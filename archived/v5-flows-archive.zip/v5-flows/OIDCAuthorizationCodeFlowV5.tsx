// src/pages/flows/OIDCAuthorizationCodeFlowV5.tsx
// V5.1 OIDC Authorization Code Flow with ID Token support

export { default } from './OIDCAuthorizationCodeFlowV5_New';
