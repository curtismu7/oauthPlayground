// src/utils/configurationStatus.ts
import { credentialManager } from './credentialManager';

export interface ConfigurationStatusResult {
  status: 'ready' | 'partial' | 'missing';
  message: string;
  missingItems: string[];
  hasCredentials: boolean;
}

/**
 * Shared configuration status logic used by both Dashboard and ConfigurationStatus components
 * This ensures consistent status display across the application
 */
export const getSharedConfigurationStatus = (flowType?: string): ConfigurationStatusResult => {
  // Use the same prioritized credential loading logic
  let credentials = credentialManager.loadConfigCredentials();
  console.log('🔧 [SharedConfigStatus] Config credentials:', credentials);
  
  if (!credentials.environmentId && !credentials.clientId) {
    credentials = credentialManager.loadAuthzFlowCredentials();
    console.log('🔧 [SharedConfigStatus] Authz flow credentials:', credentials);
  }
  if (!credentials.environmentId && !credentials.clientId) {
    credentials = credentialManager.getAllCredentials();
    console.log('🔧 [SharedConfigStatus] All credentials:', credentials);
  }
  
  // Also check localStorage directly as a fallback
  if (!credentials.environmentId && !credentials.clientId) {
    try {
      const pingoneConfig = localStorage.getItem('pingone_config');
      if (pingoneConfig) {
        const parsed = JSON.parse(pingoneConfig);
        console.log('🔧 [SharedConfigStatus] Found pingone_config in localStorage:', parsed);
        if (parsed.environmentId && parsed.clientId) {
          credentials = {
            environmentId: parsed.environmentId,
            clientId: parsed.clientId,
            clientSecret: parsed.clientSecret || '',
            authEndpoint: parsed.authEndpoint || '',
            tokenEndpoint: parsed.tokenEndpoint || '',
            userInfoEndpoint: parsed.userInfoEndpoint || '',
            redirectUri: parsed.redirectUri || ''
          };
        }
      }
    } catch (error) {
      console.warn('🔧 [SharedConfigStatus] Error parsing pingone_config:', error);
    }
  }
  
  console.log('🔍 [SharedConfigStatus] Final credentials used:', {
    environmentId: credentials.environmentId ? `${credentials.environmentId.substring(0, 8)}...` : 'MISSING',
    clientId: credentials.clientId ? `${credentials.clientId.substring(0, 8)}...` : 'MISSING',
    authEndpoint: credentials.authEndpoint ? 'SET' : 'MISSING',
    source: credentials.environmentId ? 'loaded' : 'none'
  });
  
  const missingItems = [];
  
  if (!credentials.environmentId) missingItems.push('Environment ID');
  if (!credentials.clientId) missingItems.push('Client ID');
  if (!credentials.authEndpoint) missingItems.push('API URL');

  const hasCredentials = !!(credentials.environmentId && credentials.clientId);
  const flowName = flowType === 'authorization-code' ? 'Authorization Code Flow' : 'this feature';
  
  if (missingItems.length === 0) {
    return {
      status: 'ready',
      message: `Your PingOne configuration is complete and ready to use. You can start the ${flowName} below.`,
      missingItems: [],
      hasCredentials: true
    };
  } else if (missingItems.length < 3) {
    return {
      status: 'partial',
      message: `Your PingOne configuration is partially complete. The ${flowName} may not work properly.`,
      missingItems,
      hasCredentials
    };
  } else {
    return {
      status: 'missing',
      message: `PingOne configuration is required for the ${flowName}. Please configure your credentials.`,
      missingItems,
      hasCredentials: false
    };
  }
};

/**
 * Simple boolean check for saved credentials - used by Dashboard
 */
export const hasSavedCredentials = (): boolean => {
  const statusResult = getSharedConfigurationStatus();
  return statusResult.hasCredentials;
};
