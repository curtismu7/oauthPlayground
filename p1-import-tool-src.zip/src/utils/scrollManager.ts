// src/utils/scrollManager.ts
import React from 'react';

/**
 * Centralized scroll management system for consistent behavior across the application
 * 
 * RULES:
 * - ALL pages should start at the top
 * - Authorization Code flow should ALWAYS return to top after any action
 * - No automatic scrolling to bottom unless explicitly requested by user
 */

export class ScrollManager {
  private static instance: ScrollManager;
  private scrollTimeouts: Map<string, NodeJS.Timeout> = new Map();

  static getInstance(): ScrollManager {
    if (!ScrollManager.instance) {
      ScrollManager.instance = new ScrollManager();
    }
    return ScrollManager.instance;
  }

  /**
   * Scroll to top of page - use this for ALL page loads and navigation
   */
  scrollToTop(options: { smooth?: boolean; delay?: number; force?: boolean } = {}): void {
    const { smooth = true, delay = 0, force = false } = options;
    
    // Clear any existing scroll timeouts to prevent conflicts
    this.clearScrollTimeouts();
    
    const performScroll = () => {
      console.log('📜 [ScrollManager] Scrolling to top', { smooth, force });
      
      // Force scroll to top immediately for critical cases
      if (force) {
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
      }
      
      // Then do smooth scroll if requested
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: smooth ? 'smooth' : 'instant'
      });
    };

    if (delay > 0) {
      const timeoutId = setTimeout(performScroll, delay);
      this.scrollTimeouts.set('scrollToTop', timeoutId);
    } else {
      performScroll();
    }
  }

  /**
   * Scroll to bottom of page - only use when explicitly requested by user
   */
  scrollToBottom(options: { smooth?: boolean; delay?: number } = {}): void {
    const { smooth = true, delay = 0 } = options;
    
    const performScroll = () => {
      console.log('📜 [ScrollManager] Scrolling to bottom (user requested)');
      window.scrollTo({
        top: document.documentElement.scrollHeight,
        left: 0,
        behavior: smooth ? 'smooth' : 'instant'
      });
    };

    if (delay > 0) {
      const timeoutId = setTimeout(performScroll, delay);
      this.scrollTimeouts.set('scrollToBottom', timeoutId);
    } else {
      performScroll();
    }
  }

  /**
   * Scroll to a specific element
   */
  scrollToElement(selector: string, options: { smooth?: boolean; block?: ScrollLogicalPosition; delay?: number } = {}): void {
    const { smooth = true, block = 'center', delay = 0 } = options;
    
    const performScroll = () => {
      const element = document.querySelector(selector);
      if (element) {
        console.log('📜 [ScrollManager] Scrolling to element:', selector);
        element.scrollIntoView({
          behavior: smooth ? 'smooth' : 'instant',
          block,
          inline: 'nearest'
        });
      } else {
        console.warn('📜 [ScrollManager] Element not found:', selector);
      }
    };

    if (delay > 0) {
      const timeoutId = setTimeout(performScroll, delay);
      this.scrollTimeouts.set(`scrollToElement_${selector}`, timeoutId);
    } else {
      performScroll();
    }
  }

  /**
   * Clear all pending scroll operations
   */
  clearScrollTimeouts(): void {
    this.scrollTimeouts.forEach((timeoutId) => {
      clearTimeout(timeoutId);
    });
    this.scrollTimeouts.clear();
    console.log('📜 [ScrollManager] Cleared all scroll timeouts');
  }

  /**
   * Force immediate scroll to top (for page loads and critical navigation)
   */
  forceScrollToTop(): void {
    this.scrollToTop({ smooth: false, delay: 0, force: true });
  }
}

// Export singleton instance
export const scrollManager = ScrollManager.getInstance();

// Export hook for React components
export const useScrollToTop = (options: { delay?: number; force?: boolean } = {}) => {
  React.useEffect(() => {
    scrollManager.scrollToTop({ 
      smooth: true, 
      delay: options.delay || 100,
      force: options.force || false 
    });
  }, []);
};

// Export hook for scroll to bottom (only when user explicitly requests)
export const useScrollToBottom = (options: { delay?: number } = {}) => {
  React.useEffect(() => {
    scrollManager.scrollToBottom({ 
      smooth: true, 
      delay: options.delay || 100 
    });
  }, []);
};
