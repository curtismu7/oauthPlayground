// src/hooks/usePageScroll.ts
import { useEffect } from 'react';
import { scrollManager } from '../utils/scrollManager';

/**
 * Centralized scroll hook for consistent page behavior
 * 
 * USE THIS HOOK IN ALL PAGE COMPONENTS
 * - Ensures all pages start at the top
 * - Prevents conflicting scroll behaviors
 * - Provides consistent user experience
 */

interface UsePageScrollOptions {
  /**
   * Always scroll to top on page load (default: true)
   */
  scrollToTopOnLoad?: boolean;
  
  /**
   * Delay before scrolling (default: 100ms to allow page to render)
   */
  delay?: number;
  
  /**
   * Force immediate scroll to top (default: false)
   */
  force?: boolean;
  
  /**
   * Page name for debugging
   */
  pageName?: string;
}

export const usePageScroll = (options: UsePageScrollOptions = {}) => {
  const {
    scrollToTopOnLoad = true,
    delay = 100,
    force = false,
    pageName = 'Unknown Page'
  } = options;

  useEffect(() => {
    if (scrollToTopOnLoad) {
      console.log(`📜 [usePageScroll] ${pageName} - Scrolling to top on load`);
      scrollManager.scrollToTop({ smooth: true, delay, force });
    }
    
    // Cleanup any pending scroll operations when component unmounts
    return () => {
      scrollManager.clearScrollTimeouts();
    };
  }, [scrollToTopOnLoad, delay, force, pageName]);

  // Return scroll functions for manual use
  return {
    scrollToTop: (customOptions?: { smooth?: boolean; delay?: number; force?: boolean }) => {
      console.log(`📜 [usePageScroll] ${pageName} - Manual scroll to top`);
      scrollManager.scrollToTop(customOptions);
    },
    
    scrollToBottom: (customOptions?: { smooth?: boolean; delay?: number }) => {
      console.log(`📜 [usePageScroll] ${pageName} - Manual scroll to bottom`);
      scrollManager.scrollToBottom(customOptions);
    },
    
    scrollToElement: (selector: string, customOptions?: { smooth?: boolean; block?: ScrollLogicalPosition; delay?: number }) => {
      console.log(`📜 [usePageScroll] ${pageName} - Scroll to element:`, selector);
      scrollManager.scrollToElement(selector, customOptions);
    },
    
    clearScrollTimeouts: () => {
      console.log(`📜 [usePageScroll] ${pageName} - Clearing scroll timeouts`);
      scrollManager.clearScrollTimeouts();
    }
  };
};

/**
 * Hook specifically for Authorization Code flow pages
 * - Always starts at top
 * - Always returns to top after actions
 * - Prevents any bottom scrolling
 */
export const useAuthorizationFlowScroll = (pageName: string = 'Authorization Flow') => {
  const scrollFunctions = usePageScroll({
    scrollToTopOnLoad: true,
    delay: 50, // Faster for auth flow
    force: true, // Force scroll to top for auth flow
    pageName
  });

  // Override scrollToBottom to always scroll to top instead
  return {
    ...scrollFunctions,
    scrollToBottom: () => {
      console.log(`📜 [useAuthorizationFlowScroll] ${pageName} - Blocked scroll to bottom, scrolling to top instead`);
      scrollFunctions.scrollToTop({ force: true });
    },
    
    // Force scroll to top after any action
    scrollToTopAfterAction: (actionName: string) => {
      console.log(`📜 [useAuthorizationFlowScroll] ${pageName} - Scrolling to top after action: ${actionName}`);
      scrollFunctions.scrollToTop({ delay: 200, force: true });
    }
  };
};
