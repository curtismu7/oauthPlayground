// src/components/CentralizedSuccessMessage.tsx
import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { FiCheckCircle, FiX, FiAlertCircle } from 'react-icons/fi';

interface SuccessMessage {
  id: string;
  title: string;
  message: string;
  autoCloseMs?: number; // If set, auto-close after this many milliseconds
  showAtTop?: boolean;
  showAtBottom?: boolean;
  isError?: boolean; // If true, show as error message with red styling
}

interface CentralizedSuccessMessageProps {
  position: 'top' | 'bottom';
}

const SuccessContainer = styled.div<{ $position: 'top' | 'bottom'; $isError?: boolean }>`
  position: ${({ $position }) => $position === 'top' ? 'fixed' : 'relative'};
  ${({ $position }) => $position === 'top' ? `
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 1000;
    max-width: 600px;
    width: 90%;
  ` : `
    margin: 1rem 0;
    width: 100%;
  `}
  
  background: ${({ $isError }) => $isError 
    ? 'linear-gradient(135deg, #dc2626 0%, #b91c1c 100%)'
    : 'linear-gradient(135deg, #10b981 0%, #059669 100%)'
  };
  color: white;
  padding: 1rem 1.5rem;
  border-radius: 0.75rem;
  box-shadow: ${({ $isError }) => $isError 
    ? '0 10px 25px -5px rgba(220, 38, 38, 0.3)'
    : '0 10px 25px -5px rgba(16, 185, 129, 0.3)'
  };
  border: ${({ $isError }) => $isError 
    ? '1px solid #b91c1c'
    : '1px solid #059669'
  };
  animation: slideIn 0.3s ease-out;
  
  @keyframes slideIn {
    from {
      opacity: 0;
      transform: ${({ $position }) => $position === 'top' ? 'translate(-50%, -20px)' : 'translateY(-10px)'};
    }
    to {
      opacity: 1;
      transform: ${({ $position }) => $position === 'top' ? 'translate(-50%, 0)' : 'translateY(0)'};
    }
  }
`;

const SuccessHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
`;

const SuccessContent = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  flex: 1;
`;

const SuccessTitle = styled.h3`
  margin: 0;
  font-size: 1.25rem;
  font-weight: bold;
`;

const SuccessText = styled.p`
  margin: 0.5rem 0 0 0;
  font-size: 1rem;
  opacity: 0.9;
  line-height: 1.4;
`;

const CloseButton = styled.button`
  background: rgba(255, 255, 255, 0.2);
  border: none;
  color: white;
  padding: 0.5rem;
  border-radius: 0.375rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.2s;
  
  &:hover {
    background: rgba(255, 255, 255, 0.3);
  }
`;

// Global success message state
let globalSuccessMessages: SuccessMessage[] = [];
let messageListeners: Set<(messages: SuccessMessage[]) => void> = new Set();

export class SuccessMessageManager {
  static showMessage(message: SuccessMessage): void {
    // Add message to global state
    globalSuccessMessages = [...globalSuccessMessages, message];
    
    // Notify all listeners
    messageListeners.forEach(listener => listener([...globalSuccessMessages]));
    
    // Auto-close if specified
    if (message.autoCloseMs) {
      setTimeout(() => {
        SuccessMessageManager.dismissMessage(message.id);
      }, message.autoCloseMs);
    }
    
    console.log('✅ [SuccessMessageManager] Message shown:', message.title);
  }
  
  static dismissMessage(messageId: string): void {
    globalSuccessMessages = globalSuccessMessages.filter(msg => msg.id !== messageId);
    messageListeners.forEach(listener => listener([...globalSuccessMessages]));
    console.log('❌ [SuccessMessageManager] Message dismissed:', messageId);
  }
  
  static clearAllMessages(): void {
    globalSuccessMessages = [];
    messageListeners.forEach(listener => listener([]));
    console.log('🧹 [SuccessMessageManager] All messages cleared');
  }
  
  static subscribe(listener: (messages: SuccessMessage[]) => void): () => void {
    messageListeners.add(listener);
    // Immediately send current messages
    listener([...globalSuccessMessages]);
    
    // Return unsubscribe function
    return () => {
      messageListeners.delete(listener);
    };
  }
}

const CentralizedSuccessMessage: React.FC<CentralizedSuccessMessageProps> = ({ position }) => {
  const [messages, setMessages] = useState<SuccessMessage[]>([]);

  useEffect(() => {
    const unsubscribe = SuccessMessageManager.subscribe(setMessages);
    return unsubscribe;
  }, []);

  // Filter messages based on position
  const relevantMessages = messages.filter(msg => 
    (position === 'top' && (msg.showAtTop ?? true)) ||
    (position === 'bottom' && (msg.showAtBottom ?? true))
  );

  if (relevantMessages.length === 0) {
    return null;
  }

  return (
    <>
      {relevantMessages.map(message => (
        <SuccessContainer key={`${message.id}-${position}`} $position={position} $isError={message.isError}>
          <SuccessHeader>
            <SuccessContent>
              {message.isError ? <FiAlertCircle size={24} /> : <FiCheckCircle size={24} />}
              <div>
                <SuccessTitle>{message.title}</SuccessTitle>
                <SuccessText>{message.message}</SuccessText>
              </div>
            </SuccessContent>
            <CloseButton 
              onClick={() => SuccessMessageManager.dismissMessage(message.id)}
              title="Close message"
            >
              <FiX size={18} />
            </CloseButton>
          </SuccessHeader>
        </SuccessContainer>
      ))}
    </>
  );
};

export default CentralizedSuccessMessage;

// Convenience functions for common success messages
export const showAuthorizationSuccess = (method: 'popup' | 'redirect') => {
  SuccessMessageManager.showMessage({
    id: `auth-success-${Date.now()}`,
    title: '🎉 Authorization Successful!',
    message: `You've successfully returned from PingOne authentication via ${method}. Your authorization code has been received and you can now proceed with the token exchange.`,
    autoCloseMs: 4000,
    showAtTop: true,
    showAtBottom: true
  });
};

export const showPKCESuccess = () => {
  SuccessMessageManager.showMessage({
    id: `pkce-success-${Date.now()}`,
    title: '✅ PKCE Codes Generated Successfully!',
    message: 'Your PKCE codes have been generated and are ready to use. These will be included in the authorization request for enhanced security.',
    autoCloseMs: 4000,
    showAtTop: true,
    showAtBottom: true
  });
};

export const showTokenExchangeSuccess = () => {
  SuccessMessageManager.showMessage({
    id: `token-success-${Date.now()}`,
    title: '🎉 Tokens Received Successfully!',
    message: 'Access token, refresh token, and ID token have been received. The OAuth flow is complete!',
    autoCloseMs: 4000,
    showAtTop: true,
    showAtBottom: true
  });
};

export const showCredentialsSaved = () => {
  SuccessMessageManager.showMessage({
    id: `credentials-success-${Date.now()}`,
    title: '✅ Credentials Saved Successfully!',
    message: 'Your PingOne OAuth credentials have been saved securely. You can now proceed to generate PKCE codes.',
    autoCloseMs: 4000,
    showAtTop: true,
    showAtBottom: true
  });
};

export const showAuthUrlBuilt = () => {
  SuccessMessageManager.showMessage({
    id: `auth-url-success-${Date.now()}`,
    title: '🔗 Authorization URL Built Successfully!',
    message: 'Your authorization URL has been constructed with all required OAuth parameters. You can now redirect users to PingOne.',
    autoCloseMs: 4000,
    showAtTop: true,
    showAtBottom: true
  });
};

export const showUserInfoSuccess = () => {
  SuccessMessageManager.showMessage({
    id: `userinfo-success-${Date.now()}`,
    title: '👤 User Information Retrieved!',
    message: 'User profile data has been successfully fetched from the UserInfo endpoint. The OAuth flow is now complete!',
    autoCloseMs: 4000,
    showAtTop: true,
    showAtBottom: true
  });
};

// Error message functions
export const showCredentialsError = (errorMessage: string) => {
  SuccessMessageManager.showMessage({
    id: `credentials-error-${Date.now()}`,
    title: '❌ Credentials Save Failed',
    message: `Failed to save credentials: ${errorMessage}`,
    autoCloseMs: 6000, // Errors stay longer
    showAtTop: true,
    showAtBottom: true,
    isError: true
  });
};

export const showPKCEError = (errorMessage: string) => {
  SuccessMessageManager.showMessage({
    id: `pkce-error-${Date.now()}`,
    title: '❌ PKCE Generation Failed',
    message: `Failed to generate PKCE codes: ${errorMessage}`,
    autoCloseMs: 6000,
    showAtTop: true,
    showAtBottom: true,
    isError: true
  });
};

export const showAuthUrlError = (errorMessage: string) => {
  SuccessMessageManager.showMessage({
    id: `auth-url-error-${Date.now()}`,
    title: '❌ Authorization URL Failed',
    message: `Failed to build authorization URL: ${errorMessage}`,
    autoCloseMs: 6000,
    showAtTop: true,
    showAtBottom: true,
    isError: true
  });
};

export const showTokenExchangeError = (errorMessage: string) => {
  SuccessMessageManager.showMessage({
    id: `token-error-${Date.now()}`,
    title: '❌ Token Exchange Failed',
    message: `Failed to exchange tokens: ${errorMessage}`,
    autoCloseMs: 6000,
    showAtTop: true,
    showAtBottom: true,
    isError: true
  });
};

export const showUserInfoError = (errorMessage: string) => {
  SuccessMessageManager.showMessage({
    id: `userinfo-error-${Date.now()}`,
    title: '❌ User Info Failed',
    message: `Failed to retrieve user information: ${errorMessage}`,
    autoCloseMs: 6000,
    showAtTop: true,
    showAtBottom: true,
    isError: true
  });
};

// Generic message functions for any flow
export const showFlowSuccess = (title: string, message: string, duration: number = 4000) => {
  SuccessMessageManager.showMessage({
    id: `flow-success-${Date.now()}`,
    title,
    message,
    autoCloseMs: duration,
    showAtTop: true,
    showAtBottom: true,
    isError: false
  });
};

export const showFlowError = (title: string, message: string, duration: number = 6000) => {
  SuccessMessageManager.showMessage({
    id: `flow-error-${Date.now()}`,
    title,
    message,
    autoCloseMs: duration,
    showAtTop: true,
    showAtBottom: true,
    isError: true
  });
};

// Specific flow success functions for common OAuth operations
export const showClientCredentialsSuccess = () => {
  showFlowSuccess(
    '🔑 Client Credentials Success!',
    'Access token has been obtained using client credentials flow. You can now make authenticated API calls.'
  );
};

export const showDeviceCodeSuccess = () => {
  showFlowSuccess(
    '📱 Device Code Success!',
    'Device authorization completed successfully. Tokens have been received and are ready to use.'
  );
};

export const showImplicitFlowSuccess = () => {
  showFlowSuccess(
    '⚡ Implicit Flow Success!',
    'Tokens received directly from authorization endpoint. The implicit flow is complete!'
  );
};

export const showHybridFlowSuccess = () => {
  showFlowSuccess(
    '🔄 Hybrid Flow Success!',
    'Authorization code and tokens received. The hybrid flow has been completed successfully.'
  );
};

export const showJWTBearerSuccess = () => {
  showFlowSuccess(
    '🎫 JWT Bearer Success!',
    'Access token obtained using JWT Bearer assertion. The flow is complete!'
  );
};

export const showTokenRevocationSuccess = () => {
  showFlowSuccess(
    '🗑️ Token Revoked Successfully!',
    'The token has been successfully revoked and is no longer valid.'
  );
};

export const showTokenIntrospectionSuccess = () => {
  showFlowSuccess(
    '🔍 Token Introspection Success!',
    'Token information has been successfully retrieved and validated.'
  );
};
