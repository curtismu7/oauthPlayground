// src/pages/flows/EnhancedAuthorizationCodeFlowV2.tsx - Enhanced with complete UI design implementation
import React, { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import styled from 'styled-components';
import { 
  FiUser, 
  FiKey, 
  FiGlobe, 
  FiShield, 
  FiCode, 
  FiCheckCircle, 
  FiCopy,
  FiRefreshCw,
  FiSettings,
  FiInfo,
  FiAlertTriangle,
  FiEye,
  FiEyeOff,
  FiClock,
  FiLoader,
  FiChevronDown,
  FiChevronRight
} from 'react-icons/fi';
import EnhancedStepFlowV2, { EnhancedFlowStep } from '../../components/EnhancedStepFlowV2';
import AuthorizationRequestModal from '../../components/AuthorizationRequestModal';
import OAuthErrorHelper from '../../components/OAuthErrorHelper';
import { generateCodeVerifier, generateCodeChallenge } from '../../utils/oauth';
import { credentialManager } from '../../utils/credentialManager';
import { logger } from '../../utils/logger';
import { getCallbackUrlForFlow } from '../../utils/callbackUrls';
import { PingOneErrorInterpreter } from '../../utils/pingoneErrorInterpreter';
import ConfigurationStatus from '../../components/ConfigurationStatus';
import ContextualHelp from '../../components/ContextualHelp';
import { FlowConfiguration, type FlowConfig } from '../../components/FlowConfiguration';
import { getDefaultConfig } from '../../utils/flowConfigDefaults';
import CallbackUrlDisplay from '../../components/CallbackUrlDisplay';
import ConfirmationModal from '../../components/ConfirmationModal';
import { useAuth } from '../../contexts/NewAuthContext';
import { useAuthorizationFlowScroll } from '../../hooks/usePageScroll';
import CentralizedSuccessMessage, { 
  showAuthorizationSuccess, 
  showPKCESuccess, 
  showTokenExchangeSuccess, 
  showCredentialsSaved, 
  showAuthUrlBuilt, 
  showUserInfoSuccess,
  showCredentialsError,
  showPKCEError,
  showAuthUrlError,
  showTokenExchangeError,
  showUserInfoError
} from '../../components/CentralizedSuccessMessage';
import '../../styles/enhanced-flow.css';

// Styled Components for Enhanced UI
const FormField = styled.div`
  margin-bottom: 1rem;
`;

const FormLabel = styled.label<{ $highlight?: boolean }>`
  display: block;
  font-size: 0.875rem;
  font-weight: 500;
  color: #1f2937;
  margin-bottom: 0.5rem;
  
  &.required::after {
    content: ' *';
    color: #ef4444;
  }
  
  ${props => props.$highlight && `
    color: #10b981;
    font-size: 1rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    
    &::before {
      content: "🎯";
      font-size: 1.2rem;
    }
  `}
`;

const FormInput = styled.input<{ $generated?: boolean }>`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid ${({ $generated }) => $generated ? '#10b981' : '#d1d5db'};
  border-radius: 0.5rem;
  font-size: 1rem;
  transition: all 0.2s ease;
  background: ${({ $generated }) => $generated ? '#f0fdf4' : 'white'};
  color: #1f2937;
  cursor: text;
  
  &:hover {
    border-color: #9ca3af;
    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
  }
  
  &:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.3);
  }
  
  &:invalid {
    border-color: #ef4444;
  }
  
  &:valid {
    border-color: #10b981;
  }
  
  &[readonly] {
    background: #f9fafb;
    color: #6b7280;
    cursor: not-allowed;
    border-color: #e5e7eb;
  }
`;

const FormTextarea = styled.textarea`
  width: 100%;
  min-height: 6rem;
  padding: 0.75rem;
  border: 1px solid #e5e7eb;
  border-radius: 0.5rem;
  font-size: 1rem;
  transition: all 0.2s ease;
  background: white;
  color: #1f2937;
  resize: vertical;
  font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
  
  &:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.3);
  }
`;

const FormSelect = styled.select`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #e5e7eb;
  border-radius: 0.5rem;
  font-size: 1rem;
  transition: all 0.2s ease;
  background: white;
  color: #1f2937;
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3e%3c/svg%3e");
  background-position: right 0.5rem center;
  background-repeat: no-repeat;
  background-size: 1.5em 1.5em;
  padding-right: 2.5rem;
  
  &:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.3);
  }
`;

const ValidationIndicator = styled.div<{ $valid: boolean }>`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-top: 0.5rem;
  font-size: 0.875rem;
  color: ${props => props.$valid ? '#10b981' : '#ef4444'};
`;

const InfoBox = styled.div<{ type: 'info' | 'warning' | 'success' | 'error' }>`
  padding: 1rem;
  border-radius: 0.5rem;
  margin: 1rem 0;
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  
  ${props => {
    switch (props.type) {
      case 'info':
        return `
          background: #eff6ff;
          border-left: 4px solid #3b82f6;
          color: #1e40af;
        `;
      case 'warning':
        return `
          background: #fffbeb;
          border-left: 4px solid #f59e0b;
          color: #92400e;
        `;
      case 'success':
        return `
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          border-left: 4px solid #047857;
          color: #ffffff;
          box-shadow: 0 4px 6px -1px rgba(16, 185, 129, 0.3);
        `;
      case 'error':
        return `
          background: #fef2f2;
          border-left: 4px solid #ef4444;
          color: #991b1b;
        `;
    }
  }}
`;

const UrlDisplay = styled.div`
  background: #1f2937;
  color: #e5e7eb;
  padding: 1rem;
  border-radius: 0.5rem;
  border: 3px solid #10b981;
  box-shadow: 0 0 0 1px rgba(16, 185, 129, 0.2), 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
  font-size: 0.875rem;
  line-height: 1.5;
  overflow-x: auto;
  margin: 1rem 0;
  position: relative;
  white-space: pre-wrap;
  transition: all 0.2s ease;
  
  &:hover {
    border-color: #059669;
    box-shadow: 0 0 0 1px rgba(5, 150, 105, 0.3), 0 6px 8px -1px rgba(0, 0, 0, 0.15);
  }
`;

const CopyButton = styled.button`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
  border: none;
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 0.5rem;
  font-size: 0.875rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 2px 4px rgba(59, 130, 246, 0.3);
  
  &:hover {
    background: linear-gradient(135deg, #1d4ed8 0%, #1e40af 100%);
    box-shadow: 0 4px 8px rgba(59, 130, 246, 0.4);
    transform: translateY(-1px);
  }
  
  &:active {
    transform: translateY(0);
    box-shadow: 0 2px 4px rgba(59, 130, 246, 0.3);
  }
  
  &:disabled {
    background: #9ca3af;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }
`;

const ParameterBreakdown = styled.div`
  background: linear-gradient(135deg, #f8f9ff 0%, #e8f2ff 100%);
  border: 1px solid #d1e7ff;
  padding: 1rem;
  border-radius: 0.5rem;
  margin: 1rem 0;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
`;

const ParameterItem = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.5rem 0;
  border-bottom: 1px solid #e5e7eb;
  
  &:last-child {
    border-bottom: none;
  }
`;

const ParameterName = styled.span`
  font-weight: 600;
  color: #1f2937;
`;

const ParameterValue = styled.span`
  font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
  font-size: 0.875rem;
  color: #6b7280;
  max-width: 60%;
  word-break: break-all;
`;

const JsonDisplay = styled.div`
  background: linear-gradient(135deg, #f8f9ff 0%, #e8f2ff 100%);
  color: #1f2937;
  border: 1px solid #d1e7ff;
  border-radius: 0.5rem;
  padding: 1rem;
  font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
  font-size: 0.875rem;
  line-height: 1.5;
  overflow-x: auto;
  white-space: pre-wrap;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  position: relative;
  
  @keyframes pulse {
    0%, 100% {
      transform: scale(1);
      box-shadow: 0 4px 6px -1px rgba(22, 163, 74, 0.3);
    }
    50% {
      transform: scale(1.02);
      box-shadow: 0 8px 12px -2px rgba(22, 163, 74, 0.4);
    }
  }
`;

const TestingMethodCard = styled.div<{ $selected: boolean }>`
  border: 2px solid ${props => props.$selected ? '#3b82f6' : '#e5e7eb'};
  border-radius: 0.75rem;
  padding: 1.5rem;
  margin: 1rem 0;
  cursor: pointer;
  transition: all 0.2s ease;
  background: ${props => props.$selected ? '#eff6ff' : 'white'};
  
  &:hover {
    border-color: #3b82f6;
    background: #f8fafc;
  }
`;

const MethodIcon = styled.div`
  font-size: 1.5rem;
  margin-bottom: 0.5rem;
`;

const MethodTitle = styled.h4`
  margin: 0 0 0.5rem 0;
  color: #1f2937;
  font-weight: 600;
`;

const MethodDescription = styled.p`
  margin: 0 0 1rem 0;
  color: #6b7280;
  font-size: 0.875rem;
`;

const CallbackListener = styled.div`
  background: #f9fafb;
  border: 2px dashed #d1d5db;
  border-radius: 0.5rem;
  padding: 2rem;
  text-align: center;
  margin: 1rem 0;
`;

const UserProfileCard = styled.div`
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 0.75rem;
  padding: 1.5rem;
  margin: 1rem 0;
`;

const ProfileHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;
`;

const ProfileAvatar = styled.div`
  width: 3rem;
  height: 3rem;
  border-radius: 50%;
  background: #3b82f6;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 1.5rem;
`;

const ProfileInfo = styled.div`
  flex: 1;
`;

const ProfileName = styled.h3`
  margin: 0 0 0.25rem 0;
  color: #1f2937;
  font-weight: 600;
`;

const ProfileEmail = styled.p`
  margin: 0;
  color: #6b7280;
  font-size: 0.875rem;
`;

const ProfileDetails = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  margin-top: 1rem;
`;

const DetailItem = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.875rem;
  color: #6b7280;
`;

const CodeBlock = styled.div`
  background: #f8f9fa;
  border: 1px solid #e9ecef;
  border-radius: 6px;
  padding: 1rem;
  margin: 1rem 0;
  font-family: 'SFMono-Regular', Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;
  font-size: 0.875rem;
  line-height: 1.5;
  overflow-x: auto;
`;

const CodeComment = styled.div`
  color: #6c757d;
  font-style: italic;
  margin: 0.25rem 0;
`;

const CodeLine = styled.div`
  color: #212529;
  margin: 0.25rem 0;
  word-break: break-all;
`;

const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`;

const ModalContent = styled.div`
  background: white;
  border-radius: 1rem;
  padding: 2rem;
  max-width: 600px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  position: relative;
`;

const ModalHeader = styled.div`
  text-align: center;
  margin-bottom: 2rem;
`;

const ModalTitle = styled.h2`
  margin: 0 0 0.5rem 0;
  color: #1e40af;
  font-size: 1.5rem;
`;

const ModalSubtitle = styled.p`
  margin: 0;
  color: #6b7280;
  font-size: 1rem;
`;

const ModalBody = styled.div`
  margin-bottom: 2rem;
`;

const SuccessSection = styled.div`
  background: #f0fdf4;
  border: 1px solid #22c55e;
  border-radius: 0.5rem;
  padding: 1rem;
  margin-bottom: 1rem;
`;

const SuccessTitle = styled.h3`
  margin: 0 0 0.5rem 0;
  color: #15803d;
  font-size: 1.1rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const CodeDisplay = styled.div`
  background: white;
  border: 1px solid #22c55e;
  border-radius: 0.25rem;
  padding: 0.75rem;
  font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
  font-size: 0.875rem;
  word-break: break-all;
  margin-top: 0.5rem;
`;

const ModalFooter = styled.div`
  display: flex;
  justify-content: center;
  gap: 1rem;
`;

const ModalButton = styled.button<{ $primary?: boolean; $loading?: boolean }>`
  padding: 0.75rem 1.5rem;
  border-radius: 0.5rem;
  border: none;
  font-size: 1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
  overflow: hidden;
  
  ${props => props.$primary ? `
    background: #3b82f6;
    color: white;
    
    &:hover:not(:disabled) {
      background: #2563eb;
    }
  ` : `
    background: #f3f4f6;
    color: #374151;
    
    &:hover:not(:disabled) {
      background: #e5e7eb;
    }
  `}
  
  &:disabled {
    cursor: not-allowed;
    opacity: 0.6;
  }
  
  ${props => props.$loading && `
    color: transparent;
    cursor: wait;
    
    &::after {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 1rem;
      height: 1rem;
      border: 2px solid transparent;
      border-top: 2px solid currentColor;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }
  `}
  
  @keyframes spin {
    to { transform: translate(-50%, -50%) rotate(360deg); }
  }
`;

// Main Component
const EnhancedAuthorizationCodeFlowV2: React.FC = () => {
  const authContext = useAuth();
  const { config, user: authUser, tokens: authTokens, isAuthenticated } = authContext;
  
  // Use centralized scroll management for Authorization flow
  const { scrollToTopAfterAction } = useAuthorizationFlowScroll('Enhanced Authorization Code Flow V2');
  const location = useLocation();
  const [credentials, setCredentials] = useState({
    clientId: '',
    clientSecret: '',
    environmentId: '',
    authorizationEndpoint: '',
    tokenEndpoint: '',
    userInfoEndpoint: '',
    redirectUri: window.location.origin + '/authz-callback',
    scopes: 'openid profile email',
    responseType: 'code',
    codeChallengeMethod: 'S256'
  });

  const [credentialsLoaded, setCredentialsLoaded] = useState(false);
  const [stepMessages, setStepMessages] = useState<{[key: string]: string}>({});
  const [showResetModal, setShowResetModal] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [showClearCredentialsModal, setShowClearCredentialsModal] = useState(false);
  const [isClearingCredentials, setIsClearingCredentials] = useState(false);

  // Update step message
  const updateStepMessage = useCallback((stepId: string, message: string) => {
    setStepMessages(prev => ({ ...prev, [stepId]: message }));
  }, []);

  // Clear step message
  const clearStepMessage = useCallback((stepId: string) => {
    setStepMessages(prev => {
      const newMessages = { ...prev };
      delete newMessages[stepId];
      return newMessages;
    });
  }, []);

  // Scroll functions now handled by centralized scroll management

  // Mark step as completed
  const markStepCompleted = useCallback((stepIndex: number) => {
    setCompletedSteps(prev => new Set([...prev, stepIndex]));
    console.log(`✅ [EnhancedAuthorizationCodeFlowV2] Step ${stepIndex} marked as completed`);
  }, []);

  // Check if step can be executed (not completed or user wants to re-execute)
  // State for tracking completed steps
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  
  // Track execution results for each step (for state persistence)
  const [stepResults, setStepResults] = useState<Record<string, unknown>>({});
  
  // Flag to prevent restoration after reset
  const [justReset, setJustReset] = useState(false);

  const canExecuteStep = useCallback((stepIndex: number, originalCanExecute: boolean) => {
    // If step is not completed, use original logic
    if (!completedSteps.has(stepIndex)) {
      return originalCanExecute;
    }
    
    // If step is completed, only allow execution if user is on that step and explicitly wants to re-execute
    // For now, we'll allow re-execution of completed steps
    return originalCanExecute;
  }, [completedSteps]);
  
  const saveStepResult = useCallback((stepId: string, result: unknown) => {
    setStepResults(prev => ({ ...prev, [stepId]: result }));
    console.log(`💾 [EnhancedAuthorizationCodeFlowV2] Saved result for step ${stepId}:`, result);
  }, []);
  
  const getStepResult = useCallback((stepId: string) => {
    return stepResults[stepId];
  }, [stepResults]);
  
  const hasStepResult = useCallback((stepId: string) => {
    return stepId in stepResults;
  }, [stepResults]);

  // Scroll to step progress indicator helper function (disabled to prevent overriding scroll to top)
  const scrollToStepProgress = useCallback(() => {
    // Disabled this function to prevent it from overriding the scroll to top behavior
    // The page should start at the top, not scroll to the bottom automatically
    console.log('📝 [EnhancedAuthorizationCodeFlowV2] scrollToStepProgress disabled - page starts at top');
    return;
    
    // Original code commented out:
    // setTimeout(() => {
    //   const stepProgressElement = document.querySelector('[data-testid="step-progress-bottom"]') ||
    //                              document.querySelector('[class*="sc-imTTCS"]') || 
    //                              document.querySelector('[class*="StepProgressContainer"]');
    //   
    //   if (stepProgressElement) {
    //     console.log('🎯 [EnhancedAuthorizationCodeFlowV2] Scrolling to BOTTOM step progress indicator');
    //     stepProgressElement.scrollIntoView({ 
    //       behavior: 'smooth', 
    //       block: 'center',
    //       inline: 'nearest'
    //     });
    //   } else {
    //     console.log('⚠️ [EnhancedAuthorizationCodeFlowV2] Bottom step progress not found, scrolling to bottom');
    //     window.scrollTo({
    //       top: document.documentElement.scrollHeight,
    //       behavior: 'smooth'
    //     });
    //   }
    // }, 100);
  }, []);

  // Reset flow function (preserves credentials)
  const handleResetFlow = useCallback(async () => {
    setIsResetting(true);
    try {
      console.log('🔄 [EnhancedAuthorizationCodeFlowV2] Resetting flow (preserving credentials)...');
      
      // Set reset flag to prevent restoration logic from running
      setJustReset(true);
      
      // Clear flow state but preserve credentials
      setAuthCode('');
      setTokens(null);
      setUserInfo(null);
      setAuthError(null);
      setErrorDescription(null);
      setPkceCodes({ codeVerifier: '', codeChallenge: '' });
      setAuthUrl('');
      setCustomToken('');
      setCallbackSuccess(false);
      setCallbackError(null);
      setStepMessages({});
      setCurrentStepIndex(0);
      setCompletedSteps(new Set());
      setStepResults({});
      
      // Clear flow-specific stored data but preserve credentials
      localStorage.removeItem('oauth_tokens');
      sessionStorage.removeItem('oauth_auth_code');
      sessionStorage.removeItem('code_verifier');
      sessionStorage.removeItem('code_challenge');
      sessionStorage.removeItem('oauth_state');
      sessionStorage.removeItem('enhanced-authz-code-v2-step');
      
      // Clear URL parameters by replacing the current URL without query params
      const currentUrl = new URL(window.location.href);
      currentUrl.search = '';
      window.history.replaceState({}, '', currentUrl.toString());
      
      console.log('✅ [EnhancedAuthorizationCodeFlowV2] Flow reset completed (credentials preserved)');
      
      // Show success message
      updateStepMessage('reset', 'Flow has been reset successfully. Your credentials are preserved. You can now start over from Step 1.');
      
      // Clear the reset flag after a short delay
      setTimeout(() => setJustReset(false), 1000);
      
    } catch (error) {
      console.error('❌ [EnhancedAuthorizationCodeFlowV2] Error resetting flow:', error);
    } finally {
      setIsResetting(false);
      setShowResetModal(false);
    }
  }, [updateStepMessage]);

  // Clear credentials function
  const handleClearCredentials = useCallback(async () => {
    setIsClearingCredentials(true);
    try {
      console.log('🔄 [EnhancedAuthorizationCodeFlowV2] Clearing all credentials...');
      
      // Clear credentials state
      setCredentials({
        clientId: '',
        clientSecret: '',
        environmentId: '',
        authorizationEndpoint: '',
        tokenEndpoint: '',
        userInfoEndpoint: '',
        redirectUri: window.location.origin + '/authz-callback',
        scopes: 'openid profile email',
        responseType: 'code',
        codeChallengeMethod: 'S256'
      });
      
      // Clear all flow state
      setAuthCode('');
      setTokens(null);
      setUserInfo(null);
      setAuthError(null);
      setErrorDescription(null);
      setPkceCodes({ codeVerifier: '', codeChallenge: '' });
      setAuthUrl('');
      setCustomToken('');
      setCallbackSuccess(false);
      setCallbackError(null);
      setStepMessages({});
      setCurrentStepIndex(0);
      setCompletedSteps(new Set());
      setStepResults({});
      
      // Clear all stored data
      localStorage.removeItem('oauth_tokens');
      sessionStorage.clear();
      
      // Clear credential manager data
      await credentialManager.clearAllCredentials();
      
      console.log('✅ [EnhancedAuthorizationCodeFlowV2] All credentials cleared');
      
      // Show success message
      updateStepMessage('clear-credentials', 'All credentials have been cleared. Please configure your PingOne settings again.');
      
    } catch (error) {
      console.error('❌ [EnhancedAuthorizationCodeFlowV2] Error clearing credentials:', error);
    } finally {
      setIsClearingCredentials(false);
      setShowClearCredentialsModal(false);
    }
  }, [updateStepMessage]);

  // Debug credentials state
  console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Current credentials state:', {
    environmentId: credentials.environmentId ? `${credentials.environmentId.substring(0, 8)}...` : 'none',
    clientId: credentials.clientId ? `${credentials.clientId.substring(0, 8)}...` : 'none',
    redirectUri: credentials.redirectUri || 'none',
    hasClientSecret: !!credentials.clientSecret,
    canExecutePKCE: Boolean(credentials.environmentId && credentials.clientId && credentials.redirectUri),
    credentialsLoaded: credentialsLoaded
  });

  // Monitor credentials changes
  useEffect(() => {
    console.log('🔄 [EnhancedAuthorizationCodeFlowV2] Credentials changed:', {
      environmentId: credentials.environmentId ? `${credentials.environmentId.substring(0, 8)}...` : 'none',
      clientId: credentials.clientId ? `${credentials.clientId.substring(0, 8)}...` : 'none',
      redirectUri: credentials.redirectUri || 'none',
      canExecutePKCE: Boolean(credentials.environmentId && credentials.clientId && credentials.redirectUri)
    });
  }, [credentials.environmentId, credentials.clientId, credentials.redirectUri]);

  // Monitor credentials loaded state
  useEffect(() => {
    console.log('🔄 [EnhancedAuthorizationCodeFlowV2] Credentials loaded state changed:', credentialsLoaded);
  }, [credentialsLoaded]);

  const [pkceCodes, setPkceCodes] = useState({
    codeVerifier: '',
    codeChallenge: ''
  });

  const [authUrl, setAuthUrl] = useState('');
  const [authCode, setAuthCode] = useState('');
  const [state, setState] = useState('');
  const [tokens, setTokens] = useState<Record<string, unknown> | null>(null);
  const [userInfo, setUserInfo] = useState<Record<string, unknown> | null>(null);
  const [callbackSuccess, setCallbackSuccess] = useState(false);
  const [callbackError, setCallbackError] = useState<string | null>(null);
  const [testingMethod, setTestingMethod] = useState<'popup' | 'redirect'>('popup');
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [customToken, setCustomToken] = useState<string>('');
  const [isAuthorizing, setIsAuthorizing] = useState<boolean>(false);
  const [isExchangingTokens, setIsExchangingTokens] = useState<boolean>(false);
  const [showSecret, setShowSecret] = useState<boolean>(false);
  const [showConfig, setShowConfig] = useState(false);
  const [flowConfig, setFlowConfig] = useState<FlowConfig>(getDefaultConfig('authorization-code'));
  const [showAuthSuccessModal, setShowAuthSuccessModal] = useState(false);
  const [isModalLoading, setIsModalLoading] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [showRedirectModal, setShowRedirectModal] = useState(false);
  const [redirectUrl, setRedirectUrl] = useState('');
  const [redirectParams, setRedirectParams] = useState({});
  const [isGeneratingPKCE, setIsGeneratingPKCE] = useState<boolean>(false);
  const [pkceGenerated, setPkceGenerated] = useState<boolean>(false);
  const [isSavingCredentials, setIsSavingCredentials] = useState<boolean>(false);
  const [isBuildingUrl, setIsBuildingUrl] = useState<boolean>(false);
  const [isGettingUserInfo, setIsGettingUserInfo] = useState<boolean>(false);
  const [credentialsSaved, setCredentialsSaved] = useState<boolean>(false);
  const [urlGenerated, setUrlGenerated] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [errorDescription, setErrorDescription] = useState<string | null>(null);
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({
    'setup-credentials': false,
    'exchange-tokens': false,
    'userinfo': false,
    'refresh-tokens': false
  });
  const [usedAuthCode, setUsedAuthCode] = useState<string | null>(null);
  const [showUrlDetailsInStep4, setShowUrlDetailsInStep4] = useState<boolean>(true);

  // Load UI configuration
  useEffect(() => {
    const flowConfigKey = 'enhanced-flow-authorization-code';
    const flowConfig = JSON.parse(localStorage.getItem(flowConfigKey) || '{}');
    if (flowConfig.showUrlDetailsInStep4 !== undefined) {
      setShowUrlDetailsInStep4(flowConfig.showUrlDetailsInStep4);
      console.log('🔧 [EnhancedAuthCodeFlowV2] Loaded showUrlDetailsInStep4 setting:', flowConfig.showUrlDetailsInStep4);
    }
  }, []);

  // Scroll behavior now handled by centralized scroll management hook

  // Load credentials on component mount
  useEffect(() => {
    console.log('🔍 [EnhancedAuthCodeFlowV2] Component mounted with credentials:', {
      hasClientId: !!credentials.clientId,
      hasEnvironmentId: !!credentials.environmentId,
      hasRedirectUri: !!credentials.redirectUri,
      clientId: credentials.clientId ? `${credentials.clientId.substring(0, 8)}...` : 'none'
    });

    // Clear any old authorization codes to prevent auto-exchange with expired codes
    const oldAuthCode = sessionStorage.getItem('oauth_auth_code');
    if (oldAuthCode) {
      console.log('🧹 [EnhancedAuthCodeFlowV2] Clearing old authorization code to prevent auto-exchange with expired code');
      sessionStorage.removeItem('oauth_auth_code');
      // Don't clear PKCE codes - they can be reused for multiple authorization attempts
      console.log('🔧 [EnhancedAuthCodeFlowV2] Preserving PKCE codes for reuse');
    }

    // If credentials are empty, try to load them from storage
    if (!credentials.clientId || !credentials.environmentId) {
      console.log('🔧 [EnhancedAuthCodeFlowV2] Loading credentials from storage on mount');
      
      // PRIMARY: Load from authz flow credentials (dedicated storage for this flow)
      let storedCredentials = credentialManager.loadAuthzFlowCredentials();
      console.log('🔍 [EnhancedAuthCodeFlowV2] Authz flow credentials:', storedCredentials);
      
      // FALLBACK: Only if authz flow credentials are completely blank, try permanent credentials
      if (!storedCredentials || (!storedCredentials.clientId && !storedCredentials.environmentId)) {
        console.log('🔧 [EnhancedAuthCodeFlowV2] Authz flow credentials are blank, falling back to permanent credentials');
        storedCredentials = credentialManager.loadPermanentCredentials();
        console.log('🔍 [EnhancedAuthCodeFlowV2] Permanent credentials (fallback):', storedCredentials);
      }
      
      if (storedCredentials && storedCredentials.clientId) {
        const convertedCredentials = {
          clientId: storedCredentials.clientId,
          clientSecret: storedCredentials.clientSecret || '',
          environmentId: storedCredentials.environmentId,
          authorizationEndpoint: storedCredentials.authEndpoint || '',
          tokenEndpoint: storedCredentials.tokenEndpoint || '',
          userInfoEndpoint: storedCredentials.userInfoEndpoint || '',
          redirectUri: storedCredentials.redirectUri,
          scopes: Array.isArray(storedCredentials.scopes) ? storedCredentials.scopes.join(' ') : (storedCredentials.scopes || 'openid profile email'),
          responseType: 'code',
          codeChallengeMethod: 'S256'
        };
        setCredentials(convertedCredentials);
        console.log('✅ [EnhancedAuthCodeFlowV2] Loaded credentials from storage:', {
          clientId: storedCredentials.clientId ? `${storedCredentials.clientId.substring(0, 8)}...` : 'none',
          environmentId: storedCredentials.environmentId,
          source: storedCredentials.clientSecret ? 'authz-flow' : 'permanent-fallback'
        });
      } else {
        console.log('⚠️ [EnhancedAuthCodeFlowV2] No stored credentials found - user needs to configure');
      }
    }
  }, []);

  // Toggle collapsed section
  const toggleSection = (sectionId: string) => {
    setCollapsedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  // Handle URL parameters to restore correct step
  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const stepParam = urlParams.get('step');
    const code = urlParams.get('code');
    const state = urlParams.get('state');
    
    console.log('🔍 [EnhancedAuthorizationCodeFlowV2] URL params:', { stepParam, code, state });
    console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Current location:', location);
    console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Auth context state:', { isAuthenticated, user: authUser, tokens: authTokens });
    console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Current state values:', {
      authCode,
      callbackSuccess,
      callbackError,
      tokens: !!tokens,
      userInfo: !!userInfo,
      credentials: {
        environmentId: !!credentials.environmentId,
        clientId: !!credentials.clientId,
        redirectUri: !!credentials.redirectUri
      }
    });
    
    // If we have step parameter, use it (this comes from the callback redirect)
    if (stepParam) {
      const stepIndex = parseInt(stepParam, 10) - 1; // Convert to 0-based index
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] URL step parameter detected:', stepParam, '-> step index:', stepIndex);
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Setting stored step to:', stepIndex);
      
      // If we also have an authorization code in the URL, set it
      if (code) {
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Setting authCode from URL (with step param):', code);
        setAuthCode(code);
        setState(state || '');
        
        // Store authorization code in sessionStorage for persistence
        sessionStorage.setItem('oauth_auth_code', code);
        if (state) {
          sessionStorage.setItem('oauth_state', state);
        }
        
        // Mark callback as successful and check for tokens
        setCallbackSuccess(true);
        setCallbackError(null);
        
        // Show success message for successful login
        updateStepMessage('user-authorization', '✅ Welcome back from PingOne! You have successfully logged in and been redirected back. Your authorization code is ready for token exchange.');
        
        // Show centralized success message for full redirect
        showAuthorizationSuccess('redirect');
        scrollToTopAfterAction('Full Redirect Authorization');
        
        // Check if we have tokens from the auth context
        if (authTokens) {
          console.log('✅ [EnhancedAuthorizationCodeFlowV2] Tokens found in auth context:', authTokens);
          setTokens(authTokens);
        }
        
        // Check if we have user info from the auth context
        if (authUser) {
          console.log('✅ [EnhancedAuthorizationCodeFlowV2] User info found in auth context:', authUser);
          setUserInfo(authUser);
        }
      } else {
        console.log('⚠️ [EnhancedAuthorizationCodeFlowV2] Step parameter found but no authorization code in URL');
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Full URL:', window.location.href);
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] URL search params:', location.search);
        
        // Check if we have a stored authorization code
        const storedCode = sessionStorage.getItem('oauth_auth_code');
        if (storedCode) {
          console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Found stored authorization code:', storedCode);
          setAuthCode(storedCode);
          setCallbackSuccess(true);
          setCallbackError(null);
          
          // Don't auto-exchange stored codes - let the user manually proceed to step 5
          console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Stored authorization code found, user should proceed to step 5 manually');
        }
      }
      
      sessionStorage.setItem('enhanced-authz-code-v2-step', stepIndex.toString());
      return;
    }
    
    // If we have authorization code, we should go to step 5 (exchange tokens) and exchange immediately
    if (code) {
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Authorization code detected, going to step 5 (exchange tokens)');
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Setting authCode from URL:', code);
      
      // Set the authorization code from URL parameters first
      setAuthCode(code);
      setState(state || '');
      
      // Store authorization code in sessionStorage for persistence
      sessionStorage.setItem('oauth_auth_code', code);
      if (state) {
        sessionStorage.setItem('oauth_state', state);
      }
      
      // Mark callback as successful
      setCallbackSuccess(true);
      setCallbackError(null);
      
      // Set step to 5 (exchange tokens) directly so the exchange button is enabled
      const stepIndex = 5;
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Setting step to 5 (exchange tokens) for immediate access');
      setCurrentStepIndex(stepIndex);
      sessionStorage.setItem('enhanced-authz-code-v2-step', stepIndex.toString());
      
      // Show success message for successful login
      updateStepMessage('user-authorization', '✅ Welcome back from PingOne! You have successfully logged in and been redirected back. Your authorization code is ready for token exchange.');
      updateStepMessage('exchange-tokens', '✅ Ready to exchange authorization code for tokens. Your authorization was successful and the exchange button is now enabled.');
      
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Authorization code received, user is now on step 5 with exchange button enabled');
      
      return;
    }
    
    // Check if we're coming back from a redirect and should restore to a specific step
    const storedStep = sessionStorage.getItem('enhanced-authz-code-v2-step');
    const storedAuthCode = sessionStorage.getItem('oauth_auth_code');
    const storedState = sessionStorage.getItem('oauth_state');
    
    if (storedStep) {
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Restoring from stored step:', storedStep);
      
      // Restore the authorization code and state if available
      if (storedAuthCode && !authCode) {
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Restoring authCode from sessionStorage:', storedAuthCode);
        setAuthCode(storedAuthCode);
        setCallbackSuccess(true);
        setCallbackError(null);
      }
      
      if (storedState && !state) {
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Restoring state from sessionStorage:', storedState);
        setState(storedState);
      }
      
      // Set the current step
      const stepIndex = parseInt(storedStep, 10);
      if (!isNaN(stepIndex) && stepIndex !== currentStepIndex) {
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Setting current step index to:', stepIndex);
        setCurrentStepIndex(stepIndex);
      }
    }
  }, [location.search, authTokens, authUser, authCode, currentStepIndex, state]);

  // Additional effect to ensure authCode is loaded from sessionStorage if missing
  useEffect(() => {
    const storedAuthCode = sessionStorage.getItem('oauth_auth_code');
    const storedState = sessionStorage.getItem('oauth_state');
    
    // If we don't have authCode but it's stored, restore it
    if (!authCode && storedAuthCode) {
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Restoring missing authCode from sessionStorage:', storedAuthCode);
      setAuthCode(storedAuthCode);
      setCallbackSuccess(true);
      setCallbackError(null);
    }
    
    // If we don't have state but it's stored, restore it
    if (!state && storedState) {
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Restoring missing state from sessionStorage:', storedState);
      setState(storedState);
    }
  }, [authCode, state]);

  // Manage success modal visibility
  useEffect(() => {
    // Only keep modal hidden if there's no authorization code
    // When we have an authCode, the modal should be allowed to show for consistent messaging
    if (!authCode) {
      setShowAuthSuccessModal(false);
    }
  }, [authCode, currentStepIndex]);

  // This useEffect is now handled by the main step initialization logic above

  // Debug effect to track state changes
  useEffect(() => {
    console.log('🔍 [EnhancedAuthorizationCodeFlowV2] State change detected:', {
      authCode: !!authCode,
      authCodeValue: authCode,
      callbackSuccess,
      callbackError,
      tokens: !!tokens,
      userInfo: !!userInfo,
      credentials: {
        environmentId: !!credentials.environmentId,
        clientId: !!credentials.clientId,
        redirectUri: !!credentials.redirectUri
      },
      timestamp: new Date().toISOString()
    });
  }, [authCode, callbackSuccess, callbackError, tokens, userInfo, credentials.environmentId, credentials.clientId, credentials.redirectUri]);

  // Load credentials immediately to ensure buttons are enabled
  useEffect(() => {
    const loadCredentials = async () => {
      try {
        // Debug localStorage contents
        credentialManager.debugLocalStorage();
        
        // PRIMARY: Load from authz flow credentials (dedicated storage for this flow)
        let allCredentials = credentialManager.loadAuthzFlowCredentials();
        console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Loading authz flow credentials:', allCredentials);
        
        // FALLBACK: Only if authz flow credentials are completely blank, try permanent credentials
        if (!allCredentials || (!allCredentials.clientId && !allCredentials.environmentId)) {
          console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Authz flow credentials are blank, falling back to permanent credentials');
          allCredentials = credentialManager.loadPermanentCredentials();
          console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Loading permanent credentials (fallback):', allCredentials);
        }
        
        // Debug what we found
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Final credentials to load:', {
          hasCredentials: !!allCredentials,
          environmentId: allCredentials?.environmentId ? `${allCredentials.environmentId.substring(0, 8)}...` : 'none',
          clientId: allCredentials?.clientId ? `${allCredentials.clientId.substring(0, 8)}...` : 'none',
          redirectUri: allCredentials?.redirectUri || 'none',
          hasClientSecret: !!allCredentials?.clientSecret,
          source: allCredentials?.clientSecret ? 'authz-flow' : 'permanent-fallback'
        });
        
        // Check for test values and clear them (only if BOTH are test values AND no other valid config exists)
        if (allCredentials.clientId === 'test-client-123' && allCredentials.environmentId === 'test-env-123') {
          console.log('🧹 [EnhancedAuthorizationCodeFlowV2] Found test values, checking if we should clear...');
          
          // Check if there are any other valid credentials in localStorage
          const pingoneConfig = localStorage.getItem('pingone_config');
          const loginCredentials = localStorage.getItem('login_credentials');
          
          if (!pingoneConfig && !loginCredentials) {
            console.log('🧹 [EnhancedAuthorizationCodeFlowV2] No other credentials found, clearing test values');
            credentialManager.clearAllCredentials();
            console.log('✅ [EnhancedAuthorizationCodeFlowV2] Test credentials cleared');
            return;
          } else {
            console.log('⚠️ [EnhancedAuthorizationCodeFlowV2] Other credentials exist, keeping test values for now');
          }
        }
        
        // Check if we have any credentials
        const hasCredentials = allCredentials.environmentId || allCredentials.clientId;
        
        if (!hasCredentials) {
          console.log('⚠️ [EnhancedAuthorizationCodeFlowV2] No credentials found, loading from environment variables...');
          try {
            const response = await fetch('/api/env-config');
            if (response.ok) {
              const envConfig = await response.json();
              console.log('✅ [EnhancedAuthorizationCodeFlowV2] Loaded from environment config:', envConfig);
              
              setCredentials(prev => ({ 
                ...prev, 
                environmentId: envConfig.environmentId || '',
                clientId: envConfig.clientId || '',
                clientSecret: envConfig.clientSecret || '',
                redirectUri: envConfig.redirectUri || window.location.origin + '/authz-callback',
                authorizationEndpoint: envConfig.authEndpoint || `${envConfig.apiUrl}/${envConfig.environmentId}/as/authorize`,
                tokenEndpoint: envConfig.tokenEndpoint || `${envConfig.apiUrl}/${envConfig.environmentId}/as/token`,
                userInfoEndpoint: envConfig.userInfoEndpoint || `${envConfig.apiUrl}/${envConfig.environmentId}/as/userinfo`,
                scopes: Array.isArray(envConfig.scopes) ? envConfig.scopes.join(' ') : (envConfig.scopes || 'openid profile email')
              }));
              
              console.log('✅ [EnhancedAuthorizationCodeFlowV2] Credentials loaded from environment variables');
              return;
            }
          } catch (envError) {
            console.warn('⚠️ [EnhancedAuthorizationCodeFlowV2] Failed to load from environment variables:', envError);
          }
        }
        
        setCredentials(prev => ({ 
          ...prev, 
          environmentId: allCredentials.environmentId || '',
          clientId: allCredentials.clientId || '',
          clientSecret: allCredentials.clientSecret || '',
          redirectUri: allCredentials.redirectUri || window.location.origin + '/authz-callback',
          authorizationEndpoint: allCredentials.authEndpoint || '',
          tokenEndpoint: allCredentials.tokenEndpoint || '',
          userInfoEndpoint: allCredentials.userInfoEndpoint || '',
          scopes: Array.isArray(allCredentials.scopes) ? allCredentials.scopes.join(' ') : (allCredentials.scopes || 'openid profile email')
        }));
        
        console.log('✅ [EnhancedAuthorizationCodeFlowV2] Credentials loaded successfully:', {
          environmentId: allCredentials.environmentId ? `${allCredentials.environmentId.substring(0, 8)}...` : 'none',
          clientId: allCredentials.clientId ? `${allCredentials.clientId.substring(0, 8)}...` : 'none',
          redirectUri: allCredentials.redirectUri || 'none',
          hasClientSecret: !!allCredentials.clientSecret
        });
        
        // Mark credentials as loaded
        setCredentialsLoaded(true);
      } catch (error) {
        console.error('❌ [EnhancedAuthorizationCodeFlowV2] Failed to load credentials:', error);
        logger.error('EnhancedAuthorizationCodeFlowV2', 'Failed to load credentials', String(error));
      }
    };
    
    // Load credentials asynchronously
    loadCredentials().then(() => {
      console.log('✅ [EnhancedAuthorizationCodeFlowV2] Credentials loading completed');
    }).catch((error) => {
      console.error('❌ [EnhancedAuthorizationCodeFlowV2] Failed to load credentials:', error);
    });
    console.log('🧹 [EnhancedAuthorizationCodeFlowV2] Cleared all flow states and loaded credentials on mount');
  }, []);

  // Initialize step index based on URL parameters and stored step
  useEffect(() => {
    let hasInitialized = false;
    
    const initializeStepIndex = () => {
      if (hasInitialized) {
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] InitializeStepIndex - Already initialized, skipping');
        return;
      }
      hasInitialized = true;
      const storedStep = sessionStorage.getItem('enhanced-authz-code-v2-step');
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] InitializeStepIndex - Checking for stored step:', storedStep);
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] InitializeStepIndex - Current URL:', window.location.href);
      
      // Check if we have an authorization code in the URL
      const urlParams = new URLSearchParams(window.location.search);
      const code = urlParams.get('code');
      const state = urlParams.get('state');
      const step = urlParams.get('step');
      const action = urlParams.get('action');
      
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] InitializeStepIndex - URL params:', { code, state, step, action });
      
      // PRIORITY 1: If we have both code and step=5, go directly to step 5 and exchange tokens
      if (code && step === '5') {
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] InitializeStepIndex - Authorization code with step=5, going directly to step 5');
        setCurrentStepIndex(5);
        setAuthCode(code);
        setState(state || '');
        setCallbackSuccess(true);
        setCallbackError(null);
        
        // Show success message for successful login
        updateStepMessage('user-authorization', '✅ Welcome back from PingOne! You have successfully logged in and been redirected back. Your authorization code is ready for token exchange.');
        
        // Check if tokens are already present and show appropriate message
        const hasTokens = (tokens && tokens.access_token) || (authTokens && authTokens.access_token);
        if (hasTokens) {
          updateStepMessage('exchange-tokens', '✅ Tokens already exchanged! Click "Next" to proceed to the UserInfo endpoint and see your user details.');
        } else {
          updateStepMessage('exchange-tokens', '🔄 Ready to exchange authorization code for tokens. Click the "Exchange Token" button to proceed with token exchange.');
        }
        
        // Auto-exchange tokens immediately (only if not already exchanging and on correct step)
        // Use the step we just set (5) instead of currentStepIndex which hasn't updated yet
        if (false) { // Disabled auto-exchange - user must manually execute
          // Check if this is a fresh authorization code (not an old one from sessionStorage)
          const isFreshCode = !sessionStorage.getItem('oauth_auth_code');
          if (isFreshCode) {
            setTimeout(async () => {
              try {
                console.log('🔄 [EnhancedAuthorizationCodeFlowV2] Auto-exchanging fresh authorization code for tokens');
                
                // CRITICAL: Ensure credentials are loaded before auto-exchange
                if (!credentials.clientId || !credentials.environmentId) {
                  console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Loading credentials before auto-exchange');
                // PRIMARY: Load from authz flow credentials (dedicated storage for this flow)
                let storedCredentials = credentialManager.loadAuthzFlowCredentials();
                
                // FALLBACK: Only if authz flow credentials are completely blank, try permanent credentials
                if (!storedCredentials || (!storedCredentials.clientId && !storedCredentials.environmentId)) {
                  console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Authz flow credentials are blank, falling back to permanent credentials');
                  storedCredentials = credentialManager.loadPermanentCredentials();
                }
                
                if (storedCredentials && storedCredentials.clientId) {
                  const convertedCredentials = {
                    clientId: storedCredentials.clientId,
                    clientSecret: storedCredentials.clientSecret || '',
                    environmentId: storedCredentials.environmentId,
                    authorizationEndpoint: storedCredentials.authEndpoint || '',
                    tokenEndpoint: storedCredentials.tokenEndpoint || '',
                    userInfoEndpoint: storedCredentials.userInfoEndpoint || '',
                    redirectUri: storedCredentials.redirectUri,
                    scopes: Array.isArray(storedCredentials.scopes) ? storedCredentials.scopes.join(' ') : (storedCredentials.scopes || 'openid profile email'),
                    responseType: 'code',
                    codeChallengeMethod: 'S256'
                  };
                  setCredentials(convertedCredentials);
                  console.log('✅ [EnhancedAuthorizationCodeFlowV2] Loaded credentials for auto-exchange');
                } else {
                  console.error('❌ [EnhancedAuthorizationCodeFlowV2] No credentials found for auto-exchange');
                  return;
                }
                }
                
                // Ensure PKCE codes are generated before exchange
                if (!pkceCodes.codeVerifier) {
                  console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Generating PKCE codes before exchange');
                  await generatePKCECodes();
                }
                
                await exchangeCodeForTokens();
                console.log('✅ [EnhancedAuthorizationCodeFlowV2] Auto token exchange successful');
              } catch (error) {
                console.error('❌ [EnhancedAuthorizationCodeFlowV2] Auto token exchange failed:', error);
              }
            }, 500); // Increased delay to ensure credentials are loaded
          } else {
            console.log('⚠️ [EnhancedAuthorizationCodeFlowV2] Skipping auto-exchange - using old authorization code, user should start fresh flow');
          }
        } else {
          console.log('⚠️ [EnhancedAuthorizationCodeFlowV2] Skipping auto-exchange - already in progress, tokens exist, or not on correct step');
        }
        return;
      }
      
      // PRIORITY 2: If we have authorization code but no step, go to step 4 (handle callback)
      if (code && !step) {
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] InitializeStepIndex - Authorization code found in URL, going to step 4 (handle-callback)');
        setCurrentStepIndex(4);
        return;
      }
      
      if (step) {
        const stepIndex = parseInt(step, 10);
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] InitializeStepIndex - Step from URL:', stepIndex);
        setCurrentStepIndex(stepIndex);
        // Clean up URL parameters after using them
        const newUrl = new URL(window.location.href);
        newUrl.searchParams.delete('step');
        newUrl.searchParams.delete('action');
        window.history.replaceState({}, '', newUrl.toString());
        return;
      }
      
      if (storedStep) {
        const stepIndex = parseInt(storedStep, 10);
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] InitializeStepIndex - Restoring step from stored value:', stepIndex);
        setCurrentStepIndex(stepIndex);
        return;
      }
      
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] InitializeStepIndex - No step to restore, starting from beginning');
      setCurrentStepIndex(0);
    };

    initializeStepIndex();
  }, []);

  // Listen for credential changes (debounced to prevent excessive calls)
  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    
    const handleCredentialChange = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        try {
          // Use the same loading logic as the main loadCredentials function
          let allCredentials = credentialManager.loadAuthzFlowCredentials();
          console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Reloading authz flow credentials after change:', allCredentials);
          
          // FALLBACK: Only if authz flow credentials are completely blank, try permanent credentials
          if (!allCredentials || (!allCredentials.clientId && !allCredentials.environmentId)) {
            console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Authz flow credentials are blank, falling back to permanent credentials');
            allCredentials = credentialManager.loadPermanentCredentials();
            console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Reloading permanent credentials (fallback):', allCredentials);
          }
          
          setCredentials(prev => ({ 
            ...prev, 
            environmentId: allCredentials.environmentId || '',
            clientId: allCredentials.clientId || '',
            clientSecret: allCredentials.clientSecret || '',
            redirectUri: allCredentials.redirectUri || window.location.origin + '/authz-callback',
            authorizationEndpoint: allCredentials.authEndpoint || '',
            tokenEndpoint: allCredentials.tokenEndpoint || '',
            userInfoEndpoint: allCredentials.userInfoEndpoint || '',
            scopes: Array.isArray(allCredentials.scopes) ? allCredentials.scopes.join(' ') : (allCredentials.scopes || 'openid profile email')
          }));
          
          console.log('✅ [EnhancedAuthorizationCodeFlowV2] Credentials reloaded successfully');
        } catch (error) {
          console.error('❌ [EnhancedAuthorizationCodeFlowV2] Failed to reload credentials:', error);
          logger.error('EnhancedAuthorizationCodeFlowV2', 'Failed to reload credentials', String(error));
        }
      }, 100); // Debounce by 100ms
    };
    
    window.addEventListener('permanent-credentials-changed', handleCredentialChange);
    
    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('permanent-credentials-changed', handleCredentialChange);
    };
  }, []);

  // Save credentials
  const saveCredentials = useCallback(async () => {
    setIsSavingCredentials(true);
    try {
      console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Saving credentials:', credentials);
      
      // Prepare authz flow credentials (Environment ID, Client ID, etc.)
      const authzFlowCreds = {
        environmentId: credentials.environmentId,
        clientId: credentials.clientId,
        clientSecret: credentials.clientSecret, // Include client secret in authz flow storage
        redirectUri: credentials.redirectUri,
        scopes: typeof credentials.scopes === 'string' ? credentials.scopes.split(' ').filter(Boolean) : credentials.scopes,
        authEndpoint: credentials.authorizationEndpoint,
        tokenEndpoint: credentials.tokenEndpoint,
        userInfoEndpoint: credentials.userInfoEndpoint
      };
      
      // Save to authz flow credentials (dedicated storage for this flow)
      const authzFlowSuccess = credentialManager.saveAuthzFlowCredentials(authzFlowCreds);

      if (authzFlowSuccess) {
        logger.info('Authz flow credentials saved successfully to credential manager', '');
        
        // Clear cache to ensure fresh data is loaded
        credentialManager.clearCache();
        
        // Dispatch events to notify other components that config has changed
        window.dispatchEvent(new CustomEvent('pingone-config-changed'));
        window.dispatchEvent(new CustomEvent('permanent-credentials-changed'));
        
        console.log('✅ [EnhancedAuthorizationCodeFlowV2] Authz flow credentials saved successfully to localStorage and events dispatched');
        
        // Keep the form values - don't clear them after saving
        console.log('✅ [EnhancedAuthorizationCodeFlowV2] Form values preserved after save');
        
        // Show success message
        updateStepMessage('setup-credentials', '✅ Credentials saved successfully! You can now proceed to Step 2 to generate PKCE codes.');
        
        // Show centralized success message and scroll to top
        showCredentialsSaved();
        scrollToTopAfterAction('Credentials Saved');
        
        return { success: true, message: 'Credentials saved successfully' };
      } else {
        const errorMsg = 'Failed to save authz flow credentials to credential manager';
        showCredentialsError(errorMsg);
        throw new Error(errorMsg);
      }
    } catch (error) {
      console.error('❌ [EnhancedAuthorizationCodeFlowV2] Failed to save credentials:', error);
      logger.error('EnhancedAuthorizationCodeFlowV2', 'Failed to save credentials', String(error));
      const errorMsg = error instanceof Error ? error.message : String(error);
      showCredentialsError(errorMsg);
      throw error; // Re-throw to let the step execution handle the error
    } finally {
      setIsSavingCredentials(false);
      setCredentialsSaved(true);
    }
  }, [credentials]);

  // Generate PKCE codes
  const generatePKCECodes = useCallback(async () => {
    try {
      console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Starting PKCE generation...');
    const verifier = generateCodeVerifier();
      const challenge = await generateCodeChallenge(verifier);
      console.log('✅ [EnhancedAuthorizationCodeFlowV2] PKCE codes generated:', { verifier: verifier.substring(0, 20) + '...', challenge: challenge.substring(0, 20) + '...' });
    setPkceCodes({ codeVerifier: verifier, codeChallenge: challenge });
      
      // Store code_verifier in sessionStorage for token exchange
      sessionStorage.setItem('code_verifier', verifier);
      console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Stored code_verifier in sessionStorage');
      
      logger.info('PKCE codes generated', '');
      
      // Don't show step message since we have the banner at the bottom
      // updateStepMessage('generate-pkce', '✅ PKCE codes generated successfully! These codes add security to your OAuth flow. You can now proceed to Step 3 to build the authorization URL.');
      
      // Show centralized success message and scroll to top
      showPKCESuccess();
      scrollToTopAfterAction('PKCE Generation');
      
      return { verifier, challenge };
    } catch (error) {
      console.error('❌ [EnhancedAuthorizationCodeFlowV2] Failed to generate PKCE codes:', error);
      logger.error('Failed to generate PKCE codes', String(error));
      const errorMsg = error instanceof Error ? error.message : String(error);
      showPKCEError(errorMsg);
      throw error;
    }
  }, []);

  // Generate authorization URL
  const generateAuthUrl = useCallback(() => {
    const generatedState = Math.random().toString(36).substring(2, 15);
    setState(generatedState);
    
    // Store state in sessionStorage for CSRF protection validation
    sessionStorage.setItem('oauth_state', generatedState);
    console.log('🔐 [EnhancedAuthorizationCodeFlowV2] Stored state for CSRF protection:', generatedState);
    
    // Debug: Log all credential values
    console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Current credentials:', {
      clientId: credentials.clientId,
      environmentId: credentials.environmentId,
      authorizationEndpoint: credentials.authorizationEndpoint,
      scopes: credentials.scopes
    });
    
    // Ensure scopes are properly formatted
    const scopes = credentials.scopes || 'openid profile email';
    console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Generating auth URL with scopes:', scopes);
    
    // Use the correct callback URL for authorization code flow
    const redirectUri = getCallbackUrlForFlow('authorization-code');
    console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Using redirect URI:', redirectUri);
    
    // Validate required parameters BEFORE building URL
    if (!credentials.clientId) {
      throw new Error('Client ID is required. Please configure your credentials first.');
    }
    if (!credentials.environmentId) {
      throw new Error('Environment ID is required. Please configure your credentials first.');
    }
    if (!credentials.authorizationEndpoint) {
      throw new Error('Authorization endpoint is required. Please configure your credentials first.');
    }
    if (!redirectUri) {
      throw new Error('Redirect URI is required');
    }
    if (!scopes || scopes.trim() === '') {
      throw new Error('At least one scope must be specified');
    }
    
    const params = new URLSearchParams({
      response_type: credentials.responseType || 'code',
      client_id: credentials.clientId,
      redirect_uri: redirectUri,
      scope: scopes,
      state: generatedState,
      code_challenge: pkceCodes.codeChallenge,
      code_challenge_method: credentials.codeChallengeMethod || 'S256'
    });

    const url = `${credentials.authorizationEndpoint}?${params.toString()}`;
    console.log('✅ [EnhancedAuthorizationCodeFlowV2] Generated authorization URL:', url);
    console.log('🔧 [EnhancedAuthorizationCodeFlowV2] URL parameters:', Object.fromEntries(params));
    setAuthUrl(url);
    logger.info('EnhancedAuthorizationCodeFlowV2', 'Authorization URL generated', { url, scopes });
    
    // Scroll to step progress to show the generated URL and next step
    scrollToStepProgress();
  }, [credentials, pkceCodes.codeChallenge]);

  // Handle authorization
  const handleAuthorization = useCallback(async () => {
    // Use the same redirect URI logic as in generateAuthUrl
    const redirectUri = getCallbackUrlForFlow('authorization-code');
    
    if (testingMethod === 'popup') {
      setIsAuthorizing(true);
      
      // Set up flow context for popup callback
      const currentPath = window.location.pathname;
      // Ensure we use the correct route path regardless of current path
      const correctPath = currentPath.includes('/oidc/') ? '/flows/enhanced-authorization-code-v2' : currentPath;
      const returnPath = `${correctPath}?step=4`; // Return to step 4 (token exchange)

      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Popup - Current path:', currentPath);
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Popup - Correct path:', correctPath);
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Popup - Return path:', returnPath);
      
      const flowContext = {
        flow: 'enhanced-authorization-code-v2',
        step: 4,
        returnPath: returnPath,
        redirectUri: redirectUri, // Store the redirect URI used in authorization
        timestamp: Date.now()
      };
      sessionStorage.setItem('flowContext', JSON.stringify(flowContext));
      
      console.log('🔄 [EnhancedAuthorizationCodeFlowV2] Stored flow context for callback:', flowContext);
      
      const popup = window.open(authUrl, 'oauth-popup', 'width=600,height=700');
      if (popup) {
        // Don't show success message yet - wait for actual login completion
        // Listen for messages from the popup
        const messageHandler = (event: MessageEvent) => {
          if (event.origin !== window.location.origin) return;
          if (event.data.type === 'oauth-callback') {
            const { code: callbackCode, state: callbackState, error, error_description } = event.data;
            if (error) {
              logger.error('Authorization error received', error);
              setAuthError(error);
              setErrorDescription(error_description || error);
              setIsAuthorizing(false);
            } else if (callbackCode && callbackState === state) {
              setAuthCode(callbackCode);
              setAuthError(null);
              setErrorDescription(null);
              logger.info('EnhancedAuthorizationCodeFlowV2', 'Authorization code received via message', `code: ${callbackCode.substring(0, 10)}...`);
              setIsAuthorizing(false);
              popup.close();
              window.removeEventListener('message', messageHandler);
              
              // Show centralized success message for popup authorization
              showAuthorizationSuccess('popup');
              scrollToTopAfterAction('Popup Authorization');
            }
          }
        };
        window.addEventListener('message', messageHandler);
        
        // Check if popup was closed without completing auth
        const checkClosed = setInterval(() => {
          if (popup.closed) {
            clearInterval(checkClosed);
            window.removeEventListener('message', messageHandler);
            setIsAuthorizing(false);
            if (!authCode) {
              logger.warn('EnhancedAuthorizationCodeFlowV2', 'Popup closed without authorization code');
            }
          }
        }, 1000);
      } else {
        setIsAuthorizing(false);
        logger.error('EnhancedAuthorizationCodeFlowV2', 'Failed to open popup window');
      }
    } else {
      // Full redirect - set up flow context to return to correct step
      const currentPath = window.location.pathname;
      // Ensure we use the correct route path regardless of current path
      const correctPath = currentPath.includes('/oidc/') ? '/flows/enhanced-authorization-code-v2' : currentPath;
      const returnPath = `${correctPath}?step=4`; // Return to step 4 (token exchange)

      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Full redirect - Current path:', currentPath);
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Full redirect - Correct path:', correctPath);
      console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Full redirect - Return path:', returnPath);
      
      const flowContext = {
        flow: 'enhanced-authorization-code-v2',
        step: 4,
        returnPath: returnPath,
        redirectUri: redirectUri, // Store the redirect URI used in authorization
        timestamp: Date.now()
      };
      sessionStorage.setItem('flowContext', JSON.stringify(flowContext));
      
      console.log('🔄 [EnhancedAuthorizationCodeFlowV2] Stored flow context for callback:', flowContext);
      
      // Don't show success message yet - wait for actual login completion
      
      // Full redirect
      logger.info('EnhancedAuthorizationCodeFlowV2', 'Redirecting to authorization server', `url: ${authUrl}`);
      window.location.href = authUrl;
    }
  }, [authUrl, testingMethod, state, authCode]);

  // Exchange code for tokens
  const exchangeCodeForTokens = useCallback(async () => {
    // Prevent multiple simultaneous exchanges
    if (isExchangingTokens) {
      console.log('⚠️ [EnhancedAuthCodeFlowV2] Token exchange already in progress, skipping');
      return;
    }

    // Check if we already have tokens
    if (tokens?.access_token) {
      console.log('⚠️ [EnhancedAuthCodeFlowV2] Tokens already exist, skipping exchange');
      return;
    }

    // Check if we've already used this authorization code
    if (usedAuthCode && usedAuthCode === authCode) {
      console.log('⚠️ [EnhancedAuthCodeFlowV2] Authorization code already used, skipping exchange');
      return;
    }

    // Additional check: if authCode is empty, don't proceed
    if (!authCode || authCode.trim() === '') {
      throw new Error('No authorization code available. Please complete the OAuth flow first.');
    }

    // CRITICAL: Load credentials if they're missing
    console.log('🔍 [EnhancedAuthCodeFlowV2] Checking credentials before token exchange...');
    let currentCredentials = credentials;
    
    // If credentials are empty, try to load them from storage
    if (!currentCredentials.clientId || !currentCredentials.environmentId) {
      console.log('🔧 [EnhancedAuthCodeFlowV2] Loading credentials from storage before token exchange');
      const storedCredentials = credentialManager.loadAuthzFlowCredentials();
      if (storedCredentials) {
        const convertedCredentials = {
          clientId: storedCredentials.clientId,
          clientSecret: storedCredentials.clientSecret || '',
          environmentId: storedCredentials.environmentId,
          authorizationEndpoint: storedCredentials.authEndpoint || '',
          tokenEndpoint: storedCredentials.tokenEndpoint || '',
          userInfoEndpoint: storedCredentials.userInfoEndpoint || '',
          redirectUri: storedCredentials.redirectUri,
          scopes: storedCredentials.scopes.join(' '),
          responseType: 'code',
          codeChallengeMethod: 'S256'
        };
        setCredentials(convertedCredentials);
        currentCredentials = convertedCredentials;
        console.log('✅ [EnhancedAuthCodeFlowV2] Loaded credentials from storage:', {
          clientId: storedCredentials.clientId ? `${storedCredentials.clientId.substring(0, 8)}...` : 'none',
          environmentId: storedCredentials.environmentId
        });
      }
    }

    // MANDATORY CREDENTIAL VALIDATION - This is the key fix
    console.log('🔍 [EnhancedAuthCodeFlowV2] Validating credentials before token exchange...');
    
    // Check if we have valid credentials in state
    if (!currentCredentials.clientId || currentCredentials.clientId.trim() === '') {
      console.error('❌ [EnhancedAuthCodeFlowV2] No valid client ID found in credentials state');
      throw new Error('Client ID is required for token exchange. Please configure your OAuth credentials first.');
    }
    
    if (!currentCredentials.environmentId || currentCredentials.environmentId.trim() === '') {
      console.error('❌ [EnhancedAuthCodeFlowV2] No valid environment ID found in credentials state');
      throw new Error('Environment ID is missing. Please configure your OAuth credentials first.');
    }
    
    if (!currentCredentials.redirectUri || currentCredentials.redirectUri.trim() === '') {
      console.error('❌ [EnhancedAuthCodeFlowV2] No valid redirect URI found in credentials state');
      throw new Error('Redirect URI is missing. Please configure your OAuth credentials first.');
    }

    console.log('✅ [EnhancedAuthCodeFlowV2] Credentials validation passed:', {
      clientId: currentCredentials.clientId ? `${currentCredentials.clientId.substring(0, 8)}...` : 'none',
      environmentId: currentCredentials.environmentId,
      redirectUri: currentCredentials.redirectUri
    });

    // Add a small delay to ensure all state is properly set
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // Check if we have authorization code, if not try to load from sessionStorage
    let currentAuthCode = authCode;
    if (!currentAuthCode) {
      const storedCode = sessionStorage.getItem('oauth_auth_code');
      if (storedCode) {
        console.log('🔧 [EnhancedAuthCodeFlowV2] Loading authorization code from sessionStorage');
        currentAuthCode = storedCode;
        // Update the state
        setAuthCode(storedCode);
      }
    }

    // Final validation with detailed error messages
    console.log('🔍 [EnhancedAuthCodeFlowV2] Final validation before exchange:', {
      hasAuthCode: !!currentAuthCode,
      hasClientId: !!currentCredentials.clientId,
      hasEnvironmentId: !!currentCredentials.environmentId,
      hasRedirectUri: !!currentCredentials.redirectUri,
      clientId: currentCredentials.clientId ? `${currentCredentials.clientId.substring(0, 8)}...` : 'none'
    });
    
    if (!currentAuthCode) {
      throw new Error('No authorization code available for token exchange');
    }
    if (!currentCredentials.clientId) {
      throw new Error('OAuth credentials are missing. Please go back to Step 1 and save your credentials first, then restart the OAuth flow.');
    }
    if (!currentCredentials.environmentId) {
      throw new Error('Environment ID is missing. Please go back to Step 1 and save your credentials first, then restart the OAuth flow.');
    }
    if (!currentCredentials.redirectUri) {
      throw new Error('Redirect URI is missing. Please go back to Step 1 and save your credentials first, then restart the OAuth flow.');
    }

    // Check if we've already used this authorization code
    if (usedAuthCode === currentAuthCode) {
      throw new Error('This authorization code has already been used. Please start a new OAuth flow.');
    }
    
    // Check if we have PKCE codes, if not try to load from sessionStorage
    let codeVerifier = pkceCodes.codeVerifier;
    console.log('🔍 [EnhancedAuthCodeFlowV2] PKCE code verifier check:', {
      fromState: pkceCodes.codeVerifier ? `${pkceCodes.codeVerifier.substring(0, 10)}...` : 'none',
      fromSessionStorage: sessionStorage.getItem('code_verifier') ? `${sessionStorage.getItem('code_verifier')?.substring(0, 10)}...` : 'none'
    });
    
    if (!codeVerifier) {
      const storedVerifier = sessionStorage.getItem('code_verifier');
      if (storedVerifier) {
        console.log('🔧 [EnhancedAuthCodeFlowV2] Loading code verifier from sessionStorage');
        codeVerifier = storedVerifier;
        // Update the state
        setPkceCodes(prev => ({ ...prev, codeVerifier: storedVerifier }));
      }
    }
    
    if (!codeVerifier) {
      console.error('❌ [EnhancedAuthCodeFlowV2] No code verifier found in state or sessionStorage');
      throw new Error('Code verifier is required for PKCE token exchange. Please go back to Step 2 and generate PKCE codes first.');
    }

    try {
      setIsExchangingTokens(true);
      
      // Store the auth code for validation but don't clear it yet
      setUsedAuthCode(currentAuthCode);
      console.log('🔐 [EnhancedAuthCodeFlowV2] Using authorization code for token exchange:', currentAuthCode.substring(0, 10) + '...');
      
      // FINAL VALIDATION - This is the last chance to catch empty values
      console.log('🔍 [EnhancedAuthCodeFlowV2] Final validation before request body construction:', {
        clientId: currentCredentials.clientId,
        clientIdLength: currentCredentials.clientId?.length || 0,
        environmentId: currentCredentials.environmentId,
        redirectUri: currentCredentials.redirectUri
      });

      if (!currentCredentials.clientId || currentCredentials.clientId.trim() === '') {
        console.error('❌ [EnhancedAuthCodeFlowV2] CRITICAL: clientId is empty in request body construction!');
        throw new Error('CRITICAL ERROR: Client ID is empty. This should not happen after validation.');
      }

      if (!currentCredentials.environmentId || currentCredentials.environmentId.trim() === '') {
        console.error('❌ [EnhancedAuthCodeFlowV2] CRITICAL: environmentId is empty in request body construction!');
        throw new Error('CRITICAL ERROR: Environment ID is empty. This should not happen after validation.');
      }

      if (!currentCredentials.redirectUri || currentCredentials.redirectUri.trim() === '') {
        console.error('❌ [EnhancedAuthCodeFlowV2] CRITICAL: redirectUri is empty in request body construction!');
        throw new Error('CRITICAL ERROR: Redirect URI is empty. This should not happen after validation.');
      }

      // Use backend proxy for secure token exchange
      const backendUrl = process.env.NODE_ENV === 'production' 
        ? 'https://oauth-playground.vercel.app' 
        : 'http://localhost:3001';
      
      const requestBody = {
          grant_type: 'authorization_code',
        client_id: currentCredentials.clientId.trim(), // Ensure no whitespace
        client_secret: currentCredentials.clientSecret || '',
          code: currentAuthCode,
          redirect_uri: currentCredentials.redirectUri.trim(), // Ensure no whitespace
        environment_id: currentCredentials.environmentId.trim(), // Ensure no whitespace
        code_verifier: codeVerifier
      };

      console.log('🔄 [EnhancedAuthCodeFlowV2] Token exchange via backend proxy:', {
        backendUrl,
        clientId: currentCredentials.clientId,
        code: currentAuthCode.substring(0, 10) + '...',
        redirectUri: currentCredentials.redirectUri
      });

      console.log('🔍 [EnhancedAuthCodeFlowV2] Request body being sent:', {
        grant_type: requestBody.grant_type,
        client_id: requestBody.client_id ? `${requestBody.client_id.substring(0, 8)}...` : 'none',
        client_id_length: requestBody.client_id?.length || 0,
        client_id_empty: requestBody.client_id === '',
        has_client_secret: !!requestBody.client_secret,
        code: requestBody.code ? `${requestBody.code.substring(0, 10)}...` : 'none',
        redirect_uri: requestBody.redirect_uri,
        environment_id: requestBody.environment_id,
        has_code_verifier: !!requestBody.code_verifier
      });
      
      console.log('🔍 [EnhancedAuthCodeFlowV2] Full request body for debugging:', JSON.stringify(requestBody, null, 2));

      // CRITICAL: Final check before sending
      if (requestBody.client_id === '' || !requestBody.client_id) {
        console.error('❌ [EnhancedAuthCodeFlowV2] CRITICAL: Request body has empty client_id!', requestBody);
        throw new Error('CRITICAL ERROR: Request body contains empty client_id. This should never happen.');
      }

      console.log('🌐 [EnhancedAuthCodeFlowV2] Sending request to:', `${backendUrl}/api/token-exchange`);
      
      const response = await fetch(`${backendUrl}/api/token-exchange`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody)
      });

      console.log('📡 [EnhancedAuthCodeFlowV2] Response received:', {
        status: response.status,
        statusText: response.statusText,
        ok: response.ok
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        logger.error('EnhancedAuthorizationCodeFlowV2', 'Token exchange failed', { status: response.status, error: errorData });
        
        // Use PingOne error interpreter for friendly messages
        const interpretedError = PingOneErrorInterpreter.interpret({
          error: errorData.error || 'token_exchange_failed',
          error_description: errorData.error_description || errorData.details || `HTTP ${response.status}: ${response.statusText}`,
          details: errorData
        });
        
        throw new Error(`${interpretedError.title}: ${interpretedError.message}${interpretedError.suggestion ? `\n\nSuggestion: ${interpretedError.suggestion}` : ''}`);
      }

      const tokenData = await response.json();
      setTokens(tokenData);
      logger.info('EnhancedAuthorizationCodeFlowV2', 'Tokens received', tokenData);
      
      // Store tokens in localStorage for Token Management page to access
      const tokensForStorage = {
        access_token: tokenData.access_token,
        id_token: tokenData.id_token,
        refresh_token: tokenData.refresh_token,
        token_type: tokenData.token_type || 'Bearer',
        expires_in: tokenData.expires_in,
        scope: tokenData.scope || 'openid profile email',
        expires_at: tokenData.expires_in ? new Date(Date.now() + (tokenData.expires_in * 1000)).toISOString() : undefined
      };
      
      localStorage.setItem('oauth_tokens', JSON.stringify(tokensForStorage));
      console.log('✅ [EnhancedAuthorizationCodeFlowV2] Tokens stored in localStorage for Token Management page');
      
      setIsExchangingTokens(false);
      
      // Show centralized success message for token exchange
      showTokenExchangeSuccess();
      scrollToTopAfterAction('Token Exchange');
      
      // Clear the authorization code and state after successful exchange to prevent reuse
      setAuthCode('');
      sessionStorage.removeItem('oauth_auth_code');
      sessionStorage.removeItem('oauth_state');
      console.log('🧹 [EnhancedAuthCodeFlowV2] Cleared authorization code and state after successful exchange');
    } catch (error) {
      logger.error('EnhancedAuthorizationCodeFlowV2', 'Token exchange failed', String(error));
      setIsExchangingTokens(false);
      
      const errorMsg = error instanceof Error ? error.message : String(error);
      
      // Show centralized error message
      showTokenExchangeError(errorMsg);
      
      // Show error message
      updateStepMessage('exchange-tokens', `❌ Token exchange failed: ${errorMsg}`);
      
      // Provide more specific error messages
      if (String(error).includes('Invalid Grant')) {
        // Show a more helpful message for Invalid Grant errors
        updateStepMessage('exchange-tokens', '❌ Authorization code has expired or been used already. Click "Clear & Start Fresh" below to begin a new OAuth flow.');
        throw new Error('Authorization code has expired or been used already. Please start a new OAuth flow to get a fresh authorization code.');
      } else if (String(error).includes('Client ID is required')) {
        throw new Error('OAuth credentials are missing. Please go back to Step 1 and save your credentials first.');
      } else if (String(error).includes('Code verifier is required')) {
        throw new Error('PKCE codes are missing. Please go back to Step 2 and generate PKCE codes first.');
      } else {
        throw error;
      }
    }
  }, [credentials, authCode, pkceCodes.codeVerifier]);

  // Get user info
  const getUserInfo = useCallback(async () => {
    if (!tokens?.access_token) {
      throw new Error('No access token available');
    }

    setIsGettingUserInfo(true);
    try {
      const response = await fetch(credentials.userInfoEndpoint, {
        headers: {
          'Authorization': `Bearer ${tokens.access_token}`
        }
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        logger.error('EnhancedAuthorizationCodeFlowV2', 'UserInfo request failed', { status: response.status, error: errorData });
        
        // Use PingOne error interpreter for friendly messages
        const interpretedError = PingOneErrorInterpreter.interpret({
          error: errorData.error || 'userinfo_request_failed',
          error_description: errorData.error_description || errorData.details || `HTTP ${response.status}: ${response.statusText}`,
          details: errorData
        });
        
        throw new Error(`${interpretedError.title}: ${interpretedError.message}${interpretedError.suggestion ? `\n\nSuggestion: ${interpretedError.suggestion}` : ''}`);
      }

      const userData = await response.json();
      setUserInfo(userData);
      logger.info('EnhancedAuthorizationCodeFlowV2', 'User info retrieved', userData);
      
      // Scroll to step progress to show the user info
      scrollToStepProgress();
    } catch (error) {
      logger.error('EnhancedAuthorizationCodeFlowV2', 'UserInfo request failed', String(error));
      const errorMsg = error instanceof Error ? error.message : String(error);
      showUserInfoError(errorMsg);
      throw error;
    } finally {
      setIsGettingUserInfo(false);
    }
  }, [credentials.userInfoEndpoint, tokens]);

  // Copy to clipboard
  const copyToClipboard = useCallback(async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedText(text);
      setTimeout(() => setCopiedText(null), 2000);
    } catch (error) {
      logger.error('EnhancedAuthorizationCodeFlowV2', 'Failed to copy to clipboard', String(error));
    }
  }, []);

  // Validate credentials
  const validateCredentials = useCallback(() => {
    return credentials.clientId && credentials.environmentId && credentials.authorizationEndpoint;
  }, [credentials]);

  // Auto-generate endpoints
  useEffect(() => {
    if (credentials.environmentId) {
      const baseUrl = `https://auth.pingone.com/${credentials.environmentId}`;
      setCredentials(prev => ({
        ...prev,
        authorizationEndpoint: `${baseUrl}/as/authorize`,
        tokenEndpoint: `${baseUrl}/as/token`,
        userInfoEndpoint: `${baseUrl}/as/userinfo`
      }));
    }
  }, [credentials.environmentId]);

  // Define steps
  const steps: EnhancedFlowStep[] = [
    {
      id: 'setup-credentials',
      title: 'Setup OAuth Credentials',
      description: 'Configure your PingOne OAuth application credentials. These will be saved securely for future sessions.',
      icon: <FiSettings />,
      category: 'preparation',
      content: (
        <div>
          <div 
            style={{ 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'space-between',
              cursor: 'pointer',
              padding: '0.5rem 0',
              borderBottom: '1px solid #e5e7eb',
              marginBottom: '1rem'
            }}
            onClick={() => toggleSection('setup-credentials')}
          >
            <h4 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              OAuth Credentials Configuration
            </h4>
            {collapsedSections['setup-credentials'] ? <FiChevronRight /> : <FiChevronDown />}
          </div>
          {!collapsedSections['setup-credentials'] && (
            <div>
              {stepMessages['setup-credentials'] && (
                <InfoBox type="success">
                  <div>{stepMessages['setup-credentials']}</div>
                </InfoBox>
              )}
              
              {/* Display saved results when step is completed */}
              {hasStepResult('setup-credentials') && (
                <div style={{
                  padding: '1rem',
                  backgroundColor: '#f0f9ff',
                  border: '1px solid #bae6fd',
                  borderRadius: '0.5rem',
                  marginBottom: '1rem'
                }}>
                  <h4 style={{ margin: '0 0 0.75rem 0', color: '#0369a1', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <FiCheckCircle />
                    ✅ Credentials Saved Successfully
                  </h4>
                  <div style={{ fontSize: '0.875rem', color: '#0c4a6e' }}>
                    <div><strong>Environment ID:</strong> {(getStepResult('setup-credentials') as any)?.credentials?.environmentId || 'Not provided'}</div>
                    <div><strong>Client ID:</strong> {(getStepResult('setup-credentials') as any)?.credentials?.clientId || 'Not provided'}</div>
                    <div><strong>Client Secret:</strong> {(getStepResult('setup-credentials') as any)?.credentials?.clientSecret ? '••••••••••••' : 'Not provided'}</div>
                    <div><strong>Redirect URI:</strong> {(getStepResult('setup-credentials') as any)?.credentials?.redirectUri || 'Not provided'}</div>
                    <div><strong>Saved:</strong> {new Date((getStepResult('setup-credentials') as any)?.timestamp || '').toLocaleString()}</div>
                  </div>
                </div>
              )}
              <FormField>
            <FormLabel className="required">Environment ID</FormLabel>
            <FormInput
              type="text"
              value={credentials.environmentId}
              onChange={(e) => setCredentials(prev => ({ ...prev, environmentId: e.target.value }))}
              placeholder="your-environment-id"
              required
            />
            <ValidationIndicator $valid={!!credentials.environmentId}>
              {credentials.environmentId ? <FiCheckCircle /> : <FiAlertTriangle />}
              {credentials.environmentId ? 'Valid Environment ID' : 'Environment ID is required'}
            </ValidationIndicator>
          </FormField>

          <FormField>
            <FormLabel className="required">Client ID</FormLabel>
            <FormInput
              type="text"
              value={credentials.clientId}
              onChange={(e) => setCredentials(prev => ({ ...prev, clientId: e.target.value }))}
              placeholder="12345678-1234-1234-1234-123456789012"
              required
            />
            <ValidationIndicator $valid={!!credentials.clientId}>
              {credentials.clientId ? <FiCheckCircle /> : <FiAlertTriangle />}
              {credentials.clientId ? 'Valid Client ID' : 'Client ID is required'}
            </ValidationIndicator>
          </FormField>

          <FormField>
            <FormLabel>Client Secret</FormLabel>
            <div style={{ position: 'relative' }}>
            <FormInput
                type={showSecret ? 'text' : 'password'}
              value={credentials.clientSecret || ''}
              onChange={(e) => setCredentials(prev => ({ ...prev, clientSecret: e.target.value }))}
              placeholder="your-client-secret (optional for PKCE)"
                style={{ paddingRight: '3rem' }}
                autoComplete="new-password"
              />
              <button
                type="button"
                onClick={() => setShowSecret(!showSecret)}
                style={{
                  position: 'absolute',
                  right: '0.75rem',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  color: '#6c757d',
                  padding: '0.25rem',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
                aria-label={showSecret ? 'Hide client secret' : 'Show client secret'}
                title={showSecret ? 'Hide client secret' : 'Show client secret'}
              >
                {showSecret ? <FiEyeOff size={18} /> : <FiEye size={18} />}
              </button>
            </div>
            <ValidationIndicator $valid={true}>
              <FiInfo />
              Optional for PKCE flows, required for confidential clients
            </ValidationIndicator>
          </FormField>

          <FormField>
            <FormLabel className="required">Callback URL</FormLabel>
            <div style={{ position: 'relative' }}>
              <FormInput
                type="url"
                value={credentials.redirectUri}
                onChange={(e) => setCredentials(prev => ({ ...prev, redirectUri: e.target.value }))}
                placeholder="https://localhost:3000/authz-callback"
                required
                style={{ 
                  paddingRight: '2.5rem',
                  fontFamily: 'monospace',
                  fontSize: '0.875rem'
                }}
              />
              <div style={{
                position: 'absolute',
                right: '0.75rem',
                top: '50%',
                transform: 'translateY(-50%)',
                color: '#6b7280',
                fontSize: '0.75rem',
                pointerEvents: 'none'
              }}>
                ✏️
              </div>
            </div>
            <ValidationIndicator $valid={!!credentials.redirectUri}>
              {credentials.redirectUri ? <FiCheckCircle /> : <FiAlertTriangle />}
              {credentials.redirectUri ? 'Valid Callback URL' : 'Callback URL is required'}
            </ValidationIndicator>
          </FormField>

          <FormField>
            <FormLabel>Authorization Endpoint</FormLabel>
            <FormInput
              type="text"
              value={credentials.authorizationEndpoint}
              readOnly
            />
            <ValidationIndicator $valid={!!credentials.authorizationEndpoint}>
              <FiInfo />
              Auto-generated from Environment ID
            </ValidationIndicator>
          </FormField>

          <FormField>
            <FormLabel>Scopes</FormLabel>
            <FormInput
              type="text"
              value={credentials.scopes}
              onChange={(e) => setCredentials(prev => ({ ...prev, scopes: e.target.value }))}
              placeholder="openid profile email"
            />
          </FormField>

          <FormField>
            <FormLabel>Response Type</FormLabel>
            <FormSelect
              value={credentials.responseType}
              onChange={(e) => setCredentials(prev => ({ ...prev, responseType: e.target.value }))}
            >
              <option value="code">code (Authorization Code Flow)</option>
            </FormSelect>
          </FormField>

          <InfoBox type="info">
            <FiInfo />
            <div>
              <strong>Security Note:</strong> Your credentials will be saved locally in your browser and are not transmitted to any external servers.
            </div>
          </InfoBox>

          {isSavingCredentials && (
            <InfoBox type="info">
              <FiLoader className="animate-spin" />
              <div>
                <strong>🔄 Saving Credentials...</strong>
                <br />
                Securely storing your OAuth credentials for future sessions...
              </div>
            </InfoBox>
          )}

          {credentialsSaved && (
            <InfoBox type="success">
              <FiCheckCircle />
              <div>
                <strong>✅ Credentials Saved Successfully!</strong>
                <br />
                Your OAuth credentials have been saved and are ready to use. You can now proceed to the next step.
              </div>
            </InfoBox>
          )}

          {/* Flow Control Actions - Combined Box */}
          <div style={{ 
            marginTop: '2rem', 
            padding: '1.5rem', 
            backgroundColor: '#fef2f2', 
            border: '1px solid #fecaca', 
            borderRadius: '0.5rem'
          }}>
            <h4 style={{ margin: '0 0 1rem 0', color: '#dc2626', fontSize: '1rem', textAlign: 'center' }}>
              <FiSettings style={{ marginRight: '0.5rem' }} />
              Flow Control Actions
            </h4>
            
            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              {/* Clear Credentials Button */}
              <div style={{ textAlign: 'center', flex: '1', minWidth: '200px' }}>
                <h5 style={{ margin: '0 0 0.5rem 0', color: '#dc2626', fontSize: '0.875rem' }}>
                  Clear Credentials
                </h5>
                <p style={{ margin: '0 0 1rem 0', color: '#6b7280', fontSize: '0.75rem' }}>
                  Remove all saved PingOne credentials and start fresh
                </p>
                <button
                  onClick={() => setShowClearCredentialsModal(true)}
                  style={{
                    padding: '0.5rem 1rem',
                    backgroundColor: '#dc2626',
                    color: 'white',
                    border: 'none',
                    borderRadius: '0.375rem',
                    fontSize: '0.8rem',
                    fontWeight: '500',
                    cursor: 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    transition: 'background-color 0.2s'
                  }}
                  onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#b91c1c'}
                  onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#dc2626'}
                >
                  <FiSettings />
                  Clear Credentials
                </button>
              </div>

              {/* Reset Flow Button */}
              <div style={{ textAlign: 'center', flex: '1', minWidth: '200px' }}>
                <h5 style={{ margin: '0 0 0.5rem 0', color: '#dc2626', fontSize: '0.875rem' }}>
                  Reset Flow
                </h5>
                <p style={{ margin: '0 0 1rem 0', color: '#6b7280', fontSize: '0.75rem' }}>
                  Clear flow progress and tokens (credentials preserved)
                </p>
                <button
                  onClick={() => setShowResetModal(true)}
                  style={{
                    padding: '0.5rem 1rem',
                    backgroundColor: '#dc2626',
                    color: 'white',
                    border: 'none',
                    borderRadius: '0.375rem',
                    fontSize: '0.8rem',
                    fontWeight: '500',
                    cursor: 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    transition: 'background-color 0.2s'
                  }}
                  onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#b91c1c'}
                  onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#dc2626'}
                >
                  <FiRefreshCw />
                  Reset Flow
                </button>
              </div>
            </div>
          </div>
            </div>
          )}
        </div>
      ),
      execute: async () => {
        setIsSavingCredentials(true);
        try {
        await saveCredentials();
        const result = { 
          credentials: { ...credentials },
          timestamp: new Date().toISOString(),
          success: true 
        };
        saveStepResult('setup-credentials', result);
        markStepCompleted(0); // Mark step 0 as completed
        return { success: true };
        } finally {
          setIsSavingCredentials(false);
        }
      },
      canExecute: Boolean(credentials.environmentId && credentials.clientId && credentials.redirectUri)
    },
    {
      id: 'generate-pkce',
      title: 'Generate PKCE Codes',
      description: 'PKCE adds security by preventing authorization code interception attacks. This step is optional but recommended for enhanced security.',
      icon: <FiShield />,
      category: 'preparation',
      isOptional: true,
      content: (
        <div>

          <CodeBlock>
            <CodeComment>// How PKCE Codes Are Used in OAuth Flow</CodeComment>
            <CodeComment>// Step 1: Authorization Request (with code_challenge)</CodeComment>
            <CodeLine>GET /as/authorize?response_type=code&client_id=...&code_challenge={pkceCodes.codeChallenge || '[CODE_CHALLENGE]'}&code_challenge_method=S256</CodeLine>
            <CodeComment>// Step 2: Authorization Server returns authorization code</CodeComment>
            <CodeLine>redirect_uri?code=[AUTHORIZATION_CODE]&state=[STATE]</CodeLine>
            <CodeComment>// Step 3: Token Exchange (with code_verifier)</CodeComment>
            <CodeLine>POST /as/token</CodeLine>
            <CodeLine>grant_type=authorization_code&code=[AUTHORIZATION_CODE]&code_verifier={pkceCodes.codeVerifier || '[CODE_VERIFIER]'}</CodeLine>
            <CodeComment>// Step 4: Server validates: SHA256(code_verifier) === code_challenge</CodeComment>
          </CodeBlock>

          <InfoBox type="info">
            <FiInfo />
            <div>
              <strong>How PKCE Codes Are Used (OIDC Specification):</strong>
              <br /><br />
              <strong>1. Authorization Request:</strong> The <code>code_challenge</code> is sent to the authorization server in the initial request.
              <br /><br />
              <strong>2. Token Exchange:</strong> The <code>code_verifier</code> is sent back to the token endpoint to prove you initiated the request.
              <br /><br />
              <strong>3. Security Benefit:</strong> Even if an attacker intercepts the authorization code, they cannot exchange it for tokens without the code verifier.
              <br /><br />
              <strong>OIDC Compliance:</strong> PKCE is required for public clients (mobile apps, SPAs) and recommended for all clients per RFC 7636.
            </div>
          </InfoBox>

          <InfoBox type="info">
            <FiShield />
            <div>
              <strong>Security Note:</strong> PKCE codes are automatically generated and will be used in the authorization request to enhance security.
            </div>
          </InfoBox>

          {isGeneratingPKCE && (
            <InfoBox type="info">
              <FiLoader className="animate-spin" />
              <div>
                <strong>🔄 Generating PKCE Codes...</strong>
                <br />
                Creating secure code verifier and challenge for enhanced OAuth security...
              </div>
            </InfoBox>
          )}

          {isSavingCredentials && (
            <InfoBox type="info">
              <FiLoader className="animate-spin" />
              <div>
                <strong>🔄 Saving Credentials...</strong>
                <br />
                Storing your PingOne configuration securely.
              </div>
            </InfoBox>
          )}

          {/* Display saved results when step is completed */}
          {hasStepResult('generate-pkce') && (
            <div style={{
              padding: '1rem',
              backgroundColor: '#f0f9ff',
              border: '1px solid #bae6fd',
              borderRadius: '0.5rem',
              marginBottom: '1rem'
            }}>
              <h4 style={{ margin: '0 0 0.75rem 0', color: '#0369a1', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <FiCheckCircle />
                ✅ PKCE Codes Generated Successfully
              </h4>
              <div style={{ fontSize: '0.875rem', color: '#0c4a6e' }}>
                <div><strong>Code Verifier:</strong> {(getStepResult('generate-pkce') as any)?.pkceCodes?.codeVerifier?.substring(0, 20) + '...' || 'Not available'}</div>
                <div><strong>Code Challenge:</strong> {(getStepResult('generate-pkce') as any)?.pkceCodes?.codeChallenge?.substring(0, 20) + '...' || 'Not available'}</div>
                <div><strong>Method:</strong> S256 (SHA256)</div>
                <div><strong>Generated:</strong> {new Date((getStepResult('generate-pkce') as any)?.timestamp || '').toLocaleString()}</div>
              </div>
            </div>
          )}

          {/* Generated PKCE Codes - Display at bottom */}
          {pkceGenerated && pkceCodes.codeVerifier && (
            <div style={{ 
              marginTop: '2rem', 
              padding: '1.5rem', 
              background: '#f0fdf4', 
              border: '1px solid #10b981', 
              borderRadius: '0.5rem' 
            }}>
              <h4 style={{ margin: '0 0 1rem 0', color: '#065f46' }}>Generated PKCE Codes</h4>
              
          <FormField>
            <FormLabel>Code Verifier (Generated)</FormLabel>
            <FormInput
              type="text"
              value={pkceCodes.codeVerifier}
              readOnly
                  $generated={!!pkceCodes.codeVerifier}
            />
              <CopyButton onClick={() => copyToClipboard(pkceCodes.codeVerifier)}>
                {copiedText === pkceCodes.codeVerifier ? <FiCheckCircle /> : <FiCopy />}
              </CopyButton>
          </FormField>

          <FormField>
            <FormLabel>Code Challenge (SHA256)</FormLabel>
            <FormInput
              type="text"
              value={pkceCodes.codeChallenge}
              readOnly
                  $generated={!!pkceCodes.codeChallenge}
            />
              <CopyButton onClick={() => copyToClipboard(pkceCodes.codeChallenge)}>
                {copiedText === pkceCodes.codeChallenge ? <FiCheckCircle /> : <FiCopy />}
              </CopyButton>
          </FormField>
            </div>
          )}

          {/* Reset Flow Button */}
          <div style={{ 
            marginTop: '2rem', 
            padding: '1rem', 
            backgroundColor: '#fef2f2', 
            border: '1px solid #fecaca', 
            borderRadius: '0.5rem',
            textAlign: 'center'
          }}>
            <h4 style={{ margin: '0 0 0.5rem 0', color: '#dc2626', fontSize: '0.875rem' }}>
              <FiRefreshCw style={{ marginRight: '0.5rem' }} />
              Need to Start Over?
            </h4>
            <p style={{ margin: '0 0 1rem 0', color: '#6b7280', fontSize: '0.8rem' }}>
              Clear flow progress and tokens (credentials preserved)
            </p>
            <button
              onClick={() => setShowResetModal(true)}
              style={{
                padding: '0.5rem 1rem',
                backgroundColor: '#dc2626',
                color: 'white',
                border: 'none',
                borderRadius: '0.375rem',
                fontSize: '0.8rem',
                fontWeight: '500',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                transition: 'background-color 0.2s'
              }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#b91c1c'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#dc2626'}
            >
              <FiRefreshCw />
              Reset Flow
            </button>
          </div>
        </div>
      ),
      execute: async () => {
        setIsGeneratingPKCE(true);
        try {
          const { challenge } = await generatePKCECodes();
          setPkceGenerated(true);
          // Regenerate authorization URL with PKCE codes
          generateAuthUrl();
          
          // Step message disabled - using bottom banner instead
          // updateStepMessage('generate-pkce', '✅ PKCE codes generated successfully! Your codes are ready to use for enhanced security.');
          
          const result = { 
            pkceCodes,
            challenge,
            timestamp: new Date().toISOString(),
            success: true 
          };
          saveStepResult('generate-pkce', result);
          markStepCompleted(1); // Mark step 1 as completed
          return { success: true };
        } finally {
          setIsGeneratingPKCE(false);
        }
      },
      canExecute: Boolean(credentials.environmentId && credentials.clientId && credentials.redirectUri)
    },
    {
      id: 'build-auth-url',
      title: 'Build Authorization URL',
      description: 'Construct the complete authorization URL with all required OAuth parameters.',
      icon: <FiGlobe />,
      category: 'authorization',
      content: (
        <div>
          {stepMessages['build-auth-url'] && (
            <InfoBox type="success">
              <div>{stepMessages['build-auth-url']}</div>
            </InfoBox>
          )}
          
          {/* Display saved results when step is completed */}
          {hasStepResult('build-auth-url') && (
            <div style={{
              padding: '1rem',
              backgroundColor: '#f0f9ff',
              border: '1px solid #bae6fd',
              borderRadius: '0.5rem',
              marginBottom: '1rem'
            }}>
              <h4 style={{ margin: '0 0 0.75rem 0', color: '#0369a1', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <FiCheckCircle />
                ✅ Authorization URL Built Successfully
              </h4>
              <div style={{ fontSize: '0.875rem', color: '#0c4a6e' }}>
                <div><strong>URL:</strong> <span style={{ fontFamily: 'monospace', wordBreak: 'break-all' }}>{(getStepResult('build-auth-url') as any)?.authUrl?.substring(0, 80) + '...' || 'Not available'}</span></div>
                <div><strong>Built:</strong> {new Date((getStepResult('build-auth-url') as any)?.timestamp || '').toLocaleString()}</div>
              </div>
            </div>
          )}

          {urlGenerated && (
            <InfoBox type="success">
              <FiCheckCircle />
              <div>
                <strong>✅ Authorization URL Generated Successfully!</strong>
                <br />
                Your authorization URL has been built with all required OAuth parameters. You can now proceed to redirect the user to PingOne for authentication.
              </div>
            </InfoBox>
          )}

          <CodeBlock>
            <CodeComment>// Authorization URL for Authorization Code Flow</CodeComment>
            <CodeLine>
              const authUrl = '{authUrl || 'Click "Build URL" to generate the authorization URL'}';
            </CodeLine>
            <CodeComment>// Parameters:</CodeComment>
            <CodeLine>response_type: '{credentials.responseType}'</CodeLine>
            <CodeLine>client_id: '{credentials.clientId}'</CodeLine>
            <CodeLine>redirect_uri: '{credentials.redirectUri}'</CodeLine>
            <CodeLine>scope: '{credentials.scopes}'</CodeLine>
            <CodeLine>state: '{state}'</CodeLine>
            <CodeLine>code_challenge: '{pkceCodes.codeChallenge}'</CodeLine>
            <CodeLine>code_challenge_method: '{credentials.codeChallengeMethod}'</CodeLine>
          </CodeBlock>



          {isBuildingUrl && (
            <InfoBox type="info">
              <FiLoader className="animate-spin" />
              <div>
                <strong>🔄 Building Authorization URL...</strong>
                <br />
                Constructing the complete authorization URL with all required parameters.
              </div>
            </InfoBox>
          )}

          {/* Generated Authorization URL Results - Display at bottom */}
          {urlGenerated && authUrl && (
            <div style={{ 
              marginTop: '2rem', 
              padding: '1.5rem', 
              background: '#f0fdf4', 
              border: '1px solid #22c55e', 
              borderRadius: '0.5rem' 
            }}>
              <h4 style={{ margin: '0 0 1rem 0', color: '#15803d' }}>Generated Authorization URL</h4>
              
              <div style={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: '0.5rem', 
                padding: '0.75rem', 
                backgroundColor: '#f0fdf4', 
                border: '1px solid #22c55e', 
                borderRadius: '0.5rem',
                marginBottom: '1rem'
              }}>
                <code style={{ 
                  flex: 1, 
                  fontSize: '0.875rem', 
                  color: '#495057', 
                  wordBreak: 'break-all' 
                }}>
                  {authUrl}
                </code>
                <button
                  onClick={() => copyToClipboard(authUrl)}
                  style={{
                    background: 'none',
                    border: '1px solid #007bff',
                    color: '#007bff',
                    cursor: 'pointer',
                    padding: '0.25rem 0.5rem',
                    borderRadius: '4px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.25rem'
                  }}
                >
                  {copiedText === authUrl ? <FiCheckCircle size={16} /> : <FiCopy size={16} />}
                </button>
              </div>

            <FormField>
              <FormLabel>URL Components (JSON)</FormLabel>
              <JsonDisplay>
                {JSON.stringify({
                  baseUrl: credentials.authorizationEndpoint,
                  response_type: credentials.responseType,
                  client_id: credentials.clientId,
                  redirect_uri: credentials.redirectUri,
                  scope: credentials.scopes,
                  state: state,
                  code_challenge: pkceCodes.codeChallenge,
                  code_challenge_method: credentials.codeChallengeMethod
                }, null, 2)}
                <CopyButton onClick={() => copyToClipboard(JSON.stringify({
                  baseUrl: credentials.authorizationEndpoint,
                  response_type: credentials.responseType,
                  client_id: credentials.clientId,
                  redirect_uri: credentials.redirectUri,
                  scope: credentials.scopes,
                  state: state,
                  code_challenge: pkceCodes.codeChallenge,
                  code_challenge_method: credentials.codeChallengeMethod
                }, null, 2))}>
                  {copiedText === JSON.stringify({
                    baseUrl: credentials.authorizationEndpoint,
                    response_type: credentials.responseType,
                    client_id: credentials.clientId,
                    redirect_uri: credentials.redirectUri,
                    scope: credentials.scopes,
                    state: state,
                    code_challenge: pkceCodes.codeChallenge,
                    code_challenge_method: credentials.codeChallengeMethod
                  }, null, 2) ? <FiCheckCircle /> : <FiCopy />}
                </CopyButton>
              </JsonDisplay>
            </FormField>

            <ParameterBreakdown>
              <h4>Parameter Breakdown:</h4>
              <ParameterItem>
                <ParameterName>response_type</ParameterName>
                <ParameterValue>code (Authorization Code Flow)</ParameterValue>
              </ParameterItem>
              <ParameterItem>
                <ParameterName>client_id</ParameterName>
                <ParameterValue>{credentials.clientId}</ParameterValue>
              </ParameterItem>
              <ParameterItem>
                <ParameterName>redirect_uri</ParameterName>
                <ParameterValue>{credentials.redirectUri}</ParameterValue>
              </ParameterItem>
              <ParameterItem>
                <ParameterName>scope</ParameterName>
                <ParameterValue>{credentials.scopes}</ParameterValue>
              </ParameterItem>
              <ParameterItem>
                <ParameterName>state</ParameterName>
                <ParameterValue>{state}</ParameterValue>
              </ParameterItem>
              <ParameterItem>
                <ParameterName>code_challenge</ParameterName>
                <ParameterValue>{pkceCodes.codeChallenge}</ParameterValue>
              </ParameterItem>
              <ParameterItem>
                <ParameterName>code_challenge_method</ParameterName>
                <ParameterValue>{credentials.codeChallengeMethod}</ParameterValue>
              </ParameterItem>
            </ParameterBreakdown>
            </div>
          )}

          {/* Reset Flow Button */}
          <div style={{ 
            marginTop: '2rem', 
            padding: '1rem', 
            backgroundColor: '#fef2f2', 
            border: '1px solid #fecaca', 
            borderRadius: '0.5rem',
            textAlign: 'center'
          }}>
            <h4 style={{ margin: '0 0 0.5rem 0', color: '#dc2626', fontSize: '0.875rem' }}>
              <FiRefreshCw style={{ marginRight: '0.5rem' }} />
              Need to Start Over?
            </h4>
            <p style={{ margin: '0 0 1rem 0', color: '#6b7280', fontSize: '0.8rem' }}>
              Clear flow progress and tokens (credentials preserved)
            </p>
            <button
              onClick={() => setShowResetModal(true)}
              style={{
                padding: '0.5rem 1rem',
                backgroundColor: '#dc2626',
                color: 'white',
                border: 'none',
                borderRadius: '0.375rem',
                fontSize: '0.8rem',
                fontWeight: '500',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                transition: 'background-color 0.2s'
              }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#b91c1c'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#dc2626'}
            >
              <FiRefreshCw />
              Reset Flow
            </button>
          </div>
        </div>
      ),
      execute: async () => {
        setIsBuildingUrl(true);
        try {
          console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Build Authorization URL step executing...');
          console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Current credentials:', credentials);
          console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Current PKCE codes:', pkceCodes);
          
          const generatedUrl = generateAuthUrl();
          console.log('🔧 [EnhancedAuthorizationCodeFlowV2] Generated URL:', generatedUrl);
          setUrlGenerated(true);
          
          // Update step message for success
          updateStepMessage('build-auth-url', '✅ Authorization URL built successfully! Your URL is ready for user redirection.');
          
          // Show centralized success message and scroll to top
          showAuthUrlBuilt();
          scrollToTopAfterAction('Authorization URL Built');
          
          const result = { 
            authUrl: generatedUrl,
            credentials: { ...credentials },
            pkceCodes: { ...pkceCodes },
            timestamp: new Date().toISOString(),
            success: true 
          };
          saveStepResult('build-auth-url', result);
          markStepCompleted(2); // Mark step 2 as completed
          return { success: true };
        } finally {
          setIsBuildingUrl(false);
        }
      },
      canExecute: Boolean(credentials.environmentId && credentials.clientId && credentials.redirectUri)
    },
    {
      id: 'user-authorization',
      title: 'Redirect User to Authorization Server',
      description: 'The user will be redirected to PingOne to authenticate and authorize your application.',
      icon: <FiUser />,
      category: 'authorization',
      content: (
        <div>
          <h4>Choose your testing method:</h4>
          
          <TestingMethodCard 
            $selected={testingMethod === 'popup'}
            onClick={() => setTestingMethod('popup')}
          >
            <MethodIcon>🪟</MethodIcon>
            <MethodTitle>Open in Popup Window (Recommended for testing)</MethodTitle>
            <MethodDescription>Easier to handle callback and continue with the flow</MethodDescription>
          </TestingMethodCard>

          <TestingMethodCard 
            $selected={testingMethod === 'redirect'}
            onClick={() => setTestingMethod('redirect')}
          >
            <MethodIcon>🌐</MethodIcon>
            <MethodTitle>Full Redirect (Production-like behavior)</MethodTitle>
            <MethodDescription>Redirects current tab - more realistic production behavior</MethodDescription>
          </TestingMethodCard>

          <InfoBox type="warning">
            <FiAlertTriangle />
            <div>
              <strong>State Parameter:</strong> {state}
              <br />
              Remember this value to verify the callback
            </div>
          </InfoBox>

          {/* Clear User Guidance Message */}
          <InfoBox type="info" style={{ marginTop: '2rem', marginBottom: '1rem' }}>
            <FiUser />
            <div>
              <strong>📋 What to do next:</strong>
              <br />
              <br />
              1. <strong>Choose your testing method</strong> above (popup recommended for testing)
              <br />
              2. <strong>Click the "Sign On" button</strong> below to redirect to PingOne
              <br />
              3. <strong>Log in with your PingOne credentials</strong> in the popup/redirect
              <br />
              4. <strong>Authorize the application</strong> when prompted
              <br />
              5. <strong>You'll be redirected back</strong> automatically with an authorization code
              <br />
              <br />
              <strong>💡 Tip:</strong> The popup method is easier for testing - you can see the callback happen in real-time!
            </div>
          </InfoBox>

          {/* Success Message at Bottom */}
          {stepMessages['user-authorization'] && (
            <div style={{ marginTop: '2rem', marginBottom: '1rem' }}>
              <InfoBox type="success">
                <div>{stepMessages['user-authorization']}</div>
              </InfoBox>
            </div>
          )}

          {/* Reset Flow Button */}
          <div style={{ 
            marginTop: '2rem', 
            padding: '1rem', 
            backgroundColor: '#fef2f2', 
            border: '1px solid #fecaca', 
            borderRadius: '0.5rem',
            textAlign: 'center'
          }}>
            <h4 style={{ margin: '0 0 0.5rem 0', color: '#dc2626', fontSize: '0.875rem' }}>
              <FiRefreshCw style={{ marginRight: '0.5rem' }} />
              Need to Start Over?
            </h4>
            <p style={{ margin: '0 0 1rem 0', color: '#6b7280', fontSize: '0.8rem' }}>
              Clear flow progress and tokens (credentials preserved)
            </p>
            <button
              onClick={() => setShowResetModal(true)}
              style={{
                padding: '0.5rem 1rem',
                backgroundColor: '#dc2626',
                color: 'white',
                border: 'none',
                borderRadius: '0.375rem',
                fontSize: '0.8rem',
                fontWeight: '500',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                transition: 'background-color 0.2s'
              }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#b91c1c'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#dc2626'}
            >
              <FiRefreshCw />
              Reset Flow
            </button>
          </div>
        </div>
      ),
      execute: handleAuthorization,
      canExecute: Boolean(authUrl && credentials.environmentId && credentials.clientId && credentials.redirectUri)
    },
    {
      id: 'handle-callback',
      title: 'Handle Authorization Callback',
      description: 'Process the authorization code returned from PingOne and validate the state parameter.',
      icon: <FiCode />,
      category: 'authorization',
      content: (
        <div>
          {stepMessages['handle-callback'] && (
            <InfoBox type="success">
              <div>{stepMessages['handle-callback']}</div>
            </InfoBox>
          )}

          {authCode && (
            <InfoBox type="success" style={{ marginBottom: '2rem', textAlign: 'center' }}>
              <FiCheckCircle size={48} style={{ marginBottom: '1rem' }} />
              <div>
                <h3 style={{ margin: '0 0 0.5rem 0', fontSize: '1.25rem' }}>
                  🎉 Welcome Back from PingOne!
                </h3>
                <p style={{ margin: '0', fontSize: '1.1rem' }}>
                  Your authorization was successful. You can now proceed with the token exchange.
                </p>
              </div>
            </InfoBox>
          )}

          {!callbackSuccess && !callbackError && !authCode && (
          <CallbackListener>
            <FiClock size={48} style={{ marginBottom: '1rem', color: '#6b7280' }} />
            <h4>Waiting for authorization callback...</h4>
            <p>Expected format:</p>
            <code>
              {credentials.redirectUri}?code=AUTH_CODE_HERE&state={state}
            </code>
          </CallbackListener>
          )}

          {(callbackSuccess || authCode) && (
            <div style={{ 
              marginTop: '2rem', 
              padding: '1.5rem', 
              background: '#f0fdf4', 
              border: '1px solid #22c55e', 
              borderRadius: '0.5rem' 
            }}>
              <h4 style={{ margin: '0 0 1rem 0', color: '#15803d' }}>
                <FiCheckCircle style={{ marginRight: '0.5rem' }} />
                Authorization Callback Successful!
              </h4>
              
              <div style={{ marginBottom: '1rem' }}>
                <strong>Authorization Code:</strong>
                <code style={{ 
                  display: 'block', 
                  marginTop: '0.5rem', 
                  padding: '0.5rem', 
                  background: 'white', 
                  border: '1px solid #22c55e', 
                  borderRadius: '0.25rem',
                  wordBreak: 'break-all'
                }}>
                  {authCode}
                </code>
              </div>

              {showUrlDetailsInStep4 && (
                <div style={{ 
                  marginBottom: '1rem', 
                  padding: '1.5rem', 
                  background: '#f8fafc', 
                  border: '1px solid #e2e8f0', 
                  borderRadius: '0.5rem' 
                }}>
                  <h4 style={{ margin: '0 0 1rem 0', color: '#1e40af', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <FiInfo />
                    Callback URL Details
                  </h4>
                  
                  <ParameterBreakdown>
                    <ParameterItem>
                      <ParameterName>Redirect URI</ParameterName>
                      <ParameterValue>{credentials.redirectUri}</ParameterValue>
                    </ParameterItem>
                    <ParameterItem>
                      <ParameterName>Authorization Code</ParameterName>
                      <ParameterValue>{authCode}</ParameterValue>
                    </ParameterItem>
                    <ParameterItem>
                      <ParameterName>State Parameter</ParameterName>
                      <ParameterValue>{state || 'Not provided'}</ParameterValue>
                    </ParameterItem>
                    <ParameterItem>
                      <ParameterName>Client ID</ParameterName>
                      <ParameterValue>{credentials.clientId}</ParameterValue>
                    </ParameterItem>
                    <ParameterItem>
                      <ParameterName>Environment ID</ParameterName>
                      <ParameterValue>{credentials.environmentId}</ParameterValue>
                    </ParameterItem>
                    <ParameterItem>
                      <ParameterName>Scopes</ParameterName>
                      <ParameterValue>{credentials.scopes}</ParameterValue>
                    </ParameterItem>
                  </ParameterBreakdown>
                  
                  <div style={{ marginTop: '1rem', padding: '1rem', background: '#e0f2fe', border: '1px solid #0ea5e9', borderRadius: '0.5rem' }}>
                    <h5 style={{ margin: '0 0 0.5rem 0', color: '#0c4a6e' }}>Complete Callback URL:</h5>
                    <code style={{ 
                      display: 'block', 
                      padding: '0.5rem', 
                      background: 'white', 
                      border: '1px solid #0ea5e9', 
                      borderRadius: '0.25rem',
                      wordBreak: 'break-all',
                      fontSize: '0.9rem'
                    }}>
                      {credentials.redirectUri}?code={authCode}&state={state}
                    </code>
                  </div>
                </div>
              )}

              {tokens && (
                <div style={{ 
                  marginBottom: '1rem', 
                  padding: '1rem', 
                  background: '#ecfdf5', 
                  border: '1px solid #10b981', 
                  borderRadius: '0.5rem' 
                }}>
                  <strong style={{ color: '#065f46' }}>🎉 Tokens Successfully Exchanged!</strong>
                  <ul style={{ margin: '0.5rem 0', paddingLeft: '1.5rem' }}>
                    <li>✅ Access Token: <strong style={{ color: '#1e40af' }}>{tokens.access_token ? 'Received' : 'Missing'}</strong></li>
                    <li>✅ Refresh Token: <strong style={{ color: '#1e40af' }}>{tokens.refresh_token ? 'Received' : 'Missing'}</strong></li>
                    <li>✅ ID Token: <strong style={{ color: '#1e40af' }}>{tokens.id_token ? 'Received' : 'Missing'}</strong></li>
                    <li>Token Type: <strong style={{ color: '#1e40af' }}>{tokens.token_type || 'Bearer'}</strong></li>
                    <li>Expires In: <strong style={{ color: '#1e40af' }}>{tokens.expires_in ? `${tokens.expires_in} seconds` : 'Unknown'}</strong></li>
                    <li>Scope: <strong style={{ color: '#1e40af' }}>{tokens.scope || 'Not specified'}</strong></li>
                  </ul>
                </div>
              )}

              {userInfo && (
                <div style={{ 
                  marginBottom: '1rem', 
                  padding: '1rem', 
                  background: '#fef3c7', 
                  border: '1px solid #f59e0b', 
                  borderRadius: '0.5rem' 
                }}>
                  <strong style={{ color: '#92400e' }}>👤 User Information Retrieved!</strong>
                  <div style={{ 
                    marginTop: '0.5rem', 
                    padding: '0.5rem', 
                    background: 'white', 
                    border: '1px solid #22c55e', 
                    borderRadius: '0.25rem'
                  }}>
                    <p><strong>Subject (sub):</strong> {userInfo.sub || 'Not available'}</p>
                    <p><strong>Name:</strong> {userInfo.name || 'Not available'}</p>
                    <p><strong>Email:</strong> {userInfo.email || 'Not available'}</p>
                    <p><strong>Preferred Username:</strong> {userInfo.preferred_username || 'Not available'}</p>
                  </div>
                </div>
              )}

              <div style={{ 
                padding: '0.75rem', 
                background: '#dcfce7', 
                border: '1px solid #16a34a', 
                borderRadius: '0.25rem',
                color: '#15803d'
              }}>
                <FiCheckCircle style={{ marginRight: '0.5rem' }} />
                Ready to proceed to Step 5: Exchange Code for Tokens
              </div>
            </div>
          )}

          {callbackError && (
            <div style={{ 
              marginTop: '2rem', 
              padding: '1.5rem', 
              background: '#fef2f2', 
              border: '1px solid #ef4444', 
              borderRadius: '0.5rem' 
            }}>
              <h4 style={{ margin: '0 0 1rem 0', color: '#dc2626' }}>
                <FiAlertTriangle style={{ marginRight: '0.5rem' }} />
                Authorization Callback Error
              </h4>
              <p style={{ color: '#dc2626' }}>{callbackError}</p>
              <button
                onClick={() => {
                  // Clear all OAuth state and start fresh
                  sessionStorage.removeItem('oauth_auth_code');
                  sessionStorage.removeItem('code_verifier');
                  sessionStorage.removeItem('code_challenge');
                  sessionStorage.removeItem('oauth_state');
                  setAuthCode('');
                  setCallbackError(null);
                  setCallbackSuccess(false);
                  setCurrentStepIndex(0);
                  sessionStorage.removeItem('enhanced-authz-code-v2-step');
                  console.log('🧹 [EnhancedAuthorizationCodeFlowV2] Cleared all OAuth state, starting fresh');
                }}
                style={{
                  marginTop: '1rem',
                  padding: '0.5rem 1rem',
                  backgroundColor: '#dc2626',
                  color: 'white',
                  border: 'none',
                  borderRadius: '0.25rem',
                  cursor: 'pointer'
                }}
              >
                🧹 Clear & Start Fresh
              </button>
            </div>
          )}

          <FormField>
            <FormLabel>Authorization Code (Auto-detected)</FormLabel>
            <FormInput
              type="text"
              value={authCode}
              onChange={(e) => setAuthCode(e.target.value)}
              placeholder="Authorization code will appear here automatically"
              $generated={!!authCode}
            />
            <ValidationIndicator $valid={!!authCode}>
              {authCode ? <FiCheckCircle /> : <FiAlertTriangle />}
              {authCode ? 'Authorization code received' : 'Waiting for authorization code'}
            </ValidationIndicator>
          </FormField>

          <FormField>
            <FormLabel>State Parameter (Auto-detected)</FormLabel>
            <FormInput
              type="text"
              value={state}
              readOnly
            />
            <ValidationIndicator $valid={state === state}>
              <FiCheckCircle />
            State parameter matches
          </ValidationIndicator>
        </FormField>

        {/* Reset Flow Button */}
        <div style={{ 
          marginTop: '2rem', 
          padding: '1rem', 
          backgroundColor: '#fef2f2', 
          border: '1px solid #fecaca', 
          borderRadius: '0.5rem',
          textAlign: 'center'
        }}>
          <h4 style={{ margin: '0 0 0.5rem 0', color: '#dc2626', fontSize: '0.875rem' }}>
            <FiRefreshCw style={{ marginRight: '0.5rem' }} />
            Need to Start Over?
          </h4>
          <p style={{ margin: '0 0 1rem 0', color: '#6b7280', fontSize: '0.8rem' }}>
            Clear all data and reset the entire flow
          </p>
          <button
            onClick={() => setShowResetModal(true)}
            style={{
              padding: '0.5rem 1rem',
              backgroundColor: '#dc2626',
              color: 'white',
              border: 'none',
              borderRadius: '0.375rem',
              fontSize: '0.8rem',
              fontWeight: '500',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.5rem',
              transition: 'background-color 0.2s'
            }}
            onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#b91c1c'}
            onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#dc2626'}
          >
            <FiRefreshCw />
            Reset Flow
          </button>
        </div>

      </div>
    ),
      canExecute: (() => {
        // Enable Next on Step 4 as soon as we have an auth code
        const canExec = Boolean(authCode);
        console.log('🔍 [EnhancedAuthorizationCodeFlowV2] Handle Callback canExecute check:', {
          authCode: !!authCode,
          authCodeValue: authCode,
          canExecute: canExec
        });
        return canExec;
      })()
    },
    {
      id: 'exchange-tokens',
      title: 'Exchange Code for Tokens',
      description: 'Make a secure POST request to exchange the authorization code for access and refresh tokens.',
      icon: <FiKey />,
      category: 'token-exchange',
      content: (
        <div>
          <h4>Token Request Details:</h4>
          <ParameterBreakdown>
            <ParameterItem>
              <ParameterName>Endpoint</ParameterName>
              <ParameterValue>{credentials.tokenEndpoint}</ParameterValue>
            </ParameterItem>
            <ParameterItem>
              <ParameterName>Method</ParameterName>
              <ParameterValue>POST</ParameterValue>
            </ParameterItem>
            <ParameterItem>
              <ParameterName>Content-Type</ParameterName>
              <ParameterValue>application/x-www-form-urlencoded</ParameterValue>
            </ParameterItem>
          </ParameterBreakdown>

          <h4>Request Parameters:</h4>
          <ParameterBreakdown>
            <ParameterItem>
              <ParameterName>grant_type</ParameterName>
              <ParameterValue>authorization_code</ParameterValue>
            </ParameterItem>
            <ParameterItem>
              <ParameterName>code</ParameterName>
              <ParameterValue>{authCode || '[AUTHORIZATION_CODE]'}</ParameterValue>
            </ParameterItem>
            <ParameterItem>
              <ParameterName>redirect_uri</ParameterName>
              <ParameterValue>{credentials.redirectUri}</ParameterValue>
            </ParameterItem>
            <ParameterItem>
              <ParameterName>client_id</ParameterName>
              <ParameterValue>{credentials.clientId}</ParameterValue>
            </ParameterItem>
            <ParameterItem>
              <ParameterName>code_verifier</ParameterName>
              <ParameterValue>{pkceCodes.codeVerifier || '[CODE_VERIFIER]'}</ParameterValue>
            </ParameterItem>
          </ParameterBreakdown>

          {isExchangingTokens && (
            <InfoBox type="info">
              <FiLoader className="animate-spin" />
              <div>
                <strong>🔄 Exchanging Authorization Code for Tokens...</strong>
                <br />
                Making secure request to PingOne token endpoint.
              </div>
            </InfoBox>
          )}

          {tokens && (
            <div>
              <h4 style={{ color: '#16a34a', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <FiCheckCircle />
                ✅ Token Response (JSON) - SUCCESS!
              </h4>
              <JsonDisplay style={{
                background: 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)',
                border: '2px solid #16a34a',
                boxShadow: '0 4px 6px -1px rgba(22, 163, 74, 0.3)',
                animation: 'pulse 2s ease-in-out'
              }}>
                {JSON.stringify(tokens, null, 2)}
                <CopyButton onClick={() => copyToClipboard(JSON.stringify(tokens, null, 2))}>
                  {copiedText === JSON.stringify(tokens, null, 2) ? <FiCheckCircle /> : <FiCopy />}
                </CopyButton>
              </JsonDisplay>
              <div style={{
                marginTop: '1rem',
                padding: '1rem',
                background: '#f0fdf4',
                border: '1px solid #16a34a',
                borderRadius: '0.5rem',
                color: '#15803d',
                fontWeight: '600',
                textAlign: 'center'
              }}>
                🎉 NEW TOKENS RECEIVED! Scroll up to see all your tokens in the green boxes above!
              </div>
            </div>
          )}

          <FormField>
            <FormLabel>Token Request Details (JSON)</FormLabel>
            <JsonDisplay>
              {JSON.stringify({
                endpoint: credentials.tokenEndpoint,
                method: 'POST',
                headers: {
                  'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: {
                  grant_type: 'authorization_code',
                  code: authCode || '[AUTHORIZATION_CODE]',
                  redirect_uri: credentials.redirectUri,
                  client_id: credentials.clientId,
                  code_verifier: pkceCodes.codeVerifier || '[CODE_VERIFIER]',
                  ...(credentials.clientSecret && { client_secret: credentials.clientSecret })
                }
              }, null, 2)}
              <CopyButton onClick={() => copyToClipboard(JSON.stringify({
                endpoint: credentials.tokenEndpoint,
                method: 'POST',
                headers: {
                  'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: {
                  grant_type: 'authorization_code',
                  code: authCode || '[AUTHORIZATION_CODE]',
                  redirect_uri: credentials.redirectUri,
                  client_id: credentials.clientId,
                  code_verifier: pkceCodes.codeVerifier || '[CODE_VERIFIER]',
                  ...(credentials.clientSecret && { client_secret: credentials.clientSecret })
                }
              }, null, 2))}>
                {copiedText === JSON.stringify({
                  endpoint: credentials.tokenEndpoint,
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                  },
                  body: {
                    grant_type: 'authorization_code',
                    code: authCode || '[AUTHORIZATION_CODE]',
                    redirect_uri: credentials.redirectUri,
                    client_id: credentials.clientId,
                    code_verifier: pkceCodes.codeVerifier || '[CODE_VERIFIER]'
                  }
                }, null, 2) ? <FiCheckCircle /> : <FiCopy />}
              </CopyButton>
            </JsonDisplay>
          </FormField>

          {/* Reset Flow Button */}
          <div style={{ 
            marginTop: '2rem', 
            padding: '1rem', 
            backgroundColor: '#fef2f2', 
            border: '1px solid #fecaca', 
            borderRadius: '0.5rem',
            textAlign: 'center'
          }}>
            <h4 style={{ margin: '0 0 0.5rem 0', color: '#dc2626', fontSize: '0.875rem' }}>
              <FiRefreshCw style={{ marginRight: '0.5rem' }} />
              Need to Start Over?
            </h4>
            <p style={{ margin: '0 0 1rem 0', color: '#6b7280', fontSize: '0.8rem' }}>
              Clear flow progress and tokens (credentials preserved)
            </p>
            <button
              onClick={() => setShowResetModal(true)}
              style={{
                padding: '0.5rem 1rem',
                backgroundColor: '#dc2626',
                color: 'white',
                border: 'none',
                borderRadius: '0.375rem',
                fontSize: '0.8rem',
                fontWeight: '500',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                transition: 'background-color 0.2s'
              }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#b91c1c'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#dc2626'}
            >
              <FiRefreshCw />
              Reset Flow
            </button>
          </div>

          {/* Display saved results when step is completed */}
          {hasStepResult('exchange-tokens') && (
            <div style={{
              padding: '1rem',
              backgroundColor: '#f0f9ff',
              border: '1px solid #bae6fd',
              borderRadius: '0.5rem',
              marginBottom: '1rem'
            }}>
              <h4 style={{ margin: '0 0 0.75rem 0', color: '#0369a1', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <FiCheckCircle />
                ✅ Tokens Exchanged Successfully
              </h4>
              <div style={{ fontSize: '0.875rem', color: '#0c4a6e' }}>
                <div><strong>Access Token:</strong> {(getStepResult('exchange-tokens') as any)?.tokens?.access_token ? 'Received' : 'Not available'}</div>
                <div><strong>ID Token:</strong> {(getStepResult('exchange-tokens') as any)?.tokens?.id_token ? 'Received' : 'Not available'}</div>
                <div><strong>Refresh Token:</strong> {(getStepResult('exchange-tokens') as any)?.tokens?.refresh_token ? 'Received' : 'Not available'}</div>
                <div><strong>Token Type:</strong> {(getStepResult('exchange-tokens') as any)?.tokens?.token_type || 'Bearer'}</div>
                <div><strong>Expires In:</strong> {(getStepResult('exchange-tokens') as any)?.tokens?.expires_in || 'Unknown'} seconds</div>
                <div><strong>Exchanged:</strong> {new Date((getStepResult('exchange-tokens') as any)?.timestamp || '').toLocaleString()}</div>
              </div>
            </div>
          )}

          {/* Success message at bottom above buttons */}
          {stepMessages['exchange-tokens'] && (
            <InfoBox type="success" style={{ marginTop: '2rem', marginBottom: '1rem' }}>
              <div>{stepMessages['exchange-tokens']}</div>
            </InfoBox>
          )}

        </div>
      ),
      execute: async () => {
        setIsExchangingTokens(true);
        try {
        await exchangeCodeForTokens();
        const result = { 
          tokens: { ...tokens },
          authCode,
          timestamp: new Date().toISOString(),
          success: true 
        };
        saveStepResult('exchange-tokens', result);
        markStepCompleted(5); // Mark step 5 as completed
        return { success: true };
        } finally {
          setIsExchangingTokens(false);
      }
      },
      canExecute: Boolean(authCode && credentials.environmentId && credentials.clientId)
    },
    {
      id: 'validate-tokens',
      title: 'Validate Tokens & Retrieve User Information',
      description: 'Use the access token to call the UserInfo endpoint and retrieve the authenticated user\'s profile.',
      icon: <FiUser />,
      category: 'validation',
      content: (
        <div>
          {stepMessages['validate-tokens'] && (
            <InfoBox type="success">
              <div>{stepMessages['validate-tokens']}</div>
            </InfoBox>
          )}
          
          {/* Display saved results when step is completed */}
          {hasStepResult('validate-tokens') && (
            <div style={{
              padding: '1rem',
              backgroundColor: '#f0f9ff',
              border: '1px solid #bae6fd',
              borderRadius: '0.5rem',
              marginBottom: '1rem'
            }}>
              <h4 style={{ margin: '0 0 0.75rem 0', color: '#0369a1', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <FiCheckCircle />
                ✅ User Information Retrieved Successfully
              </h4>
              <div style={{ fontSize: '0.875rem', color: '#0c4a6e' }}>
                <div><strong>User ID:</strong> {(getStepResult('validate-tokens') as any)?.userInfo?.sub || 'Not available'}</div>
                <div><strong>Name:</strong> {(getStepResult('validate-tokens') as any)?.userInfo?.name || 'Not available'}</div>
                <div><strong>Email:</strong> {(getStepResult('validate-tokens') as any)?.userInfo?.email || 'Not available'}</div>
                <div><strong>Retrieved:</strong> {new Date((getStepResult('validate-tokens') as any)?.timestamp || '').toLocaleString()}</div>
              </div>
            </div>
          )}

          {/* Always show tokens if available */}
          {tokens && (
            <InfoBox type="success">
              <FiCheckCircle />
              <div>
                <strong>🎉 Tokens Available!</strong>
                <br />
                Access token, refresh token, and ID token have been received and are ready to use.
              </div>
            </InfoBox>
          )}

          {/* Show user info if available */}
          {userInfo && (
            <InfoBox type="success">
              <FiUser />
              <div>
                <strong>👤 User Information Retrieved!</strong>
                <br />
                User profile data has been successfully fetched from the UserInfo endpoint.
              </div>
            </InfoBox>
          )}

          {/* Show complete status when both are available */}
          {tokens && userInfo && (
            <InfoBox type="success">
              <FiCheckCircle />
              <div>
                <strong>🎉 OAuth Flow Complete!</strong>
                <br />
                All tokens are valid and user information retrieved successfully.
              </div>
            </InfoBox>
          )}

          <h4>UserInfo Request:</h4>
          <ParameterBreakdown>
            <ParameterItem>
              <ParameterName>GET</ParameterName>
              <ParameterValue>{credentials.userInfoEndpoint}</ParameterValue>
            </ParameterItem>
            <ParameterItem>
              <ParameterName>Authorization</ParameterName>
              <ParameterValue>Bearer {tokens?.access_token ? tokens.access_token.substring(0, 20) + '...' : '[ACCESS_TOKEN]'}</ParameterValue>
            </ParameterItem>
          </ParameterBreakdown>

          {isGettingUserInfo && (
            <InfoBox type="info">
              <FiLoader className="animate-spin" />
              <div>
                <strong>🔄 Retrieving User Information...</strong>
                <br />
                Fetching user profile data from the UserInfo endpoint...
              </div>
            </InfoBox>
          )}

          {/* Action Button */}
          <div style={{ marginTop: '1.5rem', marginBottom: '1.5rem' }}>
            <button
              onClick={async () => {
                try {
                  await getUserInfo();
                  updateStepMessage('validate-tokens', '✅ User information retrieved successfully! Your profile data has been fetched from the UserInfo endpoint.');
                  showUserInfoSuccess();
                } catch (error) {
                  const errorMsg = error instanceof Error ? error.message : String(error);
                  updateStepMessage('validate-tokens', `❌ Failed to retrieve user information: ${errorMsg}`);
                  showUserInfoError(errorMsg);
                }
              }}
              disabled={!tokens?.access_token || isGettingUserInfo}
              style={{
                padding: '0.75rem 1.5rem',
                backgroundColor: tokens?.access_token ? '#10b981' : '#9ca3af',
                color: 'white',
                border: 'none',
                borderRadius: '0.5rem',
                fontSize: '0.9rem',
                fontWeight: '600',
                cursor: tokens?.access_token && !isGettingUserInfo ? 'pointer' : 'not-allowed',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                transition: 'all 0.2s',
                boxShadow: tokens?.access_token ? '0 2px 4px rgba(16, 185, 129, 0.3)' : 'none'
              }}
              onMouseOver={(e) => {
                if (tokens?.access_token && !isGettingUserInfo) {
                  e.currentTarget.style.backgroundColor = '#059669';
                  e.currentTarget.style.transform = 'translateY(-1px)';
                  e.currentTarget.style.boxShadow = '0 4px 8px rgba(16, 185, 129, 0.4)';
                }
              }}
              onMouseOut={(e) => {
                if (tokens?.access_token && !isGettingUserInfo) {
                  e.currentTarget.style.backgroundColor = '#10b981';
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = '0 2px 4px rgba(16, 185, 129, 0.3)';
                }
              }}
            >
              {isGettingUserInfo ? <FiLoader className="animate-spin" /> : <FiUser />}
              {isGettingUserInfo ? 'Retrieving User Info...' : 'Get User Information'}
            </button>
          </div>

          {/* Token Display Section - Show tokens when available */}
          {tokens && (
            <div style={{ marginTop: '2rem', marginBottom: '2rem' }}>
              <h4>🔑 Retrieved Tokens:</h4>
              
              {/* Access Token */}
              {tokens.access_token && (
                <div style={{ marginBottom: '1rem' }}>
                  <FormLabel>Access Token</FormLabel>
                  <div style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '0.5rem',
                    padding: '0.75rem',
                    backgroundColor: '#f0fdf4',
                    border: '1px solid #bbf7d0',
                    borderRadius: '0.5rem'
                  }}>
                    <span style={{ 
                      fontFamily: 'monospace', 
                      fontSize: '0.8rem', 
                      color: '#166534',
                      wordBreak: 'break-all',
                      flex: 1
                    }}>
                      {typeof tokens.access_token === 'string' ? tokens.access_token.substring(0, 50) + '...' : '[ACCESS_TOKEN]'}
                    </span>
                    <button
                      onClick={() => copyToClipboard(tokens.access_token as string, 'access token')}
                      style={{
                        padding: '0.25rem 0.5rem',
                        backgroundColor: '#10b981',
                        color: 'white',
                        border: 'none',
                        borderRadius: '0.25rem',
                        fontSize: '0.75rem',
                        cursor: 'pointer'
                      }}
                    >
                      <FiCopy />
                    </button>
                  </div>
                </div>
              )}

              {/* ID Token */}
              {tokens.id_token && (
                <div style={{ marginBottom: '1rem' }}>
                  <FormLabel>ID Token</FormLabel>
                  <div style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '0.5rem',
                    padding: '0.75rem',
                    backgroundColor: '#eff6ff',
                    border: '1px solid #bfdbfe',
                    borderRadius: '0.5rem'
                  }}>
                    <span style={{ 
                      fontFamily: 'monospace', 
                      fontSize: '0.8rem', 
                      color: '#1e40af',
                      wordBreak: 'break-all',
                      flex: 1
                    }}>
                      {typeof tokens.id_token === 'string' ? tokens.id_token.substring(0, 50) + '...' : '[ID_TOKEN]'}
                    </span>
                    <button
                      onClick={() => copyToClipboard(tokens.id_token as string, 'ID token')}
                      style={{
                        padding: '0.25rem 0.5rem',
                        backgroundColor: '#3b82f6',
                        color: 'white',
                        border: 'none',
                        borderRadius: '0.25rem',
                        fontSize: '0.75rem',
                        cursor: 'pointer'
                      }}
                    >
                      <FiCopy />
                    </button>
                  </div>
                </div>
              )}

              {/* Refresh Token */}
              {tokens.refresh_token && (
                <div style={{ marginBottom: '1rem' }}>
                  <FormLabel>Refresh Token</FormLabel>
                  <div style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '0.5rem',
                    padding: '0.75rem',
                    backgroundColor: '#fefbf2',
                    border: '1px solid #fed7aa',
                    borderRadius: '0.5rem'
                  }}>
                    <span style={{ 
                      fontFamily: 'monospace', 
                      fontSize: '0.8rem', 
                      color: '#92400e',
                      wordBreak: 'break-all',
                      flex: 1
                    }}>
                      {typeof tokens.refresh_token === 'string' ? tokens.refresh_token.substring(0, 50) + '...' : '[REFRESH_TOKEN]'}
                    </span>
                    <button
                      onClick={() => copyToClipboard(tokens.refresh_token as string, 'refresh token')}
                      style={{
                        padding: '0.25rem 0.5rem',
                        backgroundColor: '#f59e0b',
                        color: 'white',
                        border: 'none',
                        borderRadius: '0.25rem',
                        fontSize: '0.75rem',
                        cursor: 'pointer'
                      }}
                    >
                      <FiCopy />
                    </button>
                  </div>
                </div>
              )}

              {/* Token Metadata */}
              <div style={{ 
                padding: '0.75rem',
                backgroundColor: '#f8fafc',
                border: '1px solid #e2e8f0',
                borderRadius: '0.5rem',
                fontSize: '0.875rem'
              }}>
                <div><strong>Token Type:</strong> {tokens.token_type || 'Bearer'}</div>
                <div><strong>Expires In:</strong> {tokens.expires_in ? `${tokens.expires_in} seconds` : 'Unknown'}</div>
                <div><strong>Scope:</strong> {tokens.scope || 'openid profile email'}</div>
              </div>
            </div>
          )}

          {/* User Info Display Section - Show user info when available */}
          {userInfo && (
            <div style={{ marginTop: '2rem', marginBottom: '2rem' }}>
              <h4>👤 User Information:</h4>
              <div style={{ 
                padding: '1rem',
                backgroundColor: '#f0f9ff',
                border: '1px solid #bae6fd',
                borderRadius: '0.5rem',
                fontSize: '0.875rem'
              }}>
                <div><strong>Name:</strong> {(userInfo as any).name || 'Not provided'}</div>
                <div><strong>Email:</strong> {(userInfo as any).email || 'Not provided'}</div>
                <div><strong>Subject:</strong> {(userInfo as any).sub || 'Not provided'}</div>
                <div><strong>Given Name:</strong> {(userInfo as any).given_name || 'Not provided'}</div>
                <div><strong>Family Name:</strong> {(userInfo as any).family_name || 'Not provided'}</div>
                <div><strong>Preferred Username:</strong> {(userInfo as any).preferred_username || 'Not provided'}</div>
              </div>
            </div>
          )}

          <FormField>
            <FormLabel>UserInfo Request Details (JSON)</FormLabel>
            <JsonDisplay>
              {JSON.stringify({
                endpoint: credentials.userInfoEndpoint,
                method: 'GET',
                headers: {
                  'Authorization': `Bearer ${tokens?.access_token ? tokens.access_token.substring(0, 20) + '...' : '[ACCESS_TOKEN]'}`
                }
              }, null, 2)}
              <CopyButton onClick={() => copyToClipboard(JSON.stringify({
                endpoint: credentials.userInfoEndpoint,
                method: 'GET',
                headers: {
                  'Authorization': `Bearer ${tokens?.access_token ? tokens.access_token.substring(0, 20) + '...' : '[ACCESS_TOKEN]'}`
                }
              }, null, 2))}>
                {copiedText === JSON.stringify({
                  endpoint: credentials.userInfoEndpoint,
                  method: 'GET',
                  headers: {
                    'Authorization': `Bearer ${tokens?.access_token ? tokens.access_token.substring(0, 20) + '...' : '[ACCESS_TOKEN]'}`
                  }
                }, null, 2) ? <FiCheckCircle /> : <FiCopy />}
              </CopyButton>
            </JsonDisplay>
          </FormField>

          {userInfo && (
            <div>
              <h4>User Profile:</h4>
              <UserProfileCard>
                <ProfileHeader>
                  <ProfileAvatar>
                    <FiUser />
                  </ProfileAvatar>
                  <ProfileInfo>
                    <ProfileName>{userInfo.name || 'User'}</ProfileName>
                    <ProfileEmail>{userInfo.email || 'No email provided'}</ProfileEmail>
                  </ProfileInfo>
                </ProfileHeader>
                
                <ProfileDetails>
                  <DetailItem>
                    <FiUser />
                    <strong>ID:</strong> {userInfo.sub}
                  </DetailItem>
                  <DetailItem>
                    <FiCheckCircle />
                    <strong>Email Verified:</strong> {userInfo.email_verified ? 'Yes' : 'No'}
                  </DetailItem>
                  {userInfo.given_name && (
                    <DetailItem>
                      <FiUser />
                      <strong>First Name:</strong> {userInfo.given_name}
                    </DetailItem>
                  )}
                  {userInfo.family_name && (
                    <DetailItem>
                      <FiUser />
                      <strong>Last Name:</strong> {userInfo.family_name}
                    </DetailItem>
                  )}
                </ProfileDetails>
              </UserProfileCard>

              <h4>Raw Response (JSON):</h4>
              <JsonDisplay>
                {JSON.stringify(userInfo, null, 2)}
                <CopyButton onClick={() => copyToClipboard(JSON.stringify(userInfo, null, 2))}>
                  {copiedText === JSON.stringify(userInfo, null, 2) ? <FiCheckCircle /> : <FiCopy />}
                </CopyButton>
              </JsonDisplay>
            </div>
          )}

          {isGettingUserInfo && (
            <InfoBox type="info">
              <FiLoader className="animate-spin" />
              <div>
                <strong>🔄 Retrieving User Information...</strong>
                <br />
                Fetching user profile data from the UserInfo endpoint...
              </div>
            </InfoBox>
          )}

          {/* Token Display Section */}
          {tokens && (
            <div style={{ marginTop: '2rem' }}>
              <h4>Received Tokens:</h4>
              
              {/* Access Token */}
              {tokens.access_token && (
                <div style={{ marginBottom: '1.5rem' }}>
                  <h5 style={{ margin: '0 0 0.5rem 0', color: '#1f2937', fontSize: '0.9rem', fontWeight: '600' }}>
                    Access Token
                  </h5>
                  <ParameterBreakdown>
                    <ParameterItem>
                      <ParameterName>Token</ParameterName>
                      <ParameterValue style={{ fontFamily: 'Monaco, Menlo, monospace', fontSize: '0.8rem', wordBreak: 'break-all', fontWeight: 'bold', color: '#1e40af' }}>
                        {tokens.access_token}
                      </ParameterValue>
                    </ParameterItem>
                    <ParameterItem>
                      <ParameterName>Type</ParameterName>
                      <ParameterValue style={{ fontWeight: 'bold', color: '#1e40af' }}>{tokens.token_type || 'Bearer'}</ParameterValue>
                    </ParameterItem>
                    <ParameterItem>
                      <ParameterName>Expires In</ParameterName>
                      <ParameterValue style={{ fontWeight: 'bold', color: '#1e40af' }}>{tokens.expires_in ? `${tokens.expires_in} seconds` : 'Unknown'}</ParameterValue>
                    </ParameterItem>
                    <ParameterItem>
                      <ParameterName>Scope</ParameterName>
                      <ParameterValue style={{ fontWeight: 'bold', color: '#1e40af' }}>{tokens.scope || 'Not specified'}</ParameterValue>
                    </ParameterItem>
                  </ParameterBreakdown>
                  <div style={{ marginTop: '0.5rem', display: 'flex', justifyContent: 'flex-end' }}>
                    <CopyButton onClick={() => copyToClipboard(tokens.access_token)}>
                      {copiedText === tokens.access_token ? <FiCheckCircle /> : <FiCopy />}
                      Copy Access Token
                    </CopyButton>
                  </div>
                </div>
              )}

              {/* Refresh Token */}
              {tokens.refresh_token && (
                <div style={{ marginBottom: '1.5rem' }}>
                  <h5 style={{ margin: '0 0 0.5rem 0', color: '#1f2937', fontSize: '0.9rem', fontWeight: '600' }}>
                    Refresh Token
                  </h5>
                  <ParameterBreakdown>
                    <ParameterItem>
                      <ParameterName>Token</ParameterName>
                      <ParameterValue style={{ fontFamily: 'Monaco, Menlo, monospace', fontSize: '0.8rem', wordBreak: 'break-all', fontWeight: 'bold', color: '#1e40af' }}>
                        {tokens.refresh_token}
                      </ParameterValue>
                    </ParameterItem>
                    <ParameterItem>
                      <ParameterName>Purpose</ParameterName>
                      <ParameterValue style={{ fontWeight: 'bold', color: '#1e40af' }}>Used to obtain new access tokens</ParameterValue>
                    </ParameterItem>
                  </ParameterBreakdown>
                  <div style={{ marginTop: '0.5rem', display: 'flex', justifyContent: 'flex-end' }}>
                    <CopyButton onClick={() => copyToClipboard(tokens.refresh_token)}>
                      {copiedText === tokens.refresh_token ? <FiCheckCircle /> : <FiCopy />}
                      Copy Refresh Token
                    </CopyButton>
                  </div>
                </div>
              )}

              {/* ID Token */}
              {tokens.id_token && (
                <div style={{ marginBottom: '1.5rem' }}>
                  <h5 style={{ margin: '0 0 0.5rem 0', color: '#1f2937', fontSize: '0.9rem', fontWeight: '600' }}>
                    ID Token (JWT)
                  </h5>
                  <ParameterBreakdown>
                    <ParameterItem>
                      <ParameterName>Token</ParameterName>
                      <ParameterValue style={{ fontFamily: 'Monaco, Menlo, monospace', fontSize: '0.8rem', wordBreak: 'break-all', fontWeight: 'bold', color: '#1e40af' }}>
                        {tokens.id_token}
                      </ParameterValue>
                    </ParameterItem>
                    <ParameterItem>
                      <ParameterName>Type</ParameterName>
                      <ParameterValue style={{ fontWeight: 'bold', color: '#1e40af' }}>JWT (JSON Web Token)</ParameterValue>
                    </ParameterItem>
                    <ParameterItem>
                      <ParameterName>Purpose</ParameterName>
                      <ParameterValue style={{ fontWeight: 'bold', color: '#1e40af' }}>Contains user identity information</ParameterValue>
                    </ParameterItem>
                  </ParameterBreakdown>
                  <div style={{ marginTop: '0.5rem', display: 'flex', justifyContent: 'flex-end' }}>
                    <CopyButton onClick={() => copyToClipboard(tokens.id_token)}>
                      {copiedText === tokens.id_token ? <FiCheckCircle /> : <FiCopy />}
                      Copy ID Token
                    </CopyButton>
                  </div>
                </div>
              )}

              {/* All Tokens JSON */}
              <div style={{ marginBottom: '1.5rem' }}>
                <h5 style={{ margin: '0 0 0.5rem 0', color: '#1f2937', fontSize: '0.9rem', fontWeight: '600' }}>
                  Complete Token Response
                </h5>
                <JsonDisplay>
                  {JSON.stringify(tokens, null, 2)}
                </JsonDisplay>
                <div style={{ marginTop: '0.5rem', display: 'flex', justifyContent: 'flex-end' }}>
                  <CopyButton onClick={() => copyToClipboard(JSON.stringify(tokens, null, 2))}>
                    {copiedText === JSON.stringify(tokens, null, 2) ? <FiCheckCircle /> : <FiCopy />}
                    Copy All Tokens
                  </CopyButton>
                </div>
              </div>
            </div>
          )}

          {/* Token Decode Buttons */}
          {tokens && (
            <div style={{ marginTop: '2rem', padding: '1.5rem', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '0.75rem' }}>
              <h4 style={{ margin: '0 0 1rem 0', color: '#1f2937', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <FiKey />
                Token Management
              </h4>
              <p style={{ margin: '0 0 1.5rem 0', color: '#6b7280', fontSize: '0.9rem' }}>
                Decode and inspect your tokens to see their contents and claims.
              </p>
              
              {/* Token Paste Area */}
              <div style={{ marginBottom: '1.5rem' }}>
                <h5 style={{ margin: '0 0 0.5rem 0', color: '#1f2937', fontSize: '0.9rem', fontWeight: '600' }}>
                  Decode Custom Token
                </h5>
                <p style={{ margin: '0 0 0.75rem 0', color: '#6b7280', fontSize: '0.8rem' }}>
                  Paste any JWT token below to decode and inspect its contents.
                </p>
                <FormTextarea
                  placeholder="Paste your JWT token here (e.g., eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...)"
                  value={customToken}
                  onChange={(e) => setCustomToken(e.target.value)}
                  style={{ minHeight: '4rem', fontFamily: 'Monaco, Menlo, monospace', fontSize: '0.8rem' }}
                />
                <div style={{ marginTop: '0.5rem', display: 'flex', justifyContent: 'flex-end' }}>
                  <CopyButton 
                    onClick={() => {
                      if (customToken.trim()) {
                        // Store the custom token in localStorage for the token management page
                        const tokenData = {
                          access_token: customToken.trim(),
                          token_type: 'Bearer',
                          custom: true
                        };
                        
                        // Store in localStorage for token management page
                        localStorage.setItem('oauth_tokens', JSON.stringify(tokenData));
                        console.log('✅ Custom token stored for token management page');
                        
                        // Copy custom token to clipboard
                        navigator.clipboard.writeText(customToken).then(() => {
                          console.log('✅ Custom token copied to clipboard');
                        });
                        
                        // Navigate to token management page
                        window.location.href = '/token-management';
                      }
                    }}
                    disabled={!customToken.trim()}
                  >
                    {copiedText === customToken ? <FiCheckCircle /> : <FiCopy />}
                    Decode Custom Token
                  </CopyButton>
                </div>
              </div>
              
              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                <button
                  onClick={() => {
                    if (tokens.access_token) {
                      // Store ONLY the access token for decoding
                      const tokenData = {
                        access_token: tokens.access_token, // This is what we want to decode
                        id_token: '', // Empty - we only want to decode access token
                        refresh_token: '',
                        token_type: 'Bearer',
                        expires_in: 0,
                        scope: '',
                        tokenToDecode: 'access_token' // Flag to indicate which token to decode
                      };
                      
                      // Store in localStorage for token management page
                      localStorage.setItem('oauth_tokens', JSON.stringify(tokenData));
                      console.log('✅ Access token stored for token management page (access token only)');
                      
                      // Copy access token to clipboard
                      navigator.clipboard.writeText(tokens.access_token).then(() => {
                        console.log('✅ Access token copied to clipboard');
                      });
                      
                      // Navigate to token management page
                      window.location.href = '/token-management';
                    }
                  }}
                  disabled={!tokens.access_token}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    padding: '0.75rem 1.5rem',
                    background: 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '0.5rem',
                    fontSize: '0.875rem',
                    fontWeight: '600',
                    cursor: tokens.access_token ? 'pointer' : 'not-allowed',
                    transition: 'all 0.2s ease',
                    boxShadow: '0 2px 4px rgba(59, 130, 246, 0.3)',
                    opacity: tokens.access_token ? 1 : 0.5
                  }}
                  onMouseOver={(e) => {
                    if (tokens.access_token) {
                      e.currentTarget.style.transform = 'translateY(-1px)';
                      e.currentTarget.style.boxShadow = '0 4px 8px rgba(59, 130, 246, 0.4)';
                    }
                  }}
                  onMouseOut={(e) => {
                    if (tokens.access_token) {
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.boxShadow = '0 2px 4px rgba(59, 130, 246, 0.3)';
                    }
                  }}
                >
                  <FiKey />
                  Decode Access Token
                </button>

                <button
                  onClick={() => {
                    if (tokens.id_token) {
                      // Store ONLY the ID token for decoding
                      const tokenData = {
                        access_token: '', // Empty - we only want to decode ID token
                        id_token: tokens.id_token, // This is what we want to decode
                        refresh_token: '',
                        token_type: 'Bearer',
                        expires_in: 0,
                        scope: '',
                        tokenToDecode: 'id_token' // Flag to indicate which token to decode
                      };
                      
                      // Store in localStorage for token management page
                      localStorage.setItem('oauth_tokens', JSON.stringify(tokenData));
                      console.log('✅ ID token stored for token management page (ID token only)');
                      
                      // Copy ID token to clipboard
                      navigator.clipboard.writeText(tokens.id_token).then(() => {
                        console.log('✅ ID token copied to clipboard');
                      });
                      
                      // Navigate to token management page
                      window.location.href = '/token-management';
                    }
                  }}
                  disabled={!tokens.id_token}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    padding: '0.75rem 1.5rem',
                    background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '0.5rem',
                    fontSize: '0.875rem',
                    fontWeight: '600',
                    cursor: tokens.id_token ? 'pointer' : 'not-allowed',
                    transition: 'all 0.2s ease',
                    boxShadow: '0 2px 4px rgba(16, 185, 129, 0.3)',
                    opacity: tokens.id_token ? 1 : 0.5
                  }}
                  onMouseOver={(e) => {
                    if (tokens.id_token) {
                      e.currentTarget.style.transform = 'translateY(-1px)';
                      e.currentTarget.style.boxShadow = '0 4px 8px rgba(16, 185, 129, 0.4)';
                    }
                  }}
                  onMouseOut={(e) => {
                    if (tokens.id_token) {
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.boxShadow = '0 2px 4px rgba(16, 185, 129, 0.3)';
                    }
                  }}
                >
                  <FiShield />
                  Decode ID Token
                </button>
                
                <button
                  onClick={() => {
                    // Navigate to token management page (tokens already stored in localStorage)
                    console.log('✅ [EnhancedAuthorizationCodeFlowV2] Navigating to Token Management page with all tokens');
                    window.location.href = '/token-management';
                  }}
                  disabled={!tokens}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    padding: '0.75rem 1.5rem',
                    background: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '0.5rem',
                    fontSize: '0.875rem',
                    fontWeight: '600',
                    cursor: tokens ? 'pointer' : 'not-allowed',
                    transition: 'all 0.2s ease',
                    boxShadow: '0 2px 4px rgba(59, 130, 246, 0.3)',
                    opacity: tokens ? 1 : 0.5
                  }}
                  onMouseOver={(e) => {
                    if (tokens) {
                      e.currentTarget.style.transform = 'translateY(-1px)';
                      e.currentTarget.style.boxShadow = '0 4px 8px rgba(59, 130, 246, 0.4)';
                    }
                  }}
                  onMouseOut={(e) => {
                    if (tokens) {
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.boxShadow = '0 2px 4px rgba(59, 130, 246, 0.3)';
                    }
                  }}
                >
                  <FiEye />
                  Go to Token Management
                </button>
              </div>

              <div style={{ marginTop: '1rem', fontSize: '0.8rem', color: '#6b7280' }}>
                <p style={{ margin: '0 0 0.5rem 0' }}>
                  <strong>Access Token:</strong> <strong style={{ color: '#1e40af' }}>{tokens.access_token ? 'Available' : 'Not available'}</strong>
                </p>
                <p style={{ margin: '0' }}>
                  <strong>ID Token:</strong> <strong style={{ color: '#1e40af' }}>{tokens.id_token ? 'Available' : 'Not available'}</strong>
                </p>
              </div>
            </div>
          )}

          {/* Reset Flow Button */}
          <div style={{ 
            marginTop: '2rem', 
            padding: '1rem', 
            backgroundColor: '#fef2f2', 
            border: '1px solid #fecaca', 
            borderRadius: '0.5rem',
            textAlign: 'center'
          }}>
            <h4 style={{ margin: '0 0 0.5rem 0', color: '#dc2626', fontSize: '0.875rem' }}>
              <FiRefreshCw style={{ marginRight: '0.5rem' }} />
              Need to Start Over?
            </h4>
            <p style={{ margin: '0 0 1rem 0', color: '#6b7280', fontSize: '0.8rem' }}>
              Clear flow progress and tokens (credentials preserved)
            </p>
            <button
              onClick={() => setShowResetModal(true)}
              style={{
                padding: '0.5rem 1rem',
                backgroundColor: '#dc2626',
                color: 'white',
                border: 'none',
                borderRadius: '0.375rem',
                fontSize: '0.8rem',
                fontWeight: '500',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                transition: 'background-color 0.2s'
              }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#b91c1c'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#dc2626'}
            >
              <FiRefreshCw />
              Reset Flow
            </button>
          </div>
        </div>
      ),
      execute: async () => {
        setIsGettingUserInfo(true);
        try {
        await getUserInfo();
        
        // Show centralized success message
        showUserInfoSuccess();
        scrollToTopAfterAction('User Info Retrieved');
        
        const result = { 
          userInfo: { ...userInfo },
          tokens: { ...tokens },
          timestamp: new Date().toISOString(),
          success: true 
        };
        saveStepResult('validate-tokens', result);
        markStepCompleted(6); // Mark step 6 as completed
        return { success: true };
        } finally {
          setIsGettingUserInfo(false);
        }
      },
      canExecute: Boolean(tokens?.access_token && credentials.environmentId && credentials.clientId)
    }
  ];

  // Modal handlers
  const handleRedirectModalClose = () => {
    setShowRedirectModal(false);
  };

  const handleRedirectModalProceed = () => {
    setShowRedirectModal(false);
    window.open(redirectUrl, '_blank');
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '1.5rem' }}>
      
      {/* Centralized Success Messages - Top */}
      <CentralizedSuccessMessage position="top" />

      <ConfigurationStatus 
        config={config} 
        onConfigure={() => setShowConfig(!showConfig)}
        flowType="authorization-code"
        defaultExpanded={false}
      />

      <ContextualHelp flowId="authorization-code" />

      {showConfig && (
        <div style={{ marginBottom: '2rem' }}>
          <FlowConfiguration
            config={flowConfig}
            onConfigChange={setFlowConfig}
            flowType="authorization-code"
            isConfigured={!!(credentials.clientId && credentials.environmentId)}
          />
        </div>
      )}

      {/* Callback URL Configuration - Collapsible with shaded background */}
      <div style={{ 
        marginBottom: '2rem', 
        backgroundColor: '#f8fafc', 
        border: '1px solid #e2e8f0', 
        borderRadius: '0.75rem',
        boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)'
      }}>
        <CallbackUrlDisplay 
          flowType="authorization-code" 
          baseUrl={window.location.origin}
          defaultExpanded={false}
        />
      </div>


      {/* Authorization URL Display - Moved to bottom */}

      {/* OAuth Error Helper */}
      {authError && (
        <OAuthErrorHelper
          error={authError}
          errorDescription={errorDescription || ''}
          onRetry={() => {
            setAuthError(null);
            setErrorDescription(null);
            handleAuthorization();
          }}
          onGoToConfig={() => window.location.href = '/configuration'}
        />
      )}

      {/* Reset Flow Modal */}
      <ConfirmationModal
        isOpen={showResetModal}
        onClose={() => setShowResetModal(false)}
        onConfirm={handleResetFlow}
        title="Reset Flow"
        message="Are you sure you want to reset the flow? This will clear flow progress and tokens, but preserve your credentials."
        confirmText="Reset Flow"
        cancelText="Cancel"
        variant="danger"
        isLoading={isResetting}
      />

      {/* Clear Credentials Modal */}
      <ConfirmationModal
        isOpen={showClearCredentialsModal}
        onClose={() => setShowClearCredentialsModal(false)}
        onConfirm={handleClearCredentials}
        title="Clear All Credentials"
        message="Are you sure you want to clear all PingOne credentials? This will remove all saved configuration and you'll need to re-enter your credentials."
        confirmText="Clear Credentials"
        cancelText="Cancel"
        variant="danger"
        isLoading={isClearingCredentials}
      />

      {/* Success Messages - Moved to bottom of page above action buttons */}
      
      {/* PKCE Success Message - Only show on PKCE step (index 1) */}
      {pkceGenerated && currentStepIndex === 1 && (
        <div style={{
          background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
          color: 'white',
          padding: '1rem 1.5rem',
          borderRadius: '0.75rem',
          marginBottom: '1rem',
          boxShadow: '0 10px 25px -5px rgba(16, 185, 129, 0.3)',
          border: '1px solid #059669'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '0.5rem' }}>
            <FiCheckCircle size={24} />
            <h3 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 'bold' }}>
              ✅ PKCE Codes Generated Successfully!
            </h3>
          </div>
          <p style={{ margin: 0, fontSize: '1rem', opacity: 0.9 }}>
            Your PKCE codes have been generated and are ready to use. These will be included in the authorization request for enhanced security.
          </p>
        </div>
      )}

      {/* Authorization Success Message */}
      {authCode && (
        <div style={{
          background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
          color: 'white',
          padding: '1rem 1.5rem',
          borderRadius: '0.75rem',
          marginBottom: '2rem',
          boxShadow: '0 10px 25px -5px rgba(16, 185, 129, 0.3)',
          border: '1px solid #059669'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '0.5rem' }}>
            <FiCheckCircle size={32} />
            <h3 style={{ margin: 0, fontSize: '1.5rem', fontWeight: 'bold' }}>
              🎉 Authorization Successful!
            </h3>
          </div>
          <p style={{ margin: 0, fontSize: '1.1rem', opacity: 0.9 }}>
            You've successfully returned from PingOne authentication. Your authorization code has been received and you can now proceed with the token exchange.
          </p>
          {tokens && (
            <div style={{ marginTop: '1rem', padding: '0.75rem', background: 'rgba(255,255,255,0.2)', borderRadius: '0.5rem' }}>
              <strong>✅ Tokens Exchanged Successfully!</strong> - Access token, refresh token, and ID token have been received.
            </div>
          )}
          {userInfo && (
            <div style={{ marginTop: '0.5rem', padding: '0.75rem', background: 'rgba(255,255,255,0.2)', borderRadius: '0.5rem' }}>
              <strong>👤 User Information Retrieved!</strong> - User profile data has been successfully fetched.
            </div>
          )}
        </div>
      )}

      {/* Centralized Success Messages - Bottom */}
      <CentralizedSuccessMessage position="bottom" />

    <EnhancedStepFlowV2
      steps={steps}
      title="🚀 Enhanced Authorization Code Flow"
      persistKey="enhanced-authz-code"
      autoAdvance={false}
      showDebugInfo={true}
      allowStepJumping={true}
      initialStepIndex={currentStepIndex}
      onStepChange={useCallback((stepIndex) => {
        console.log('🔔 [EnhancedAuthorizationCodeFlowV2] Step changed to:', stepIndex);
        setCurrentStepIndex(stepIndex);
      }, [])}
      onStepComplete={useCallback((stepId, result) => {
        console.log('✅ [EnhancedAuthorizationCodeFlowV2] Step completed:', stepId, result);
        // The step completion is already handled by the EnhancedStepFlowV2 component
        // This callback is for any additional logic we might need
      }, [])}
    />

      {/* Authorization Request Modal */}
      <AuthorizationRequestModal
        isOpen={showRedirectModal}
        onClose={handleRedirectModalClose}
        onProceed={handleRedirectModalProceed}
        authorizationUrl={redirectUrl}
        requestParams={redirectParams}
      />

      {/* Authorization Success Modal */}
      {showAuthSuccessModal && flowConfig.showSuccessModal && (
        <ModalOverlay onClick={() => setShowAuthSuccessModal(false)}>
          <ModalContent onClick={(e) => e.stopPropagation()}>
            <ModalHeader>
              <FiCheckCircle size={48} style={{ color: '#22c55e', marginBottom: '1rem' }} />
              <ModalTitle>🎉 Authorization Successful!</ModalTitle>
              <ModalSubtitle>
                You've successfully returned from PingOne authentication
              </ModalSubtitle>
            </ModalHeader>

            <ModalBody>
              <SuccessSection>
                <SuccessTitle>
                  <FiCode />
                  Authorization Code Received
                </SuccessTitle>
                <CodeDisplay>{authCode}</CodeDisplay>
              </SuccessSection>

              {tokens && (
                <SuccessSection>
                  <SuccessTitle>
                    <FiKey />
                    Tokens Exchanged Successfully
                  </SuccessTitle>
                  <div style={{ fontSize: '0.875rem' }}>
                    <div>✅ Access Token: <strong style={{ color: '#1e40af' }}>{tokens.access_token ? 'Received' : 'Missing'}</strong></div>
                    <div>✅ Refresh Token: <strong style={{ color: '#1e40af' }}>{tokens.refresh_token ? 'Received' : 'Missing'}</strong></div>
                    <div>✅ ID Token: <strong style={{ color: '#1e40af' }}>{tokens.id_token ? 'Received' : 'Missing'}</strong></div>
                    <div>Token Type: <strong style={{ color: '#1e40af' }}>{tokens.token_type || 'Bearer'}</strong></div>
                    <div>Expires In: <strong style={{ color: '#1e40af' }}>{tokens.expires_in ? `${tokens.expires_in} seconds` : 'Unknown'}</strong></div>
                    <div>Scope: <strong style={{ color: '#1e40af' }}>{tokens.scope || 'Not specified'}</strong></div>
                  </div>
                </SuccessSection>
              )}

              {userInfo && (
                <SuccessSection>
                  <SuccessTitle>
                    <FiUser />
                    User Information Retrieved
                  </SuccessTitle>
                  <div style={{ fontSize: '0.875rem' }}>
                    <div>Name: {userInfo.name || 'Not provided'}</div>
                    <div>Email: {userInfo.email || 'Not provided'}</div>
                    <div>Subject: {userInfo.sub || 'Not provided'}</div>
                  </div>
                </SuccessSection>
              )}

              {!tokens && (
                <div style={{ 
                  background: '#fef3c7', 
                  border: '1px solid #f59e0b', 
                  borderRadius: '0.5rem', 
                  padding: '1rem',
                  textAlign: 'center'
                }}>
                  <FiClock style={{ marginRight: '0.5rem' }} />
                  <strong>Next Step:</strong> Proceed to exchange your authorization code for tokens
                </div>
              )}
            </ModalBody>

            <ModalFooter>
              <ModalButton 
                $primary 
                $loading={isModalLoading}
                disabled={isModalLoading}
                onClick={async () => {
                  setIsModalLoading(true);
                  try {
                    // Add a small delay to show the spinner
                    await new Promise(resolve => setTimeout(resolve, 500));
                    
                    console.log('🔔 [EnhancedAuthorizationCodeFlowV2] Modal button clicked - current step:', currentStepIndex);
                    
                    // Close the modal first
                    setShowAuthSuccessModal(false);
                    
                    // If we're already on step 5 (exchange-tokens), just close the modal
                    if (currentStepIndex === 5) {
                      console.log('✅ [EnhancedAuthorizationCodeFlowV2] Already on step 5, just closing modal');
                      setIsModalLoading(false);
                      return;
                    }
                    
                    // Otherwise, advance to step 5
                    console.log('🔄 [EnhancedAuthorizationCodeFlowV2] Advancing to step 5 (exchange-tokens)');
                    
                    // Clear any existing step storage
                    sessionStorage.removeItem('enhanced-authz-code-v2-step');
                    
                    // Use URL redirect to force a fresh page load with the correct step
                    const currentUrl = new URL(window.location.href);
                    currentUrl.searchParams.set('step', '5');
                    currentUrl.searchParams.set('action', 'exchange-tokens');
                    // Preserve authorization code if it exists
                    if (authCode) {
                      currentUrl.searchParams.set('code', authCode);
                    }
                    if (state) {
                      currentUrl.searchParams.set('state', state);
                    }
                    // Add cache-busting parameter
                    currentUrl.searchParams.set('t', Date.now().toString());
                    
                    console.log('🔄 [EnhancedAuthorizationCodeFlowV2] Redirecting to:', currentUrl.toString());
                    
                    // Force a hard redirect to ensure clean state
                    window.location.href = currentUrl.toString();
                    
                  } catch (error) {
                    console.error('❌ [EnhancedAuthorizationCodeFlowV2] Error in modal button click:', error);
                    setIsModalLoading(false);
                  }
                }}
              >
                {isModalLoading ? 'Processing...' : 'Continue with Flow'}
              </ModalButton>
            </ModalFooter>
          </ModalContent>
        </ModalOverlay>
      )}
    </div>
  );
};

export default EnhancedAuthorizationCodeFlowV2;
