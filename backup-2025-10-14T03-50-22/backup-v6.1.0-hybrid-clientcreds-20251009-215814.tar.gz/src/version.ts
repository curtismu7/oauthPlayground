export const APP_VERSION = '6.0.1';
