// src/pages/flows/OIDCImplicitFlowV5_Full.tsx
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
	FiAlertCircle,
	FiAlertTriangle,
	FiCheckCircle,
	FiChevronDown,
	FiClock,
	FiCode,
	FiCopy,
	FiExternalLink,
	FiGlobe,
	FiInfo,
	FiKey,
	FiRefreshCw,
	FiSettings,
	FiShield,
} from 'react-icons/fi';
import styled from 'styled-components';
import AudienceParameterInput from '../../components/AudienceParameterInput';
import ClaimsRequestBuilder, {
	ClaimsRequestStructure,
} from '../../components/ClaimsRequestBuilder';
import { CodeExamplesDisplay } from '../../components/CodeExamplesDisplay';
import ColoredUrlDisplay from '../../components/ColoredUrlDisplay';
import DisplayParameterSelector, { DisplayMode } from '../../components/DisplayParameterSelector';
import { EnhancedApiCallDisplay } from '../../components/EnhancedApiCallDisplay';
import EnhancedFlowInfoCard from '../../components/EnhancedFlowInfoCard';
import EnhancedPromptSelector, { PromptValue } from '../../components/EnhancedPromptSelector';
import FlowSequenceDisplay from '../../components/FlowSequenceDisplay';
import LocalesParameterInput from '../../components/LocalesParameterInput';
import LoginSuccessModal from '../../components/LoginSuccessModal';
import PingOneApplicationConfig, {
	type PingOneApplicationState,
} from '../../components/PingOneApplicationConfig';
import ResourceParameterInput from '../../components/ResourceParameterInput';
import ResponseModeSelector from '../../components/response-modes/ResponseModeSelector';
import SecurityFeaturesDemo from '../../components/SecurityFeaturesDemo';
import { StepNavigationButtons } from '../../components/StepNavigationButtons';
import type { StepCredentials } from '../../components/steps/CommonSteps';
// Import components
import TokenIntrospect from '../../components/TokenIntrospect';
import { useUISettings } from '../../contexts/UISettingsContext';
import { useImplicitFlowController } from '../../hooks/useImplicitFlowController';
import { usePageScroll } from '../../hooks/usePageScroll';
import AuthenticationModalService from '../../services/authenticationModalService';
import ComprehensiveCredentialsService from '../../services/comprehensiveCredentialsService';
import { CopyButtonService } from '../../services/copyButtonService';
import { validateForStep } from '../../services/credentialsValidationService';
import { EnhancedApiCallDisplayService } from '../../services/enhancedApiCallDisplayService';
import { FlowCompletionConfigs, FlowCompletionService } from '../../services/flowCompletionService';
// Import shared services
import { FlowConfigurationService } from '../../services/flowConfigurationService';
import { FlowHeader } from '../../services/flowHeaderService';
import { FlowLayoutService } from '../../services/flowLayoutService';
import { getFlowSequence } from '../../services/flowSequenceService';
import FlowStateService from '../../services/flowStateService';
import { FlowStepNavigationService } from '../../services/flowStepNavigationService';
import { FlowUIService } from '../../services/flowUIService';
import { ImplicitFlowSharedService } from '../../services/implicitFlowSharedService';
import { oidcDiscoveryService } from '../../services/oidcDiscoveryService';
import { useResponseModeIntegration } from '../../services/responseModeIntegrationService';
import {
	IntrospectionApiCallData,
	TokenIntrospectionService,
} from '../../services/tokenIntrospectionService';
import { UISettingsService } from '../../services/uiSettingsService';
import { UnifiedTokenDisplayService } from '../../services/unifiedTokenDisplayService';
import { storeFlowNavigationState } from '../../utils/flowNavigation';
import { decodeJWTHeader } from '../../utils/jwks';
import { v4ToastManager } from '../../utils/v4ToastMessages';

// Import extracted styles and config

// Get all UI components from the shared service
const {
	Container,
	ContentWrapper,
	MainCard,
	StepHeader,
	StepHeaderLeft,
	VersionBadge,
	StepHeaderTitle,
	StepHeaderSubtitle,
	StepHeaderRight,
	StepNumber,
	StepTotal,
	StepContentWrapper,
	CollapsibleSection,
	CollapsibleHeaderButton,
	CollapsibleTitle,
	CollapsibleContent,
	InfoBox,
	InfoTitle,
	InfoText,
	StrongText,
	InfoList,
	ActionRow,
	Button,
	HighlightedActionButton,
	HighlightBadge,
	CodeBlock,
	GeneratedContentBox,
	GeneratedLabel,
	ParameterGrid,
	ParameterLabel,
	ParameterValue,
	FlowDiagram,
	FlowStep,
	FlowStepNumber,
	FlowStepContent,
	SectionDivider,
	ResultsSection,
	ResultsHeading,
	HelperText,
	ExplanationSection,
	ExplanationHeading,
	NextSteps,
} = FlowUIService.getFlowUIComponents();

// Local CollapsibleToggleIcon that accepts children
const CollapsibleToggleIcon = styled.span<{ $collapsed?: boolean }>`
	display: inline-flex;
	align-items: center;
	justify-content: center;
	width: 32px;
	height: 32px;
	border-radius: 50%;
	background: #3b82f6;
	color: white;
	box-shadow: 0 6px 16px #3b82f633;
	transition: background 0.2s ease, color 0.2s ease, transform 0.2s ease;
	transform: ${({ $collapsed }) => ($collapsed ? 'rotate(0deg)' : 'rotate(180deg)')};

	svg {
		width: 16px;
		height: 16px;
	}
`;

import {
	DEFAULT_APP_CONFIG,
	FLOW_TYPE,
	INTRO_SECTION_KEYS,
	type IntroSectionKey,
	STEP_METADATA,
} from './config/OIDCImplicitFlow.config';

// Import step components

// Requirements components now generated by FlowLayoutService
const RequirementsIndicator = FlowLayoutService.getRequirementsIndicatorStyles();
const RequirementsIcon = FlowLayoutService.getRequirementsIconStyles();
const RequirementsText = FlowLayoutService.getRequirementsTextStyles();

const OIDCImplicitFlowV6: React.FC = () => {
	const controller = useImplicitFlowController({
		flowKey: 'oidc-implicit-v5',
		defaultFlowVariant: 'oidc',
		enableDebugger: true,
	});

	// Initialize shared services
	const configService = FlowConfigurationService.createOAuthImplicitConfig();
	const [credentials, setCredentials] = useState<StepCredentials>(() => {
		// Initialize from controller.credentials first, then fall back to stored config
		const controllerCreds = controller.credentials;
		if (controllerCreds && (controllerCreds.environmentId || controllerCreds.clientId)) {
			return controllerCreds;
		}

		const stored = configService.loadConfiguration();
		return (
			stored || {
				environmentId: '',
				clientId: '',
				clientSecret: '',
				redirectUri:
					require('../../services/flowRedirectUriService').FlowRedirectUriService.getDefaultRedirectUri(
						'oidc-implicit-v6'
					),
				scope: 'openid profile email',
				scopes: 'openid profile email',
				responseType: 'id_token token',
				grantType: '',
				clientAuthMethod: 'none',
			}
		);
	});

	// Keep local credentials in sync with controller credentials
	useEffect(() => {
		ImplicitFlowSharedService.CredentialsSync.syncCredentials(
			'oidc',
			controller.credentials,
			setCredentials
		);
	}, [controller.credentials]);

	// Response mode integration using centralized service
	const responseModeIntegration = useResponseModeIntegration({
		flowKey: 'implicit',
		credentials: credentials,
		setCredentials: setCredentials,
		logPrefix: '[🔐 OIDC-IMPLICIT]',
	});

	const { responseMode, setResponseMode: setResponseModeInternal } = responseModeIntegration;

	// Wrapper to update both local and controller credentials when response mode changes
	const setResponseMode = useCallback(
		(mode: string) => {
			console.log('[OIDC Implicit V5] Response mode changing to:', mode);
			setResponseModeInternal(mode);
			// Also update controller credentials
			const updated = { ...controller.credentials, responseMode: mode };
			controller.setCredentials(updated);
			setCredentials(updated);
		},
		[setResponseModeInternal, controller, setCredentials]
	);

	// Ensure page starts at top
	usePageScroll({ pageName: 'OIDC Implicit Flow V5', force: true });

	const { settings } = useUISettings();
	const { showApiCallExamples } = settings;

	// Step navigation via FlowStateService
	const [currentStep, setCurrentStep] = useState(0);
	const initialStepAppliedRef = useRef(false);
	const initialStepRef = useRef(0);

	useEffect(() => {
		if (initialStepAppliedRef.current) {
			return;
		}
		const initialStep = ImplicitFlowSharedService.StepRestoration.getInitialStep();
		initialStepRef.current = initialStep;
		setCurrentStep(initialStep);
		initialStepAppliedRef.current = true;
	}, []);

	useEffect(() => {
		if (initialStepRef.current < 2) {
			return;
		}
		const hasTokenFragment =
			typeof window !== 'undefined' && window.location.hash?.includes('access_token');
		if (!controller.tokens && !hasTokenFragment) {
			initialStepRef.current = 0;
			setCurrentStep(0);
			try {
				sessionStorage.removeItem('restore_step');
			} catch (error) {
				console.warn(
					'[OIDCImplicitFlowV6] Failed to clear restore_step from sessionStorage',
					error
				);
			}
		}
	}, [controller.tokens]);

	// Collapse all sections by default for cleaner UI
	const shouldCollapseAll = true;

	const [pingOneConfig, setPingOneConfig] = useState<PingOneApplicationState>(DEFAULT_APP_CONFIG);
	const [introspectionApiCall, setIntrospectionApiCall] = useState<IntrospectionApiCallData | null>(
		null
	);
	const [collapsedSections, setCollapsedSections] = useState(
		ImplicitFlowSharedService.CollapsibleSections.getDefaultState
	);
	const [showSuccessModal, setShowSuccessModal] = useState<boolean>(false);
	const [showRedirectModal, setShowRedirectModal] = useState<boolean>(false);
	const [completionCollapsed, setCompletionCollapsed] = useState(false);
	const [displayMode, setDisplayMode] = useState<DisplayMode>('page');
	const [claimsRequest, setClaimsRequest] = useState<ClaimsRequestStructure | null>(null);
	// Internationalization - SAVED FOR LATER
	// const [uiLocales, setUiLocales] = useState<string>('');
	// const [claimsLocales, setClaimsLocales] = useState<string>('');
	const [audience, setAudience] = useState<string>('');
	const [resources, setResources] = useState<string[]>([]);
	const [promptValues, setPromptValues] = useState<PromptValue[]>([]);

	// All useEffect hooks AFTER state declarations
	useEffect(() => {
		ImplicitFlowSharedService.TokenFragmentProcessor.processTokenFragment(
			controller,
			setCurrentStep,
			setShowSuccessModal
		);
	}, []); // Only run once on mount, not when controller changes

	useEffect(() => {
		ImplicitFlowSharedService.CredentialsSync.syncCredentials(
			'oidc',
			controller.credentials,
			setCredentials
		);
	}, [controller.credentials]);

	useEffect(() => {
		ImplicitFlowSharedService.ResponseTypeEnforcer.enforceResponseType(
			'oidc',
			credentials,
			setCredentials
		);
	}, [credentials, setCredentials]);

	useEffect(() => {
		ImplicitFlowSharedService.StepRestoration.scrollToTopOnStepChange();
	}, [currentStep]);

	// Step completions are now handled by FlowStateService

	const toggleSection =
		ImplicitFlowSharedService.CollapsibleSections.createToggleHandler(setCollapsedSections);

	const savePingOneConfig = useCallback((config: PingOneApplicationState) => {
		ImplicitFlowSharedService.CredentialsHandlers.createPingOneConfigHandler(
			'oidc',
			setPingOneConfig
		)(config);
	}, []);

	const handleGenerateAuthUrl = useCallback(async () => {
		await ImplicitFlowSharedService.Authorization.generateAuthUrl('oidc', credentials, controller);
	}, [controller, credentials]);

	const handleOpenAuthUrl = useCallback(() => {
		if (ImplicitFlowSharedService.Authorization.openAuthUrl(controller.authUrl)) {
			setShowRedirectModal(true);
		}
	}, [controller]);

	const handleConfirmRedirect = useCallback(() => {
		setShowRedirectModal(false);
		controller.handleRedirectAuthorization();
	}, [controller]);

	const handleCancelRedirect = useCallback(() => {
		setShowRedirectModal(false);
	}, []);

	const navigateToTokenManagement = useCallback(() => {
		ImplicitFlowSharedService.TokenManagement.navigateToTokenManagement(
			'oidc',
			controller.tokens,
			credentials,
			currentStep
		);
	}, [controller.tokens, credentials, currentStep]);

	const handleResetFlow = useCallback(() => {
		controller.resetFlow();
		setCurrentStep(0);
	}, [controller]);

	const handleStartOver = useCallback(() => {
		const flowKey = 'oidc-implicit-v5';
		sessionStorage.removeItem(`${flowKey}-tokens`);
		sessionStorage.removeItem('restore_step');
		sessionStorage.removeItem(`redirect_uri_${flowKey}`);
		controller.clearStepResults?.();
		setCurrentStep(0);
		console.log('🔄 [OIDCImplicitFlowV6] Starting over: cleared tokens, keeping credentials');
		v4ToastManager.showSuccess('Flow restarted', {
			description: 'Tokens cleared. Credentials preserved.',
		});
	}, [controller]);

	const handleIntrospectToken = useCallback(
		async (token: string) => {
			if (!credentials.environmentId || !credentials.clientId) {
				throw new Error('Missing PingOne credentials. Please configure your credentials first.');
			}

			const request = {
				token: token,
				clientId: credentials.clientId,
				// No client secret for implicit flow (public client)
				tokenTypeHint: 'access_token' as const,
			};

			try {
				// Determine the appropriate authentication method for implicit flow
				// Implicit flows are public clients and typically don't use client secrets
				const authMethod = 'none'; // Implicit flows don't use client authentication for introspection

				// Use the reusable service to create API call data and execute introspection
				const result = await TokenIntrospectionService.introspectToken(
					request,
					'implicit',
					'/api/introspect-token', // Use proxy endpoint
					`https://auth.pingone.com/${credentials.environmentId}/as/introspect`, // Pass PingOne URL as introspection endpoint
					authMethod // Token auth method
				);

				// Set the API call data for display
				setIntrospectionApiCall(result.apiCall);

				return result.response;
			} catch (error) {
				// Create error API call using reusable service
				const errorApiCall = TokenIntrospectionService.createErrorApiCall(
					request,
					'implicit',
					error instanceof Error ? error.message : 'Unknown error',
					500,
					`https://auth.pingone.com/${credentials.environmentId}/as/introspect`
				);

				setIntrospectionApiCall(errorApiCall);
				throw error;
			}
		},
		[credentials]
	);

	// Validation and navigation functions using services
	const isStepValid = useCallback(
		(stepIndex: number) => {
			switch (stepIndex) {
				case 0:
					return true;
				case 1:
					return Boolean(controller.authUrl);
				case 2:
					return Boolean(controller.tokens);
				case 3:
					return Boolean(controller.tokens);
				case 4:
					return true;
				case 5:
					return true;
				default:
					return false;
			}
		},
		[controller.authUrl, controller.tokens]
	);

	const getStepRequirements = useCallback((stepIndex: number) => {
		switch (stepIndex) {
			case 1:
				return ['Configure credentials and generate authorization URL'];
			case 2:
				return ['Complete authorization and receive tokens'];
			case 3:
				return ['Validate and inspect received tokens'];
			case 4:
				return ['Review security features and best practices'];
			case 5:
				return ['Review flow completion and next steps'];
			default:
				return [];
		}
	}, []);

	const { handleNext, handlePrev, canNavigateNext } =
		FlowStepNavigationService.createStepNavigationHandlers({
			currentStep,
			totalSteps: STEP_METADATA.length,
			isStepValid: (stepIndex: number) => {
				// Add step validation logic here if needed
				return true;
			},
		});

	// Create the actual handlers that use setCurrentStep
	const handleNextStep = useCallback(
		() => handleNext(setCurrentStep),
		[handleNext, setCurrentStep]
	);
	const handlePrevStep = useCallback(
		() => handlePrev(setCurrentStep),
		[handlePrev, setCurrentStep]
	);

	// Override canNavigateNext to include step validation
	const validatedCanNavigateNext = useCallback(() => {
		return canNavigateNext() && isStepValid(currentStep);
	}, [canNavigateNext, isStepValid, currentStep]);

	// Override handleNext to include step validation
	const validatedHandleNext = useCallback(() => {
		ImplicitFlowSharedService.Navigation.handleNext(
			currentStep,
			credentials,
			'oidc',
			isStepValid,
			handleNext
		);
	}, [handleNext, isStepValid, currentStep, credentials]);

	const renderStepContent = useMemo(() => {
		const tokens = controller.tokens;

		switch (currentStep) {
			case 0:
				return (
					<>
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() => toggleSection('overview')}
								aria-expanded={!collapsedSections.overview}
							>
								<CollapsibleTitle>
									<FiInfo /> Implicit Flow Overview
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.overview}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.overview && (
								<CollapsibleContent>
									<InfoBox $variant="info">
										<FiInfo size={20} />
										<div>
											<InfoTitle>OIDC Implicit Flow (Authentication + Authorization)</InfoTitle>
											<InfoText>
												This is the OpenID Connect Implicit Flow that returns both an{' '}
												<StrongText>ID Token and Access Token</StrongText>. It's designed for{' '}
												<StrongText>user authentication AND authorization</StrongText>, providing
												verified identity claims about the user.
											</InfoText>
											<InfoText style={{ marginTop: '0.5rem', fontSize: '0.875rem' }}>
												✅ This flow provides user identity information (who they are) via the ID
												Token, plus API access via the Access Token.
											</InfoText>
										</div>
									</InfoBox>

									<InfoBox $variant="warning">
										<FiAlertCircle size={20} />
										<div>
											<InfoTitle>Legacy Flow - Use with Caution</InfoTitle>
											<InfoText>
												The Implicit Flow is considered legacy and less secure than Authorization
												Code with PKCE. Tokens are exposed in the URL, making them vulnerable to
												interception. Use this flow only if you have specific requirements that
												prevent using Authorization Code + PKCE.
											</InfoText>
										</div>
									</InfoBox>

									<GeneratedContentBox>
										<GeneratedLabel>OIDC vs OAuth 2.0 Implicit Comparison</GeneratedLabel>
										<ParameterGrid>
											<div>
												<ParameterLabel>Tokens Returned</ParameterLabel>
												<ParameterValue style={{ color: '#10b981', fontWeight: 'bold' }}>
													ID Token + Access Token
												</ParameterValue>
											</div>
											<div>
												<ParameterLabel>Purpose</ParameterLabel>
												<ParameterValue style={{ color: '#10b981', fontWeight: 'bold' }}>
													Authentication + Authorization
												</ParameterValue>
											</div>
											<div>
												<ParameterLabel>Spec Layer</ParameterLabel>
												<ParameterValue>OpenID Connect (on OAuth 2.0)</ParameterValue>
											</div>
											<div>
												<ParameterLabel>Nonce Requirement</ParameterLabel>
												<ParameterValue style={{ color: '#dc2626', fontWeight: 'bold' }}>
													REQUIRED for security
												</ParameterValue>
											</div>
											<div>
												<ParameterLabel>Scope Requirements</ParameterLabel>
												<ParameterValue style={{ fontWeight: 'bold' }}>
													Must include 'openid'
												</ParameterValue>
											</div>
											<div>
												<ParameterLabel>User Identity</ParameterLabel>
												<ParameterValue style={{ color: '#10b981', fontWeight: 'bold' }}>
													PROVIDED in ID Token
												</ParameterValue>
											</div>
											<div style={{ gridColumn: '1 / -1' }}>
												<ParameterLabel>Use Case</ParameterLabel>
												<ParameterValue>
													Authenticate user identity + delegate API access (e.g., "Sign in with
													Google")
												</ParameterValue>
											</div>
										</ParameterGrid>
									</GeneratedContentBox>

									<ExplanationSection>
										<ExplanationHeading>
											<FiShield /> How OIDC Implicit Flow Works
										</ExplanationHeading>
										<InfoText>
											In the OIDC Implicit Flow, both ID token and access token are returned
											directly from the authorization endpoint in the URL fragment (#), without an
											intermediate authorization code exchange step. The nonce parameter is REQUIRED
											to protect against replay attacks on the ID token.
										</InfoText>
									</ExplanationSection>

									<FlowDiagram>
										{[
											'User clicks login to start the flow',
											'App redirects to PingOne with authorization request (includes nonce)',
											'User authenticates and approves scopes',
											'PingOne returns ID token and access token directly in URL fragment',
											'App extracts tokens, validates ID token signature and nonce claim',
										].map((description, index) => (
											<FlowStep key={description}>
												<FlowStepNumber>{index + 1}</FlowStepNumber>
												<FlowStepContent>
													<StrongText>{description}</StrongText>
												</FlowStepContent>
											</FlowStep>
										))}
									</FlowDiagram>
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						{/* Comprehensive Credentials Service - replaces all credential configuration components */}
						<ComprehensiveCredentialsService
							// Flow identification
							flowType="oidc-implicit-v6"
							// Pass individual credential props
							environmentId={controller.credentials?.environmentId || ''}
							clientId={controller.credentials?.clientId || ''}
							clientSecret={controller.credentials?.clientSecret || ''}
							redirectUri={controller.credentials?.redirectUri}
							scopes={
								controller.credentials?.scope ||
								controller.credentials?.scopes ||
								'openid profile email'
							}
							loginHint={controller.credentials?.loginHint || ''}
							postLogoutRedirectUri={
								controller.credentials?.postLogoutRedirectUri ||
								'https://localhost:3000/logout-callback'
							}
							// Individual change handlers
							onEnvironmentIdChange={(value) => {
								const updated = { ...controller.credentials, environmentId: value };
								controller.setCredentials(updated);
								setCredentials(updated);
								console.log('[OIDC Implicit V5] Environment ID updated:', value);
							}}
							onClientIdChange={(value) => {
								const updated = { ...controller.credentials, clientId: value };
								controller.setCredentials(updated);
								setCredentials(updated);
								console.log('[OIDC Implicit V5] Client ID updated:', value);
							}}
							onClientSecretChange={(value) => {
								const updated = { ...controller.credentials, clientSecret: value };
								controller.setCredentials(updated);
								setCredentials(updated);
							}}
							onRedirectUriChange={(value) => {
								const updated = { ...controller.credentials, redirectUri: value };
								controller.setCredentials(updated);
								setCredentials(updated);
								console.log('[OIDC Implicit V5] Redirect URI updated:', value);
								// Auto-save redirect URI to persist across refreshes
								controller
									.saveCredentials()
									.then(() => {
										v4ToastManager.showSuccess('Redirect URI saved successfully!');
									})
									.catch((error) => {
										console.error('[OIDC Implicit V5] Failed to save redirect URI:', error);
										v4ToastManager.showError('Failed to save redirect URI');
									});
							}}
							onScopesChange={(value) => {
								// Ensure openid is always included (required for OIDC & PingOne)
								const scopes = value.split(/\s+/).filter((s) => s.length > 0);
								if (!scopes.includes('openid')) {
									scopes.unshift('openid');
									value = scopes.join(' ');
									v4ToastManager.showWarning('Added required "openid" scope for OIDC compliance');
								}
								const updated = { ...controller.credentials, scope: value, scopes: value };
								controller.setCredentials(updated);
								setCredentials(updated);
							}}
							onLoginHintChange={(value) => {
								const updated = { ...controller.credentials, loginHint: value };
								controller.setCredentials(updated);
								setCredentials(updated);
							}}
							onPostLogoutRedirectUriChange={(value) => {
								const updated = { ...controller.credentials, postLogoutRedirectUri: value };
								controller.setCredentials(updated);
								setCredentials(updated);
								console.log('[OIDC Implicit V6] Post-Logout Redirect URI updated:', value);
							}}
							// Save handler for credentials
							onSave={async () => {
								try {
									await controller.saveCredentials();
									v4ToastManager.showSuccess('Credentials saved successfully!');
								} catch (error) {
									console.error('[OIDC Implicit V5] Failed to save credentials:', error);
									v4ToastManager.showError('Failed to save credentials');
								}
							}}
							// Discovery handler - environment ID is auto-populated by the service
							onDiscoveryComplete={(result) => {
								console.log('[OIDC Implicit V6] OIDC Discovery completed:', result);
								// Extract environment ID from issuer URL using the standard service
								if (result.issuerUrl) {
									const extractedEnvId = oidcDiscoveryService.extractEnvironmentId(
										result.issuerUrl
									);
									if (extractedEnvId) {
										implicitFlowActions.setCredentials({
											...implicitFlowState.credentials,
											environmentId: extractedEnvId,
										});
										console.log(
											'[OIDC Implicit V6] Auto-extracted Environment ID:',
											extractedEnvId
										);
									}
								}
							}}
							// PingOne Advanced Configuration (correct prop names)
							pingOneAppState={pingOneConfig}
							onPingOneAppStateChange={savePingOneConfig}
							// Configuration
							requireClientSecret={false}
							showAdvancedConfig={false} // ❌ Implicit flow deprecated, no token endpoint for client auth
							defaultCollapsed={shouldCollapseAll}
						/>
					</>
				);

			case 1:
				return (
					<>
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() => toggleSection('authRequestOverview')}
								aria-expanded={!collapsedSections.authRequestOverview}
							>
								<CollapsibleTitle>
									<FiGlobe /> Authorization Request Overview
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.authRequestOverview}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.authRequestOverview && (
								<CollapsibleContent>
									<InfoBox $variant="info">
										<FiGlobe size={20} />
										<div>
											<InfoTitle>Building the Authorization URL</InfoTitle>
											<InfoText>
												The authorization URL includes all OAuth parameters. Unlike Authorization
												Code flow, the response_type is 'token' or 'id_token token', telling PingOne
												to return tokens directly instead of an authorization code.
											</InfoText>
										</div>
									</InfoBox>

									<InfoBox $variant="danger">
										<FiAlertCircle size={20} />
										<div>
											<InfoTitle>OIDC Implicit Flow Specific Parameters</InfoTitle>
											<InfoList>
												<li>
													<StrongText>response_type:</StrongText> id_token token (ID Token + Access
													Token)
												</li>
												<li>
													<StrongText>nonce:</StrongText>{' '}
													<span style={{ color: '#dc2626', fontWeight: 'bold' }}>
														REQUIRED to protect ID Token
													</span>{' '}
													from replay attacks
												</li>
												<li>
													<StrongText>state:</StrongText> CSRF protection (recommended)
												</li>
												<li>
													<StrongText>No PKCE:</StrongText> Implicit flow doesn't support PKCE
												</li>
												<li>
													<StrongText>scope:</StrongText> Must include 'openid' for OIDC
												</li>
											</InfoList>
										</div>
									</InfoBox>

									{/* Nonce Security Educational Section */}
									<CollapsibleSection>
										<CollapsibleHeaderButton
											onClick={() =>
												setCollapsedSections((prev) => ({
													...prev,
													nonceEducation: !prev.nonceEducation,
												}))
											}
											aria-expanded={!collapsedSections.nonceEducation}
										>
											<CollapsibleTitle>
												<FiShield /> 🔐 OIDC Security: Nonce Parameter (Replay Attack Protection) -
												REQUIRED
											</CollapsibleTitle>
											<CollapsibleToggleIcon $collapsed={collapsedSections.nonceEducation}>
												<FiChevronDown />
											</CollapsibleToggleIcon>
										</CollapsibleHeaderButton>
										{!collapsedSections.nonceEducation && (
											<CollapsibleContent>
												<InfoBox $variant="warning">
													<FiShield size={24} />
													<div>
														<InfoTitle
															style={{ fontSize: '1rem', fontWeight: '600', color: '#b45309' }}
														>
															What is Nonce?
														</InfoTitle>
														<InfoText style={{ marginTop: '0.75rem', color: '#78350f' }}>
															The nonce (number used once) is a cryptographically random string that
															binds your client session to the ID token and prevents replay attacks.
														</InfoText>
														<InfoText style={{ marginTop: '0.5rem', color: '#78350f' }}>
															<strong>How it works:</strong>
														</InfoText>
														<ul
															style={{
																marginTop: '0.5rem',
																paddingLeft: '1.5rem',
																color: '#78350f',
															}}
														>
															<li>
																Your client generates a unique random nonce value for each
																authorization request
															</li>
															<li>
																The nonce is sent in the authorization request to the identity
																provider
															</li>
															<li>
																The authorization server includes the nonce claim in the ID token
															</li>
															<li>
																Your client MUST validate that the nonce in the ID token matches the
																original nonce
															</li>
														</ul>
														<InfoText
															style={{ marginTop: '0.75rem', color: '#78350f', fontWeight: 'bold' }}
														>
															⚠️ <strong>Security Critical:</strong> Without nonce validation, an
															attacker could intercept an old ID token and replay it to impersonate
															a user. This playground automatically generates and validates nonce
															for educational purposes.
														</InfoText>
														<InfoText
															style={{ marginTop: '0.5rem', color: '#dc2626', fontWeight: 'bold' }}
														>
															🔴 <strong>OIDC Implicit Requirement:</strong> Unlike OAuth 2.0
															Implicit (which doesn't use nonce), OIDC Implicit REQUIRES nonce
															validation because it returns an ID Token containing sensitive user
															identity claims directly in the URL fragment.
														</InfoText>
														<InfoText
															style={{
																marginTop: '0.5rem',
																color: '#78350f',
																fontSize: '0.875rem',
																fontStyle: 'italic',
															}}
														>
															💡 <strong>Spec Reference:</strong> OIDC Core 1.0 Section 15.5.2
															REQUIRES nonce validation for Implicit Flow. This is mandatory, not
															optional.
														</InfoText>
													</div>
												</InfoBox>
											</CollapsibleContent>
										)}
									</CollapsibleSection>
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						<SectionDivider />

						{/* Response Mode Selection */}
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() =>
									setCollapsedSections((prev) => ({ ...prev, responseMode: !prev.responseMode }))
								}
								aria-expanded={!collapsedSections.responseMode}
							>
								<CollapsibleTitle>
									<FiSettings /> Response Mode Selection
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.responseMode}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.responseMode && (
								<CollapsibleContent>
									<ResponseModeSelector
										flowKey="implicit"
										responseType="id_token token"
										redirectUri={`${window.location.origin}/oidc-implicit-callback`}
										clientId={credentials.clientId}
										scope={credentials.scope || 'openid profile email'}
										state="random_state_123"
										nonce="random_nonce_456"
										defaultMode="fragment"
										readOnlyFlowContext={false}
										onModeChange={setResponseMode}
									/>
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						{/* Display Parameter */}
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() =>
									setCollapsedSections((prev) => ({ ...prev, displayMode: !prev.displayMode }))
								}
								aria-expanded={!collapsedSections.displayMode}
							>
								<CollapsibleTitle>
									<FiSettings /> Display Mode (OIDC UI Adaptation)
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.displayMode}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.displayMode && (
								<CollapsibleContent>
									<DisplayParameterSelector value={displayMode} onChange={setDisplayMode} />
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						{/* Advanced Claims Request */}
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() =>
									setCollapsedSections((prev) => ({ ...prev, claimsRequest: !prev.claimsRequest }))
								}
								aria-expanded={!collapsedSections.claimsRequest}
							>
								<CollapsibleTitle>
									<FiSettings /> Advanced Claims Request (Optional)
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.claimsRequest}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.claimsRequest && (
								<CollapsibleContent>
									<ClaimsRequestBuilder value={claimsRequest} onChange={setClaimsRequest} />
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						{/* Internationalization Parameters - SAVED FOR LATER */}
						{/* 
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() => setCollapsedSections(prev => ({ ...prev, i18n: !prev.i18n }))}
								aria-expanded={!collapsedSections.i18n}
							>
								<CollapsibleTitle>
									<FiSettings /> Internationalization (Optional)
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.i18n}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.i18n && (
								<CollapsibleContent>
									<LocalesParameterInput
										type="ui"
										value={uiLocales}
										onChange={setUiLocales}
									/>
									<LocalesParameterInput
										type="claims"
										value={claimsLocales}
										onChange={setClaimsLocales}
									/>
								</CollapsibleContent>
							)}
						</CollapsibleSection>
						*/}

						{/* Audience Parameter */}
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() =>
									setCollapsedSections((prev) => ({ ...prev, audience: !prev.audience }))
								}
								aria-expanded={!collapsedSections.audience}
							>
								<CollapsibleTitle>
									<FiSettings /> API Audience (Optional)
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.audience}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.audience && (
								<CollapsibleContent>
									<AudienceParameterInput value={audience} onChange={setAudience} flowType="oidc" />
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						{/* Resource Indicators */}
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() =>
									setCollapsedSections((prev) => ({ ...prev, resources: !prev.resources }))
								}
								aria-expanded={!collapsedSections.resources}
							>
								<CollapsibleTitle>
									<FiSettings /> Resource Indicators (Optional)
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.resources}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.resources && (
								<CollapsibleContent>
									<ResourceParameterInput
										value={resources}
										onChange={setResources}
										flowType="oidc"
									/>
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						{/* Enhanced Prompt Parameter */}
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() => setCollapsedSections((prev) => ({ ...prev, prompt: !prev.prompt }))}
								aria-expanded={!collapsedSections.prompt}
							>
								<CollapsibleTitle>
									<FiSettings /> Authentication Behavior (Optional)
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.prompt}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.prompt && (
								<CollapsibleContent>
									<EnhancedPromptSelector value={promptValues} onChange={setPromptValues} />
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						<SectionDivider />
						<ResultsSection>
							<ResultsHeading>
								<FiCheckCircle size={18} /> Build Authorization URL
							</ResultsHeading>
							<HelperText>
								Generate the authorization URL with Implicit flow parameters. Review it carefully
								before redirecting.
							</HelperText>

							{(!credentials.clientId || !credentials.environmentId) && (
								<InfoBox $variant="warning" style={{ marginBottom: '1.5rem' }}>
									<FiAlertCircle size={20} />
									<div>
										<InfoTitle>Missing Required Credentials</InfoTitle>
										<InfoText>
											<StrongText>Environment ID</StrongText> and <StrongText>Client ID</StrongText>{' '}
											are required to generate the authorization URL. Please go back to Step 0 to
											fill in these credentials first.
										</InfoText>
										<InfoText
											style={{ marginTop: '0.5rem', fontSize: '0.75rem', fontFamily: 'monospace' }}
										>
											DEBUG: Client ID: {credentials.clientId || 'EMPTY'} | Environment ID:{' '}
											{credentials.environmentId || 'EMPTY'}
											<br />
											Controller: Client ID: {controller.credentials?.clientId || 'EMPTY'} |
											Environment ID: {controller.credentials?.environmentId || 'EMPTY'}
										</InfoText>
									</div>
								</InfoBox>
							)}

							<ActionRow>
								<HighlightedActionButton
									onClick={handleGenerateAuthUrl}
									$priority="primary"
									disabled={
										!!controller.authUrl || !credentials.clientId || !credentials.environmentId
									}
									title={
										!credentials.clientId || !credentials.environmentId
											? `Complete Step 0: Fill in Environment ID and Client ID first (Client ID: ${credentials.clientId ? '✓' : '✗'}, Environment ID: ${credentials.environmentId ? '✓' : '✗'})`
											: 'Generate authorization URL with current credentials'
									}
								>
									{controller.authUrl ? <FiCheckCircle /> : <FiGlobe />}{' '}
									{controller.authUrl
										? 'Authorization URL Generated'
										: 'Generate Authorization URL'}
									<HighlightBadge>1</HighlightBadge>
								</HighlightedActionButton>

								{controller.authUrl && (
									<HighlightedActionButton onClick={handleOpenAuthUrl} $priority="success">
										<FiExternalLink /> Redirect to PingOne
										<HighlightBadge>2</HighlightBadge>
									</HighlightedActionButton>
								)}
							</ActionRow>

							{controller.authUrl && (
								<GeneratedContentBox>
									<GeneratedLabel>Generated Authorization URL</GeneratedLabel>
									<ColoredUrlDisplay
										url={controller.authUrl}
										label="OAuth 2.0 Implicit Flow Authorization URL"
										showCopyButton={true}
										showInfoButton={true}
										showOpenButton={true}
										onOpen={handleOpenAuthUrl}
									/>
								</GeneratedContentBox>
							)}
						</ResultsSection>
					</>
				);

			case 2:
				return (
					<>
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() => toggleSection('tokenResponseOverview')}
								aria-expanded={!collapsedSections.tokenResponseOverview}
							>
								<CollapsibleTitle>
									<FiCheckCircle /> Token Response Overview
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.tokenResponseOverview}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.tokenResponseOverview && (
								<CollapsibleContent>
									<InfoBox $variant="success">
										<FiCheckCircle size={20} />
										<div>
											<InfoTitle>Tokens Received Directly</InfoTitle>
											<InfoText>
												In Implicit Flow, tokens come back in the URL fragment (#) immediately after
												authorization. No token exchange step is needed, making it simpler but
												exposing tokens in the browser.
											</InfoText>
										</div>
									</InfoBox>
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						{/* Token Response Details Section */}
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() => toggleSection('tokenResponseDetails')}
								aria-expanded={!collapsedSections.tokenResponseDetails}
							>
								<CollapsibleTitle>
									<FiCode /> Token Response Details
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.tokenResponseDetails}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.tokenResponseDetails && (
								<CollapsibleContent>
									<InfoBox $variant="info">
										<FiInfo size={20} />
										<div>
											<InfoTitle>URL Fragment Response Format</InfoTitle>
											<InfoText>
												In OAuth 2.0 Implicit Flow, tokens are returned in the URL fragment (#) as
												key-value pairs. This allows the client to extract tokens without a
												server-side exchange.
											</InfoText>
										</div>
									</InfoBox>

									<InfoBox $variant="warning">
										<FiAlertTriangle size={20} />
										<div>
											<InfoTitle>Security Considerations</InfoTitle>
											<InfoList>
												<li>Tokens are visible in browser history and logs</li>
												<li>No refresh tokens are provided for security</li>
												<li>Tokens expire and require re-authentication</li>
												<li>Use HTTPS to protect tokens in transit</li>
											</InfoList>
										</div>
									</InfoBox>

									<CodeBlock>
										{`// Extract tokens from URL fragment
const hash = window.location.hash.substring(1);
const params = new URLSearchParams(hash);

const accessToken = params.get('access_token');
const tokenType = params.get('token_type');
const expiresIn = params.get('expires_in');
const scope = params.get('scope');
const state = params.get('state');

console.log('Access Token:', accessToken);
console.log('Token Type:', tokenType);
console.log('Expires In:', expiresIn + ' seconds');
console.log('Scope:', scope);`}
									</CodeBlock>
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						{tokens && (
							<CollapsibleSection>
								<CollapsibleHeaderButton
									onClick={() => toggleSection('tokenResponse')}
									aria-expanded={!collapsedSections.tokenResponse}
								>
									<CollapsibleTitle>
										<FiCheckCircle /> Token Response
									</CollapsibleTitle>
									<CollapsibleToggleIcon $collapsed={collapsedSections.tokenResponse}>
										<FiChevronDown />
									</CollapsibleToggleIcon>
								</CollapsibleHeaderButton>
								{!collapsedSections.tokenResponse && (
									<CollapsibleContent>
										<HelperText>
											Review the tokens received. In Implicit Flow, there is no refresh token.
										</HelperText>

										{/* Raw Response Display */}
										<GeneratedContentBox>
											<GeneratedLabel>Raw Token Response</GeneratedLabel>
											<CodeBlock>{JSON.stringify(tokens, null, 2)}</CodeBlock>
											<ActionRow>
												<CopyButtonService
													text={JSON.stringify(tokens, null, 2)}
													label="Copy JSON Response"
													variant="primary"
												/>
											</ActionRow>
										</GeneratedContentBox>

										{UnifiedTokenDisplayService.showTokens(tokens, 'oidc', 'oidc-implicit-v6', {
											showCopyButtons: true,
											showDecodeButtons: true,
										})}

										{/* Security Warnings */}
										<InfoBox $variant="warning">
											<FiAlertCircle size={20} />
											<div>
												<InfoTitle>No Refresh Token</InfoTitle>
												<InfoText>
													Implicit Flow does not provide refresh tokens for security reasons. When
													the access token expires, users must re-authenticate.
												</InfoText>
											</div>
										</InfoBox>

										<InfoBox $variant="danger">
											<FiAlertTriangle size={20} />
											<div>
												<InfoTitle>Token Security</InfoTitle>
												<InfoList>
													<li>Store tokens securely (not in localStorage)</li>
													<li>Use HTTPS for all token transmissions</li>
													<li>Implement proper token expiration handling</li>
													<li>Consider using Authorization Code flow for better security</li>
												</InfoList>
											</div>
										</InfoBox>
									</CollapsibleContent>
								)}
							</CollapsibleSection>
						)}

						{/* No Tokens State */}
						{!tokens && (
							<ResultsSection>
								<ResultsHeading>
									<FiClock size={18} /> Waiting for Tokens
								</ResultsHeading>
								<HelperText>
									Complete the authorization flow to receive tokens in this step.
								</HelperText>
								<InfoBox $variant="info">
									<FiInfo size={20} />
									<div>
										<InfoTitle>Next Steps</InfoTitle>
										<InfoList>
											<li>Go back to Step 1 and generate the authorization URL</li>
											<li>Click "Redirect to PingOne" to start authentication</li>
											<li>Complete authentication with PingOne</li>
											<li>Return here to see the received tokens</li>
										</InfoList>
									</div>
								</InfoBox>
							</ResultsSection>
						)}
					</>
				);

			case 3:
				return (
					<>
						<TokenIntrospect
							flowName="OpenID Connect Implicit Flow"
							flowVersion="V5"
							tokens={controller.tokens || {}}
							credentials={credentials as unknown as Record<string, unknown>}
							onResetFlow={handleResetFlow}
							onNavigateToTokenManagement={navigateToTokenManagement}
							onIntrospectToken={handleIntrospectToken}
							collapsedSections={{
								completionOverview: collapsedSections.completionOverview,
								completionDetails: collapsedSections.completionDetails,
								introspectionOverview: collapsedSections.introspectionOverview,
								introspectionDetails: collapsedSections.introspectionDetails,
								rawJson: false,
							}}
							onToggleSection={(section) => {
								if (
									section === 'completionOverview' ||
									section === 'completionDetails' ||
									section === 'introspectionOverview' ||
									section === 'introspectionDetails'
								) {
									toggleSection(section as IntroSectionKey);
								}
							}}
							completionMessage="You've completed the OpenID Connect Implicit Flow. Remember: this flow is legacy and less secure than Authorization Code + PKCE."
							nextSteps={[
								'Inspect or decode tokens using the Token Management tools.',
								'Note: No refresh token is provided in Implicit Flow.',
								'Verify ID token signature and nonce claim for security.',
								'Consider migrating to Authorization Code + PKCE for better security.',
							]}
						/>

						{/* API Call Display for Token Introspection */}
						{introspectionApiCall && (
							<EnhancedApiCallDisplay
								apiCall={introspectionApiCall}
								options={{
									showEducationalNotes: true,
									showFlowContext: true,
									urlHighlightRules:
										EnhancedApiCallDisplayService.getDefaultHighlightRules('implicit'),
								}}
							/>
						)}

						{/* API Call Display Section */}
						{controller.tokens?.access_token && showApiCallExamples && (
							<CollapsibleSection>
								<CollapsibleHeaderButton
									onClick={() => toggleSection('apiCallDisplay')}
									aria-expanded={!collapsedSections.apiCallDisplay}
								>
									<CollapsibleTitle>
										<FiCode /> Code Examples
									</CollapsibleTitle>
									<CollapsibleToggleIcon $collapsed={collapsedSections.apiCallDisplay}>
										<FiChevronDown />
									</CollapsibleToggleIcon>
								</CollapsibleHeaderButton>
								{!collapsedSections.apiCallDisplay && (
									<CollapsibleContent>
										<ResultsSection>
											<ResultsHeading>
												<FiCode size={18} /> Test Your Access Token
											</ResultsHeading>
											<HelperText>
												Use the access token to make authenticated API calls. Copy the curl command
												below to test your token with a PingOne API endpoint.
											</HelperText>

											<CodeExamplesDisplay
												flowType="implicit"
												stepId="step3"
												config={{
													baseUrl: 'https://auth.pingone.com',
													clientId: credentials.clientId || '',
													clientSecret: '', // Implicit flow doesn't use client secret
													redirectUri: credentials.redirectUri || '',
													scopes: credentials.scopes?.split(' ') || ['openid', 'profile'],
													environmentId: credentials.environmentId || '',
												}}
											/>

											<InfoBox $variant="info" style={{ marginTop: '1.5rem' }}>
												<FiInfo size={20} />
												<div>
													<InfoTitle>API Testing Tips</InfoTitle>
													<InfoText>
														• Replace <code>{'{environmentId}'}</code> with your actual PingOne
														environment ID
														<br />• The access token is valid for the scopes you requested
														<br />• Test with different API endpoints to verify token functionality
														<br />• Monitor token expiration and handle refresh scenarios
													</InfoText>
												</div>
											</InfoBox>
										</ResultsSection>
									</CollapsibleContent>
								)}
							</CollapsibleSection>
						)}
					</>
				);

			case 4:
				return (
					<>
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() => toggleSection('securityOverview')}
								aria-expanded={!collapsedSections.securityOverview}
							>
								<CollapsibleTitle>
									<FiShield /> Security Features Overview
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.securityOverview}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.securityOverview && (
								<CollapsibleContent>
									<InfoBox $variant="warning">
										<FiAlertTriangle size={20} />
										<div>
											<InfoTitle>Implicit Flow Security Considerations</InfoTitle>
											<InfoText>
												The Implicit Flow has inherent security limitations. Tokens are exposed in
												the URL, making them vulnerable to interception. This step demonstrates
												security best practices and mitigation strategies.
											</InfoText>
										</div>
									</InfoBox>

									<InfoBox $variant="info">
										<FiShield size={20} />
										<div>
											<InfoTitle>Security Features Demonstrated</InfoTitle>
											<InfoList>
												<li>
													<StrongText>Token Revocation:</StrongText> Ability to revoke access tokens
													before expiration
												</li>
												<li>
													<StrongText>Session Termination:</StrongText> End user sessions and
													invalidate tokens
												</li>
												<li>
													<StrongText>State Parameter:</StrongText> CSRF protection using state
													parameter
												</li>
												<li>
													<StrongText>HTTPS Only:</StrongText> All communications must use HTTPS
												</li>
												<li>
													<StrongText>Token Validation:</StrongText> Always validate tokens before
													use
												</li>
											</InfoList>
										</div>
									</InfoBox>
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						<SectionDivider />
						<ResultsSection>
							<ResultsHeading>
								<FiShield size={18} /> Interactive Security Demonstrations
							</ResultsHeading>
							<HelperText>
								Test security features and understand how to protect your OAuth implementation.
							</HelperText>

							<SecurityFeaturesDemo
								tokens={controller.tokens as unknown as Record<string, unknown> | null}
								credentials={credentials as unknown as Record<string, unknown>}
								onTerminateSession={() => {
									v4ToastManager.showSuccess('Session termination completed.');
								}}
								onRevokeTokens={() => {
									v4ToastManager.showSuccess('Token revocation completed.');
								}}
							/>
						</ResultsSection>

						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() => toggleSection('securityBestPractices')}
								aria-expanded={!collapsedSections.securityBestPractices}
							>
								<CollapsibleTitle>
									<FiCheckCircle /> Security Best Practices
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.securityBestPractices}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.securityBestPractices && (
								<CollapsibleContent>
									<InfoBox $variant="success">
										<FiCheckCircle size={20} />
										<div>
											<InfoTitle>Recommended Security Practices</InfoTitle>
											<InfoList>
												<li>
													<StrongText>Use HTTPS:</StrongText> Always use HTTPS for all OAuth
													endpoints
												</li>
												<li>
													<StrongText>Validate State:</StrongText> Always validate the state
													parameter to prevent CSRF
												</li>
												<li>
													<StrongText>Short Token Lifetimes:</StrongText> Use short-lived access
													tokens
												</li>
												<li>
													<StrongText>Token Storage:</StrongText> Never store tokens in localStorage
													for production
												</li>
												<li>
													<StrongText>Consider PKCE:</StrongText> Use Authorization Code + PKCE
													instead of Implicit
												</li>
												<li>
													<StrongText>Regular Audits:</StrongText> Regularly audit and rotate client
													secrets
												</li>
											</InfoList>
										</div>
									</InfoBox>

									<InfoBox $variant="danger">
										<FiAlertCircle size={20} />
										<div>
											<InfoTitle>Critical Security Warnings</InfoTitle>
											<InfoText>
												<StrongText>⚠️ Production Warning:</StrongText> The Implicit Flow is
												deprecated by OAuth 2.1 specification due to security concerns. Use
												Authorization Code + PKCE flow for new implementations.
											</InfoText>
										</div>
									</InfoBox>
								</CollapsibleContent>
							)}
						</CollapsibleSection>
					</>
				);

			case 5:
				return (
					<>
						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() => toggleSection('flowSummary')}
								aria-expanded={!collapsedSections.flowSummary}
							>
								<CollapsibleTitle>
									<FiCheckCircle /> Flow Completion Summary
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.flowSummary}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.flowSummary && (
								<CollapsibleContent>
									<InfoBox $variant="success">
										<FiCheckCircle size={20} />
										<div>
											<InfoTitle>OAuth 2.0 Implicit Flow Completed!</InfoTitle>
											<InfoText>
												Congratulations! You have successfully completed the OAuth 2.0 Implicit Flow
												demonstration. This flow returned an access token directly in the URL
												fragment for API authorization.
											</InfoText>
										</div>
									</InfoBox>

									<GeneratedContentBox>
										<GeneratedLabel>Flow Summary</GeneratedLabel>
										<ParameterGrid>
											<div>
												<ParameterLabel>Flow Type</ParameterLabel>
												<ParameterValue>OAuth 2.0 Implicit</ParameterValue>
											</div>
											<div>
												<ParameterLabel>Tokens Received</ParameterLabel>
												<ParameterValue>Access Token Only</ParameterValue>
											</div>
											<div>
												<ParameterLabel>Security Level</ParameterLabel>
												<ParameterValue>Legacy (Deprecated)</ParameterValue>
											</div>
											<div>
												<ParameterLabel>Refresh Token</ParameterLabel>
												<ParameterValue>Not Provided</ParameterValue>
											</div>
											<div style={{ gridColumn: '1 / -1' }}>
												<ParameterLabel>Recommended Alternative</ParameterLabel>
												<ParameterValue>Authorization Code + PKCE Flow</ParameterValue>
											</div>
										</ParameterGrid>
									</GeneratedContentBox>
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						<SectionDivider />
						<ResultsSection>
							<ResultsHeading>
								<FiExternalLink size={18} /> Next Steps & Recommendations
							</ResultsHeading>
							<HelperText>
								What to do now that you've completed the Implicit Flow demonstration.
							</HelperText>

							<InfoBox $variant="info">
								<FiInfo size={20} />
								<div>
									<InfoTitle>Recommended Actions</InfoTitle>
									<NextSteps
										steps={[
											'Try Authorization Code + PKCE: Experience the more secure modern OAuth flow',
											'Explore OIDC Implicit: See how OpenID Connect adds identity tokens',
											'Test API Calls: Use your access token to call protected APIs',
											'Review Security: Understand the limitations of Implicit Flow',
											'Token Management: Decode and inspect your tokens in detail',
										]}
									/>
								</div>
							</InfoBox>

							<ActionRow style={{ justifyContent: 'center', gap: '1rem', flexWrap: 'wrap' }}>
								<Button
									onClick={() => window.open('/authorization-code-v5', '_blank')}
									variant="primary"
								>
									<FiExternalLink /> Try Auth Code + PKCE
								</Button>
								<Button
									onClick={() => window.open('/oidc-implicit-v5', '_blank')}
									variant="secondary"
								>
									<FiExternalLink /> Try OIDC Implicit
								</Button>
								<Button onClick={navigateToTokenManagement} variant="success">
									<FiKey /> Decode Access Token
								</Button>
								<Button onClick={handleResetFlow} variant="outline">
									<FiRefreshCw /> Reset Flow
								</Button>
							</ActionRow>
						</ResultsSection>

						<CollapsibleSection>
							<CollapsibleHeaderButton
								onClick={() => toggleSection('flowComparison')}
								aria-expanded={!collapsedSections.flowComparison}
							>
								<CollapsibleTitle>
									<FiShield /> Flow Comparison & Migration Guide
								</CollapsibleTitle>
								<CollapsibleToggleIcon $collapsed={collapsedSections.flowComparison}>
									<FiChevronDown />
								</CollapsibleToggleIcon>
							</CollapsibleHeaderButton>
							{!collapsedSections.flowComparison && (
								<CollapsibleContent>
									<InfoBox $variant="warning">
										<FiAlertTriangle size={20} />
										<div>
											<InfoTitle>Implicit Flow vs Authorization Code + PKCE</InfoTitle>
											<NextSteps
												steps={[
													'Security: Auth Code + PKCE is more secure (no token exposure)',
													'Tokens: Auth Code provides refresh tokens for long-term access',
													'Standards: Auth Code + PKCE is OAuth 2.1 recommended',
													'Browser Support: Auth Code works better with modern browsers',
													'Migration: Implicit Flow is deprecated - plan migration',
												]}
											/>
										</div>
									</InfoBox>

									<InfoBox $variant="success">
										<FiCheckCircle size={20} />
										<div>
											<InfoTitle>Migration Benefits</InfoTitle>
											<InfoText>
												Migrating to Authorization Code + PKCE provides better security, refresh
												tokens, and compliance with modern OAuth standards. Your applications will
												be more secure and future-proof.
											</InfoText>
										</div>
									</InfoBox>
								</CollapsibleContent>
							)}
						</CollapsibleSection>

						{/* Professional Flow Completion */}
						{controller.tokens && (
							<FlowCompletionService
								config={{
									...FlowCompletionConfigs.implicit,
									flowName: 'OpenID Connect Implicit Flow V5',
									flowDescription:
										"You've successfully completed the OIDC Implicit Flow. You received both an ID token (for user identity) and access token (for API calls) directly from the authorization server.",
									onStartNewFlow: handleResetFlow,
									showUserInfo: true,
									userInfo: controller.userInfo,
									showIntrospection: !!introspectionApiCall,
									introspectionResult: introspectionApiCall,
									nextSteps: [
										'Store the ID token and access token securely',
										'Validate ID token signature and claims before trusting user identity',
										'Use the access token to call protected APIs',
										'Note: Implicit flow returns tokens directly (no refresh token)',
										'Consider migrating to OIDC Authorization Code + PKCE for better security',
									],
								}}
								collapsed={completionCollapsed}
								onToggleCollapsed={() => setCompletionCollapsed(!completionCollapsed)}
							/>
						)}
					</>
				);

			default:
				return null;
		}
	}, [
		collapsedSections,
		controller,
		currentStep,
		handleGenerateAuthUrl,
		handleOpenAuthUrl,
		handleResetFlow,
		handleIntrospectToken,
		navigateToTokenManagement,
		pingOneConfig,
		savePingOneConfig,
		showApiCallExamples,
		toggleSection,
		completionCollapsed,
		introspectionApiCall,
	]);

	return (
		<Container>
			<ContentWrapper>
				<FlowHeader flowId="oidc-implicit-v5" />

				<EnhancedFlowInfoCard flowType="oidc-implicit" />
				<FlowSequenceDisplay flowType="implicit" />

				<MainCard>
					<StepHeader>
						<StepHeaderLeft>
							<VersionBadge>OIDC Implicit Flow · V5 · Legacy</VersionBadge>
							<StepHeaderTitle>{STEP_METADATA[currentStep].title}</StepHeaderTitle>
							<StepHeaderSubtitle>{STEP_METADATA[currentStep].subtitle}</StepHeaderSubtitle>
						</StepHeaderLeft>
						<StepHeaderRight>
							<StepNumber>{String(currentStep + 1).padStart(2, '0')}</StepNumber>
							<StepTotal>of {String(STEP_METADATA.length).padStart(2, '0')}</StepTotal>
						</StepHeaderRight>
					</StepHeader>

					{!isStepValid(currentStep) && currentStep !== 0 && (
						<RequirementsIndicator>
							<RequirementsIcon>
								<FiAlertCircle />
							</RequirementsIcon>
							<RequirementsText>
								<StrongText>Complete this step to continue:</StrongText>
								<ul>
									{getStepRequirements(currentStep).map((requirement, index) => (
										<li key={index}>{requirement}</li>
									))}
								</ul>
							</RequirementsText>
						</RequirementsIndicator>
					)}
					<StepContentWrapper>{renderStepContent}</StepContentWrapper>
				</MainCard>
			</ContentWrapper>

			<StepNavigationButtons
				currentStep={currentStep}
				totalSteps={STEP_METADATA.length}
				onPrevious={handlePrevStep}
				onReset={handleResetFlow}
				onStartOver={handleStartOver}
				onNext={validatedHandleNext}
				canNavigateNext={validatedCanNavigateNext()}
				isFirstStep={currentStep === 0}
				nextButtonText={isStepValid(currentStep) ? 'Next' : 'Complete above action'}
				disabledMessage="Complete the action above to continue"
			/>

			<LoginSuccessModal
				isOpen={showSuccessModal}
				onClose={() => setShowSuccessModal(false)}
				title="🎉 Implicit Flow Success!"
				message="Access token received successfully! You can now explore token analysis and make API calls."
				autoCloseDelay={5000}
			/>

			{/* Authentication Modal */}
			{AuthenticationModalService.showModal(
				showRedirectModal,
				() => setShowRedirectModal(false),
				handleConfirmRedirect,
				controller.authUrl,
				'oidc',
				'OIDC Implicit Flow',
				{ redirectMode: 'redirect' }
			)}
		</Container>
	);
};

export default OIDCImplicitFlowV6;
