// src/pages/flows/OIDCImplicitFlowV6.tsx
// OIDC Implicit Flow V6 - Full implementation with ID Token support and nonce requirement

export { default } from './OIDCImplicitFlowV6_Full';
